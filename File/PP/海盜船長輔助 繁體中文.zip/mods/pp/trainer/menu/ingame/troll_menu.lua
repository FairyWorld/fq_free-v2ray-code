if ( not GameSetup ) then
	return
end

local pp_require = pp_require
pp_require 'trainer/tools/new_menu/menu'

local main_menu, interaction_with_other, interaction_with_id_menu, interaction_with_self, activate_elements, trigger_alarm_menu, interaction_with_team, give_equipments, give_bags, give_items,kick_ply

local path = "trainer/addons/troll_menu/"

local managers = managers
local M_navigation = managers.navigation
local M_network = managers.network
local M_net_session = M_network:session()
local M_localization = managers.localization
local locale_text = M_localization.text
local locale_exists = M_localization.exists

local tweak_data = tweak_data
local T_equipments = tweak_data.equipments
local T_E_specials = T_equipments.specials

local M_enemy = managers.enemy
local M_fire = managers.fire
local G_timer = TimerManager:game()
local togg_vars = togg_vars

local World = World
local W_spawn_unit = World.spawn_unit
local M_groupAI = managers.groupai
local T_levels = tweak_data.levels
local team_id = T_levels:get_default_team_ID("combatant")
local team_data = M_groupAI:state():team_data( team_id )
local spook_id = Idstring( "units/payday2/characters/ene_spook_1/ene_spook_1" )

togg_vars.reduce_damage = {}

-- Functions

local alive = alive
local m_log_error = m_log_error

function unit_from_id( id )
	local unit = M_net_session:peer( id ):unit()
	if alive(unit) then
		return unit
	else
		m_log_error('unit_from_id()','Peer',id,'is dead')
	end
end
local unit_from_id = unit_from_id

local pairs = pairs
local all_ladders = Ladder.ladders

local increase_ladder = function()
	for _,unit in pairs( all_ladders )  do
		local ladder = unit:ladder()
		if ladder then
			ladder:set_height( 10000 )
			ladder:set_width( 10000 )
		end
	end
end

local PackageManager = PackageManager
local package_udata = PackageManager.unit_data

local World = World
local find_units_quick = World.find_units_quick
local delete_unit = World.delete_unit

local delete_units = function()
	for _,unit_data in pairs(find_units_quick(World, "all"))  do
		if package_udata( PackageManager, unit_data:name() ):network_sync() == "spawn" then
			delete_unit(World, unit_data)
		end
	end
end

local GetPlayerUnit = GetPlayerUnit
local M_player = managers.player

local change_own_state = function(state)
	if alive( GetPlayerUnit() ) then
		M_player:set_player_state(state)
	else
		m_log_error('change_own_state()','You are dead.')
	end
end

kick_ply = function( id )
	local session = M_network._session
	if ( session ) then
		local peer = session:peer( id )
		if ( peer ) then
			session:on_peer_kicked( peer, id, 0 )
			session:send_to_peers( "kick_peer", id, 0 )
		end
	end
end

local set_cops_on_fire = function()
	local weapon_unit = GetPlayerUnit():inventory():unit_by_selection(1)
	
	local all_enemies = M_enemy:all_enemies()
	for u_key, u_data in pairs( all_enemies ) do
		M_fire:add_doted_enemy( u_data.unit, G_timer:time(), weapon_unit, 10, 10 )
	end
end

-- Interact with other players

local rot0 = Rotation(0,0,0)

local teleport_to_player = function(id)
	local unit = unit_from_id(id)
	if unit then
		M_player:warp_to( unit:position(), rot0 )
	end
end

-- Give equipments
local give_equipment = pp_require( path .. 'spawn_equipments' )

-- Spawn bag
local give_bag = pp_require( path .. 'spawn_bags' )

-- Interact with players
local sync_movement = pp_require( path .. 'sync_movement' )

-- Activate element
local run_element = pp_require( path .. 'activate_element' )

-- Add item
local add_item = pp_require( path .. 'add_items' )

-- Teleport player
local teleport_player = function(id)
	local unit = unit_from_id(id)
	if unit then
		sync_movement(id, "dead")
		
		local release_player = function() sync_movement( id, "release" ) end
		executewithdelay(release_player, 1)
	end
end

-- Teleport team
local teleport_team = function()
	sync_movement("all", "dead")
	
	local release_team = function() sync_movement("all", "release") end
	executewithdelay(release_team, 1)
end

-- Slap player
local set_killzone = function( id )
	local unit = unit_from_id( id )
	if unit then
		local rpc_params = {
			"killzone_set_unit",
			"sniper"
		}
	
		unit:network():send_to_unit( rpc_params )
	end
end

local invisible_spooks = function()
	run_element("dismember_body_top")
	run_element("dismember_head")
end

local spawn_spook = function( id )
	local unit = unit_from_id( id )
	if not unit then
		return
	end
	
	local unit = W_spawn_unit( World, spook_id, unit:position(), unit:rotation() )
	unit:brain():set_spawn_ai( { init_state = "idle" } )		
	unit:movement():set_team( team_data )
end

local reduce_damage_all = function()
	togg_vars.reduce_damage.all = not togg_vars.reduce_damage.all
	
	local dmg = togg_vars.reduce_damage.all and 100 or -1
	for _, peer in pairs(M_net_session._peers) do
		peer:send_queued_sync("sync_damage_reduction_buff", dmg)
	end
end

local reduce_damage = function( id )
	if id == "all" then
		reduce_damage_all()
		return
	end
	
	togg_vars.reduce_damage[id] = not togg_vars.reduce_damage[id]
	
	local dmg = togg_vars.reduce_damage[id] and 100 or -1
	for i, peer in pairs(M_net_session._peers) do
		if i == id then
			peer:send_queued_sync("sync_damage_reduction_buff", dmg)
			
			break
		end
	end
end

local sub = string.sub

local RunNewLoopIdent = RunNewLoopIdent
local StopLoopIdent = StopLoopIdent
local AllRunningLoops = AllRunningLoops

local Localization = Localization
local tr = Localization.translate

local backuper = backuper
local restore = backuper.restore
local hijack = backuper.hijack

local lname = "face_rider"
local riding_id

-- Ride upon the face of your allies into battle, by Davy Jones
local ride_player = function(id)
	local function stop()
		riding_id = nil
		restore(backuper, "ChatManager.send_message")
		StopLoopIdent(lname)
	end
	if riding_id and riding_id == id then
		stop()
	else
		local loops = AllRunningLoops()
		if loops[lname] then
			stop()
		end
		riding_id = id
		hijack(backuper, "ChatManager.send_message", function(o, self, channel_id, sender, message)
			local last = sub(message, -1)
			local modify = last == "!" or last == "." or last == "?"
			o(self, channel_id, sender, (modify and sub(message, 1, -2) or message)..tr['troll_rider_peasant']..(modify and last or ""))
		end)
		local unit = unit_from_id(id)
		local function ride()
			if alive(unit) and alive(M_player:player_unit()) then
				M_player:warp_to(unit:movement()._m_head_pos, rot0)
			else
				stop()
			end
		end
		RunNewLoopIdent(lname, ride)
	end
end

local open_menu
do
	local Menu = Menu
	local open = Menu.open
	open_menu = function( ... )
		return open(Menu, ...)
	end
end

local spawn_deposit_money_box = function()
	local chance_text = tr['chance']
	local data = {
		{ text = chance_text .. " 25%", callback = run_element, data = { "spawn_special_money", 4 } },
		{ text = chance_text .. " 50%", callback = run_element, data = { "spawn_special_money", 2 } },
		{ text = chance_text .. " 100%", callback = run_element, data = { "spawn_special_money", 1 } },
	}

	open_menu( { title = tr['troll_fill_deposits_money'], button_list = data, back = activate_elements } )
end

local tab_insert = table.insert

-- Menu
--TO DO: Catch these details from tweak_data ?
give_equipments = function( id, back_f )
	local data = {
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_ammo_bag"), callback = give_equipment, data = { id, "ammo" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_doctor_bag"), callback = give_equipment, data = { id, "medic" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_equipment_ecm_jammer"), callback = give_equipment, data = { id, "ecm" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_trip_mine"), callback = give_equipment, data = { id, "trip_mine" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_sentry_gun"), callback = give_equipment, data = { id, "sentry" } },
		{ text = tr['troll_give'] .. " " .. locale_text(M_localization, "debug_equipment_bodybags_bag"), callback = give_equipment, data = { id, "bodybag" } },
	}
	
	open_menu( { title = tr['troll_give_equipments'], button_list = data, back = back_f } )
end

give_bags = function( id, back_f )
	local data = {}
	local data_carry = tweak_data.carry
	local locale_text = M_localization.text
	local locale_exists = M_localization.exists
	
	for bag_id, bag_data in pairs( data_carry ) do
		local name_id = bag_data.name_id
		if name_id and locale_exists( M_localization, name_id ) then
			tab_insert( data, { text = tr['troll_give'] .. " " .. locale_text( M_localization, name_id ), callback = give_bag, data = { id, bag_id }, switch_back = true } )
		end
	end
	
	open_menu( { title = tr['troll_give_bags'], button_list = data, back = back_f } )
end

give_items = function( id, back_f )
	local data = {}
	
	local locale_text = locale_text
	local locale_exists = locale_exists
	
	for item_id, item_data in pairs( T_E_specials ) do
		local text_id = item_data.text_id
		if text_id and locale_exists( M_localization, text_id ) then
			tab_insert( data, { text = tr['troll_give'] .. " " .. locale_text( M_localization, text_id ), callback = add_item, data = { id, item_id }, switch_back = true } )
		end
	end
	
	open_menu( { title = tr['troll_give_bags'], button_list = data, back = back_f } )
end

local data_access = {
	M_groupAI:state():get_unit_type_filter("civilians_enemies"),
	M_navigation:convert_access_flag("teamAI1")
}

local panic_alarm = function(typ, act)
	for _, group in pairs({M_enemy:all_civilians(), M_enemy:all_enemies()}) do
		for _, unit in pairs(group or {}) do
			M_groupAI:state():propagate_alert({typ, unit.m_pos, 10000, act == 3 and unit.so_access or data_access[act], act == 2 and M_player:player_unit() or act == 3 and unit.unit or nil, act == 2 and unit.m_pos or nil})
		end
	end
end

interaction_with_self = function()
	local data = {}
	for _,state in pairs( M_player:player_states() ) do
		if state ~= "fatal" and state ~= "bleed_out" and state ~= "bipod" and state ~= "driving" then
			tab_insert(data, { text = state, callback = change_own_state, data = state })
		end
	end
	
	open_menu( { title = tr['troll_change_own_state'], button_list = data, back = main_menu } )
end

local format_loc = Localization.text

interaction_with_id_menu = function( id, name )
	local back_f = function() interaction_with_id_menu( id, name ) end
	
	local data = { 
		{ text = tr['troll_release_player'], callback = sync_movement, data = { id, "release" } },
		{ text = tr['troll_teleport_to'], callback = teleport_to_player, data = id },
		{ text = tr['troll_teleport_player'], callback = teleport_player, data = id, host_only = true },
		{ text = tr['troll_set_killzone'], callback = set_killzone, data = id, host_only = true },
		{ text = tr['troll_reduce_damage'], type = "toggle", toggle = function() return togg_vars.reduce_damage[id] end, callback = reduce_damage, data = id, host_only = true },
		{ text = tr['troll_rider']..":  "..(riding_id and riding_id == id and tr['troll_rider_stop'] or tr['troll_rider_start']), callback = ride_player, data = id},
		{},
		{ text = tr['troll_give_equipments'], callback = give_equipments, data = { id, back_f }, menu = true },
		{ text = tr['troll_give_bags'], callback = give_bags, data = { id, back_f }, menu = true },
		{ text = tr['troll_give_items'], callback = give_items, data = { id, back_f }, host_only = true, menu = true },
		{ text = tr['troll_spawn_spook'], callback = spawn_spook, data = id, host_only = true },
		{},
		{ text = tr['troll_send_peer_in_custody'], callback = sync_movement, data = { id, "dead" } },
		{ text = tr['troll_tase_player'], callback = sync_movement, data = { id, "tased" } },
		{ text = tr['troll_arrest_player'], callback = sync_movement, data = { id, "arrested" } },
		{ text = tr['troll_kill_player'], callback = sync_movement, data = { id, "bleed_out" } },
		{ text = tr['troll_standart_player'], callback = sync_movement, data = { id, "standard" } },
		{ text = tr['troll_kick_player'], callback = kick_ply, data = id },
	}
	
	open_menu( { title = format_loc(Localization, 'troll_interact_with', name, id), button_list = data, back = interaction_with_other } )
end

interaction_with_team = function()
	local data = { 
		{ text = tr['troll_team_god_mode'], host_only = true, plugin = "team_god_mode", switch_back = true },
		{ text = tr['troll_teleport_team'], callback = teleport_team, host_only = true },
		{ text = tr['troll_reduce_damage'], type = "toggle", toggle = function() return togg_vars.reduce_damage.all end, callback = reduce_damage, data = "all", host_only = true },
		{},
		{ text = tr['troll_give_equipments'], callback = give_equipments, data = { "all", interaction_with_team }, menu = true },
		{ text = tr['troll_give_bags'], callback = give_bags, data = { "all", interaction_with_team }, menu = true },
		{ text = tr['troll_give_items'], callback = give_items, data = { "all", interaction_with_team }, host_only = true, menu = true },
		{},
		{ text = tr['troll_send_tm_in_custody'], callback = sync_movement, data = { "all", "dead" } },
		{ text = tr['troll_release_tm_from_jail'], callback = sync_movement, data = { "all", "release" } },
		{ text = tr['troll_tase_tm'], callback = sync_movement, data = { "all", "tased" } },
		{ text = tr['troll_arrest_tm'], callback = sync_movement, data = { "all", "arrested" } },
		{ text = tr['troll_kill_tm'], callback = sync_movement, data = { "all", "bleed_out" } },
		{ text = tr['troll_standard_tm'], callback = sync_movement, data = { "all", "standard" } },
		{ text = tr['troll_kick_all_players'], callback = function() for I=2,4 do kick_ply(I) end end },
	}
	
	open_menu( { title = tr['troll_interact_team'], button_list = data, plugin_path = path, back = interaction_with_other } )
end

interaction_with_other = function()
	local data = { 
		{ text = tr['troll_interact_team'], callback = interaction_with_team, menu = true },
		{},
	}
	
	local count_data = #data
	
	local session = M_network._session
	local lpeer_id = session._local_peer._id
	for _, peer in pairs( session._peers ) do
		local peer_id = peer._id
		if peer_id ~= lpeer_id then
			local peer_name = peer._name
			tab_insert( data, { text = format_loc(Localization, 'troll_interact_with', peer_name, peer_id ), callback = interaction_with_id_menu, data = { peer_id, peer_name }, menu = true } )
		end
	end
	
	if #data == count_data then
		tab_insert(data, { text = tr['troll_no_players'], callback = void })
	end
	
	open_menu( { title = tr['troll_interaction_with_other'], button_list = data, plugin_path = path, back = main_menu } )
end

activate_elements = function()
	local data = {
		{ text = tr['troll_open_doors'], callback = run_element, data = "anim_open_door" },
		{ text = tr['troll_close_doors'], callback = run_element, data = "anim_close_door" },
		{ text = tr['troll_open_vault'], callback = run_element, data = "anim_open" },
		{ text = tr['troll_close_vault'], callback = run_element, data = "state_closed" },
		{ text = tr['troll_remove_head'], callback = run_element, data = "activate_ragdoll_head" },
		{ text = tr['troll_fill_deposits_money'], callback = spawn_deposit_money_box, box = true },
		{ text = tr['troll_invisible_spooks'], callback = invisible_spooks },
		{ text = tr['troll_launch_cars'], callback = run_element, data = "not_driving" },
		{ text = tr['troll_close_van_doors'], callback = run_element, data = "state_door_rear_both_close" },
		{ text = tr['troll_open_van_doors'], callback = run_element, data = "anim_door_rear_both_open" },
	}
	
	open_menu( { title = tr['troll_activate_elements'], button_list = data, back = main_menu } )
end

-- Alert all people with different calls, by Davy Jones
trigger_alarm_menu = function()
	local data = {
		{ text = tr['troll_alarm_crim'], callback = panic_alarm, data = {"aggression", 1} },
		{ text = tr['troll_alarm_gun'], callback = panic_alarm, data = {"bullet", 2} },
		{ text = tr['troll_alarm_exp'], callback = panic_alarm, data = {"explosion", 1} },
		{ text = tr['troll_alarm_mon'], callback = panic_alarm, data = {"vo_intimidate", 3} },
	}

	open_menu( { title = tr['troll_alarm'], button_list = data, back = main_menu } )
end

local pp_dofile = pp_dofile

main_menu = function()
	local data = { 
		{ text = tr['troll_interaction_with_other'], callback = interaction_with_other, menu = true },
		{ text = tr['troll_change_own_state'], callback = interaction_with_self, menu = true },
		{ text = tr['troll_activate_elements'], callback = activate_elements, host_only = true , menu = true},
		{ text = tr['troll_alarm'], callback = trigger_alarm_menu, menu = true },
		{},
		{ text = tr['troll_cops_to_bulld'], host_only = true, plugin = "cops_to_bulld" },
		{ text = tr['troll_replace_cops'], host_only = true, plugin = "replace_cops" },
		{ text = tr['troll_exploding_enemies'], host_only = true, plugin = "exploding_enemies" },
		{ text = tr['troll_change_statistic'], plugin = "change_statistic" },
		{ text = tr['troll_change_spawn_pos'], host_only = true, callback = pp_dofile, data = path .. "change_spawn_pos" },
		{ text = tr['troll_increase_ladder'], callback = increase_ladder },
		{ text = tr['troll_del_units'], host_only = true, callback = delete_units },
		{ text = tr['troll_take_mask'], callback = change_own_state, data = "mask_off" },
		{ text = tr['troll_set_cops_on_fire'], callback = set_cops_on_fire },
		{ text = tr["troll_drill"], plugin = 'trolldrills', switch_back = true },
	}
	
	open_menu( { title = tr['troll_menu'], plugin_path = path, button_list = data } )
end

return main_menu