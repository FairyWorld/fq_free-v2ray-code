pp_require 'trainer/tools/sorteddialog'

local change_name,main_menu,open_name_menu,table_names
local data_names

-- Function

change_name = function(name)
	Global.spoofed_name = name
	pp_require 'trainer/addons/namespoof'
	pp_config.NameSpoof = name
end

-- Menu

open_name_menu = function(id, translation)
	show_sorted_dialog(Localization.translate[translation], nil, data_names[id], main_menu)
end

main_menu = function()
	data_names = { [1] = {}, [2] = {}, [3] = {}, }
	local data = { 
		{ text = Localization.translate['spoof_standard_names'], callback = function() open_name_menu(1, "spoof_standard_names") end  },
		{ text = Localization.translate['spoof_donors_names'], callback = function() open_name_menu(2, "spoof_donors_names") end },
		{ text = Localization.translate['spoof_pirates_names'], callback = function() open_name_menu(3, "spoof_pirates_names") end },
	}
	
	for line in pp_io.lines("trainer/other/names.txt") do 
		table_names = (line == "--Standard") and 1 or (line == "--Donors") and 2 or (line == "--Pirates") and 3 or table_names

		if not string.find(line, "^(%-%-)") then
			table.insert(data_names[table_names], { text = line, callback = change_name, data = line })
		end
	end
	table.insert(data_names[1], 25, { text = "Anti-kicky", callback = change_name, data = "" })
	
	show_sorted_dialog(Localization.translate['spoof_menu'], Localization.translate['change_name'], data)
end

main_menu() -- Open menu