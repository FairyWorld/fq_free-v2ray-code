-- Guards doesn't see tied civilians

--Add script or remove file at all