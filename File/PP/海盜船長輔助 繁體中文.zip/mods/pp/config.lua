return function( cfg )
	cfg.menu_save=true
	cfg.Language="ttraditional"
end
