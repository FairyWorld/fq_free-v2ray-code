--pp_require core key config first
--Read trainer/keyconfig for default key configuration and documentation
local cfg=pp_require("trainer/keyconfig")

return cfg
