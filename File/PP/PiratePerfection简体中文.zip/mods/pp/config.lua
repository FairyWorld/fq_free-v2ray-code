return function( cfg )
	cfg.HUD_MovingText=false
	cfg.HUD=false
	cfg.RunSpeed=234
	cfg.FreeFlightTeleport=true
	cfg.FreeAssets=false
	cfg.Language="schinese"
	cfg.NoCivilianPenality=false
	cfg.announcements=false
	cfg.NoStatsSynced=false
	cfg.RestartProMissions=true
	cfg.menu_save=true
	cfg.HUD_VersionText=false
	cfg.DisableAutoKick=false
	cfg.NoEscapeTimer=true
	cfg.announcements_interval=1
end
