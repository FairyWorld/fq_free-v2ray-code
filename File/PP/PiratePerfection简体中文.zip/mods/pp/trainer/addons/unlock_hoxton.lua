--backuper:backup('GenericDLCManager.has_freed_old_hoxton')
function GenericDLCManager.has_freed_old_hoxton()
	return true
end