﻿Pirate Perfection Reborn
完美海盗：重生

汉化 By y123ao6@3DM 

Trainer for PAYDAY 2 remade from white list with a fresh new structure and less bugs than in previous versions. Some scripts were improved, some got lost from original Pirate Perfection, but are slowly being reintroduced.

Enjoy cheating pirates :-)
祝你玩得开心

If you have any troubles, please report bugs here through our forum support
如果你有些问题，请打开下面网址发帖反馈
https://www.pirateperfection.com/support/

Version: v1

REGULAR USERS
- Noclip speed
- No rpg delay
- Fixed bag all corpses
- Added spawn forkflift and enemy/friendly turret
- Increase amount of hostile units
- Favorites menu in props menu
- Spoof Detection Level
- Receive 50% damage
- Reduce AI hitpoints to 1%
- Spawn cloaker behind teammate
- Fixed vault door open/close
- Added music menu
- I Want that menu by Davy Jones
- Allskins unlocker
- New spawnable units
DONORS
- Teleport player to self
- Teleport team to self
- Slap player
- Slap team
- Invisible spooks/cloakers
- 100% decapitation chance
- Launch players car into the air
- Remove Getaway Van
- Secret skills menu by  Davy Jones
- Troll drill by King Nothing
- Reduce player damage
- Reduce team damage
PREMIUMS
- Sequencer Menu
- Spoof name

Version: v0.99

Featuring:

- Crosshair added
- Superman MOD converted to true NoClip 
- Driver2 - Spawn vehicles and drive them (on maps that allows it)
- Exploding Domino cops
- Spawn turret
- Premium option fixed
- New units in spawn menu
- DLC unlocker fixed
- Set cops on fire
- Change sentry gun ammunition (grenades, molotovs or rockets)
- Bugfixes galore ( autocooker,choose engine, xray, interaction menu,waypoints,anti anti cheat,skills/infamy reset,unlock all perks,add perks points,troll menu, spawn bags, rain bags)
 
- PVP ( Kill your teammates mod)
- Enhanced billboard on Harvest and trustee maps
- Choppy mod (Yea the heli is back)
- Wavehouse (safehouse minigame)
- Updated the infamy menu upping max to 25
- Bugfixes

Version: v0.97a

Featuring:

- DLC Unlocker (Why do we need to bother buying all dlcs ? Get them for free here!)
- Stealth cheats (Everything you need to make your stealth heist successfull)
- Character cheats (Common cheats like godmode, infinite ammo and etc.)
- Inventory cheats (Spawn extra bags or rain them to make your day)
- Interaction cheats (Instantly interact with common things or improve your interaction with things at all)
- Freeflight (Wonderfull for movie making)
- Autostart cheats (If you don't want to manually turn on some of them)
- Spawn menu (Spawn enemies and props for fun)
- Xray (A.k.a. wallhack)
- Equipment cheats (Do you want your sentry shoot grenades ? Go here!)
- Slowmotion (whyyyy soooo sloooooooow ?)
- Lego (Build your own castle)
- Some anti-noob protections (It will display warning whenever you're close to get marked as cheater)
- Anticheat disabler (Let other people cheat on your server too)
- Easy configuration (Do you want to turn on various cheats on game start or tweak some ? Now it is easy!)
- Abillity to localizate trainer or use already done localizations
- And many more ...

Keys:
5 - Equipment spawn menu
设备生成菜单
6 - Place prop
放置道具
7 - Switch to previous prop
选择上一个点
8 - Switch to next prop
选择下一个点

Numpad 1 - Character menu in game/Inventory cheats in menu
通用（游戏里）/库存作弊（主界面）
Numpad 2 - Job menu/Stealth menu
工作菜单/隐秘行动菜单
Numpad 3 - Spawn menu
生成菜单
Numpad 4 - Troll menu (Donor's or higher have full version)
恶搞菜单（免费版不可用）
Numpad 5 - Interaction menu
互动作弊菜单
Numpad 6 - Inventory menu (Bags and in game money related menu)
物品菜单
Numpad 7 - Weapon list
武器列表
Numpad 8 - Equipment menu
设备菜单
Numpad 9 - Mission menu
关卡菜单
Numpad + - Pregame menu
游戏前的菜单

END - Instant win
直接胜利
HOME - Normalizer
取消修改

F1 - Help menu
帮助菜单
F2 - Mod menu
MOD菜单
F4 - Carry stacker (frequently tap it in order to drop all stored bags)
携带更多袋子
F5 - User script
用户脚本
F6 - Configuration menu
配置菜单

Z - Replenish all ammo and health, restore standard state
满血满子弹
X - Xray
透视

Middle Mouse Button - Teleport（这个是鼠标中键）
传送
X7 Extra Button 1 - Slowmotion（这个按键是鼠标侧键）
慢动作（子弹时间）

Mods control:
	Superman mod: 
	Page Up - Fly up.
	起飞
	Page Down - Fly down.
	降落
	
	Driver mod: 
	arrow left/right/up/down - Move left/right/up/down.
	方向键 			           移动
	
	Lego mod:
	
	Page Up - Place lego.
	放置lego   
	Page Down - Remove lego.
	移除lego
	
Installation:
注意事项
If you had Pirate Perfection v16 and a lower installed earlier, remove it first.
假如你还保留着完美海盗V16或者更低版本的，请先移除它
Place all files from current folder into the game folder (:/Program Files (x86)/Steam/steamapps/common/PAYDAY 2 or where game located)
请将解压出来所有文件放置到游戏目录（你游戏安装在哪里，就解压出来的文件放在哪里，跟你的payday2_win32_release.exe在一起）
Remove IPHLPAPI.dll from game root folder (if you have it)
请先移除游戏目录里的IPHLPAPI.dll（假如你有它的话）
Don't forget to edit config.lua and keyconfig.lua to your taste.
别忘记你修改 config.lua 和 keyconfig.lua 之后的改动（前者是功能设置，后者是按键设置）

(+) - Addition
(*) - Fix

Version story:
v0.97a
(*) Synced underground light hook with latest changes.
(*) Greatly improved lego mod. Now you can place more props on map, place them using binded key and even quickswitch between them using same binds.
(*) Configs structure updated, so now config related problems are easier to detect. Update all your configs with current structure, including config.lua, key configs, game configs.
(*) Announcements, update checker and version checker are working again.
(*) restart_pro_missions.lua updated
(*) Fixed bug, where cheat control got unloaded for game session, when game configs were switched or game was normalized.
(*) Localizator changes, preparation for upcoming changes related to localizations.
(*) Added menu, where you can configure waypoints filter. (For show waypoints in mission menu)
(*) Autocooker improved, so now it doesn't require "Interact with all" to be enabled in order to properly work.
(+) Added shut down dialogs (can be found in mission menu)
(*) Probably fixed issue, where convert all stopped converting others, when it failed to convert atleast 1 enemy.
(+) Added "Secure All" script. Now you can secure any type of bag in special zones for that.
(*) Improvements in xray
(*) New interactions were added in interaction menu
(*) General improvements with scripts, so now trainer do less queries to disk for some trainer scripts.

v0.96i
(+) Moved trainer to new hook
(*) Fixed props sub menu in spawn menu not opening
(*) Improved text input and multi choice elements. Now you can hold key in text input to remove text and move carret; in multi choice you can use arrows to select some item.
(+) Added abillity to change permission and kick settings in job menu.

v0.95
(*) Now secure bags chooses the most expensive bag automatically
(*) Fixed equipments not being binded on alt. click in equipment menu
(*) Bag throw multiplier can be changed in config
(*) Fixed normalizer, so now it restores and reboots properly
(*) Updated drop-in pause script (more proof to updates, show join status in chat)
(*) Applied some optimisations, where they needed
(*) Slowmotion updated (you gonna like it)
(*) Fixed aimbot targeting some friendly units
(*) Fixed crash in spawn menu
(*) Fixed infinite cable ties not working
(*) Fixed description issues in custom menu
(*) Updated lasecolor.lua (Noob proofed in general)
(*) Updated some descriptions in config.lua
(*) Fixed issue, where game could crash, if some plugin in opened menu isn't found
(-) Removed headshot sounds, trainer size greatly decreased
(*) Reworked disable_anticheat.lua
(*) Fixed Job Menu's glitch with permissions
(*) Remade equipment control. Turned into plugin and much better code.
(*) A lot of work with the trainer's scripts
(*) Improved First launch and Crash Noticer messaging logic a bit.

(+) Added multiple configs feature. Currently you can create/rename/delete configs, save your active cheats to some config and change them on fly.
(+) Added script, that remove delays between melee attacks (can be found in Character menu)
(+) Added menu, from where you can load user plugins (located in trainer/plugins). Menu located in trainer/menu/custom_plugins.lua. Bind it in keyconfig or use dofile in your custom script. This is experimental feature.
(+) Added plugin "Noone shall down". (Can be found in interaction menu)
(+) Added new interactions to interaction menu.
(+) Added check to menus, so if some plugin isn't found, button for this plugin will not be visible.
(+) Added escapes to Job menu
(+) Added grenade shooting weapon
(+) Added change armor and melee weapon
(+) Added new units to spawn menu

v0.91
->Added unlock/lock all perks.
->Added unlock old hoxton script.
->Added new units to spawn menu.
->Added revive all players and open all doors to interaction menu, also added new interactions.
->Added possibility to choose a heist day in job menu.
->Added equipment spawn menu.

->*Updated troll menu.
->Improved xray.
->Fixed instant intimidation.
->Fixed correct engine menu.
->Fixed weapon menu.
->Fixed driver.
->Updated inventory menu.
->Improved AimBot (It's no longer refill your health, refill ammo as option, also you can choose damage).
And some other fixes.

v0.9
->Added unlock skill tiers.
->Added text input.
->Added fix for miami dlc.
->Added remove exclamation mark.
->Added use all perks.
->Added option to add perk points.

->Fixed interaction menu.
->Fixed instant interaction.
->Fixed spawn menu and added new units to it.
->Improved shoot through walls script.

v0.85

Added:
-> Added new menu.
-> Added equipment changer.
-> Added spawn on random spawn position to spawn menu.
-> Added crazy firerate to grenade launcher.
-> Added key config option in main config.
-> Added multi choice to menu.

Updated:
-> Weapon mods in all items menu sorted by categories.
-> Updated main menu.
-> Updated spawn menu.
-> Updated weapon menu.
-> Improved menu slider.
-> Fixed inventory menu.
-> Fixed and updated job menu.

v0.8
Added:
-> Added lock all achievements.
-> Added tie all civilians.
-> Added script to make player invisible for AI.
-> Added change FOV on mouse scroll.
-> Added increase bag throw force.
-> Added make all bags explosive.
-> Added no penalty movement with bag.
-> Added experimental menu to character and inventory menu.

Updated:
-> Updated troll menu.
-> Updated trainer structure.
-> Fixed lobotomize AI.
-> Fixed bug with F2 button.

And other fixes and changes.

v0.7
Added:
-> Reduce detection level.
-> Correct engine menu.
-> Convert all.
-> Instantly charge melee weapon.
-> Host check to some scripts.
-> Remove limit of installed modifications.
-> Option to choose weapon from inventory.
-> Included unlimited saw ammo to unlimited weapon ammo

Updated:
-> Upgraded inventory menu.
-> Updated waypoints.
-> Fixed crash with laser color.
-> Fixed instant intimidation crashes
-> Fixed no fall damage, now it works as intended.
-> Fixed lobotomize all ai.
-> Removed old menu require from some scripts, now conflicts should gone
-> dofile() shoudn't cause crashes, if file wasn't found
-> Updated error messages around, they should be more detail now.

And other changes.

v0.6
Added:
-> New translations made by community
-> Returned open all ATMs.
-> Returned instant intimidation.
-> Returned Anti-kicky name.
-> Returned instant deployment.
-> Returned weapon instant kill
-> Returned very cutted troll menu version for public release

Updated:
-> Trainer structure updated
-> Xray marks friendly units properly now
-> Modified menu.
-> Troll menu updated.
-> Added save settings option.
-> Fixed some bugs.

And other changes, these we didn't log

F.A.Q.
注意
A. My DLC items locked again/DLC unlocker isn't working/DLCs aren't working, what to do ?
为什么我的DLC物品还是锁着的/为什么DLC解锁不工作/DLC不工作，怎么办
R. Look into config.lua and set DLCUnlocker to true. (DLCUnlocker = true)
请打开 config.lua 检查 DLCUnlocker 这项是不是为 true （就是这样 DLCUnlocker = true ）
We disabled it by default, because it causes kicks/cheater tags for using DLC item you don't own (see colored list below for more information)
我们默认是把这项关闭的，因为这项功能会使你永远戴着红马甲而导致被踢被骂，假如你不介意这些问题，可以重新打开它

A. Why achievements are not working ?
为什么我拿不到成就
R. Because stats synchronisation disabled by default, you can enable in config.lua by changing NoStatsSynced = true to NoStatsSynced = false Just make sure you will set your profile visibility from public to other.
因为完美海盗在默认设置中关闭了同步数据，你可以通过修改 config.lua 重新打开同步数据，操作如下：在 config.lua 找到 NoStatsSynced = true 改为 NoStatsSynced = false ，这样你的用户数据会被公开（言下之意：可能导致你被举报什么的）

A. Name spoofing broken, fix it!
名称伪装不行了，修复它
R. Name spoofing was broken by update.
在某次更新后，这货已经完蛋了

A. My game crashes with error "Engine stopped working" after I installed trainer. How to fix it ?
在我使用修改器后，游戏崩溃了，提示"Engine stopped working" ，怎么办
R. In 99% of cases that means you installed trainer wrong or have other mods installed, like Hoxhud. Try to reinstall trainer properly and everything should work fine. If you're 100% sure that you installed trainer properly, then you can create new topic in "Support" forum section and we'll try our best to help you.
99%的问题都来自于你还安装了其他会引发冲突的MOD或者修改器，比如Hoxhud。所以请尝试移除这些可能会导致问题的MOD或者修改器再次运行游戏，如果你确认你100%你正确放置完美海盗，请到咱们的官网来，在"Support" 这个论坛板块发帖回复

A. I've installed trainer, but nothing works or shows up, what I have to do?
我正确放置了修改器，但它还是不工作，怎么办
R. To repeat, trainer will not work on Windows XP.
重复，完美海盗不支持XP
Uninstall old versions of Pirate Perfection (applies only to those, who still have v16), uninstall other lua mods/trainers. Make sure you unpacked everything from release/donor folder to main game folder. Also delete file called "PD2APIDLL1.dll".
请删除所有有关旧版本的完美海盗，同时请删除其他LUA类的MOD或修改器，然后重新把完美海盗最新版解压并正确放置到游戏目录下（假如你游戏目录里有一个DLL叫"PD2APIDLL1.dll"，也请删了它）

A. How to enable *some option* ?
怎么开启一些设置
R. Checkout config.lua and explore menus.
请把 config.lua 的内容用优秀的在线翻译翻译一次

A. NVAPI error in dll hook, how to fix it ?
提示NVAPI 错误，我该怎么办
R. Try to run game as Administrator
请在管理员模式下运行游戏

A. Do trainer have *some feature* ?
这修改器有什么与众不同的地方
R. Maybe we will write full list of what trainer can do, but why not to explore it yourself ? ;)
或许我们应该写更多内容来表达完美海盗能做到什么。笑~

A. Can I be banned from using this trainer ?
R. No way! And I doubt if OVERKILL will care to add some kind of banning system. Currently you can be visually marked on client's or server's side if you spawn illegal equipments from server and client side or illegal bags from client side. Though in next big update, they will mark you for having DLC item/heist without actually owning it.

A. I have CHEATER tag above my name, I didn't used cheats. Will you ever fix this ?
为什么我会头顶红马甲。但是我没用任何作弊功能，怎么办
R. Recently OVERKILL added code to verify ownership of DLCs. In case you have some DLC item from DLC you don't own, host will see CHEATER tag above your name and also you maybe automatically kicked, if server choosed to do so. Though it is applicable that you used some cheat randomly.
OK社在某次更新加入了新的检测方式，只要你使用没购买的DLC的物品，你就会被顶上红马甲，只要主机打开自动踢出功能，你也可能会被踢出游戏
We currently trying our best at fixing this issue. If we'll manage to get something working it will probably appear only for premium/donor users, but not sure if we'll ever succeed.
我们会尝试用各种办法解决这个问题，虽然希望不大，但是我们会竭尽全力

This is list of things these will give you cheater tag for game session/kick you outta game if you're client (if server choosed to do so):
以下列表是会使你穿上红马甲的行为，进而有可能会被自动踢出房间（假如主机开启了自动踢人选项）

From client side:
你不是主机下会导致红名的行为

	-> Spawning equipment, different from last equipment you spawned.
	-> Throwing more, than allowed amount of grenades. (Picking up grenade from grenades crate case increases limit)
	-> Spawning more than allowed amount of equipments.
	-> Attempting to secure bag different from what you currently carring. (When you secure bag, host suspects that you no longer have any bags)
	-> Attempting to spawn bag different from what you currently carring. (When you drop any bag, host suspects that you no longer have any bags)
	-> Wearing item from DLC you don't own (The most common way of being detected)

From server side:
你是主机下会导致红名的行为：

	-> Spawning equipment, different from last equipment you spawned.
	-> Throwing more, than allowed amount of grenades. (Picking up grenade from grenades crate case increases limit)
	-> Spawning more than allowed amount of equipments.
	-> Wearing item or hosting heist from DLC you don't own (The most common way of being detected)

Credits:
DLL Hook: ThisJazzman (https://bitbucket.org/SoulHipHop/underground-light-lua-hook)
Main Development: Simplity, baldwin, v00d00, ThisJazzman
Separate scripts development: Harfatus, OJSimpson (dlc unlocker), Transcend
Also thanks to: KIU_Stinger, folks who tested night versions and some people, these wished to remain annonymous

DISCLAIMER:

Though it's impropable that your account will ever be banned for using this trainer, we take no responsibility for any ban, corrupted game files, not limited to save files, game content(bundle files); We also take no responsibility in the way you chose to use this software and results caused by it, use at your own risk and be nice to others.
If we forget to credit someone, we're really sorry for that (wasn't on purpose), please let us know about it and you will be credited in next release!