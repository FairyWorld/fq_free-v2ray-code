Pirate Perfection Reborn

Trainer for PAYDAY 2 remade from white list with a fresh new structure and less bugs than in previous versions. Some scripts were improved, some got lost from original Pirate Perfection, but are slowly being reintroduced.

Enjoy cheating pirates :-)

If you have any troubles, please report bugs here through our forum support
https://www.pirateperfection.com/support/

Version: v1

REGULAR USERS
- Noclip speed
- No rpg delay
- Fixed bag all corpses
- Added spawn forkflift and enemy/friendly turret
- Increase amount of hostile units
- Favorites menu in props menu
- Spoof Detection Level
- Receive 50% damage
- Reduce AI hitpoints to 1%
- Spawn cloaker behind teammate
- Fixed vault door open/close
- Added music menu
- I Want that menu by Davy Jones
- Allskins unlocker
- New spawnable units
DONORS
- Teleport player to self
- Teleport team to self
- Slap player
- Slap team
- Invisible spooks/cloakers
- 100% decapitation chance
- Launch players car into the air
- Remove Getaway Van
- Secret skills menu by  Davy Jones
- Troll drill by King Nothing
- Reduce player damage
- Reduce team damage
PREMIUMS
- Sequencer Menu
- Spoof name

Version: v0.99

Featuring:

- Crosshair added
- Superman MOD converted to true NoClip 
- Driver2 - Spawn vehicles and drive them (on maps that allows it)
- Exploding Domino cops
- Spawn turret
- Premium option fixed
- New units in spawn menu
- DLC unlocker fixed
- Set cops on fire
- Change sentry gun ammunition (grenades, molotovs or rockets)
- Bugfixes galore ( autocooker,choose engine, xray, interaction menu,waypoints,anti anti cheat,skills/infamy reset,unlock all perks,add perks points,troll menu, spawn bags, rain bags)
 
- PVP ( Kill your teammates mod)
- Enhanced billboard on Harvest and trustee maps
- Choppy mod (Yea the heli is back)
- Wavehouse (safehouse minigame)
- Updated the infamy menu upping max to 25
- Bugfixes

Version: v0.97a

Featuring:

- DLC Unlocker (Why do we need to bother buying all dlcs ? Get them for free here!)
- Stealth cheats (Everything you need to make your stealth heist successfull)
- Character cheats (Common cheats like godmode, infinite ammo and etc.)
- Inventory cheats (Spawn extra bags or rain them to make your day)
- Interaction cheats (Instantly interact with common things or improve your interaction with things at all)
- Freeflight (Wonderfull for movie making)
- Autostart cheats (If you don't want to manually turn on some of them)
- Spawn menu (Spawn enemies and props for fun)
- Xray (A.k.a. wallhack)
- Equipment cheats (Do you want your sentry shoot grenades ? Go here!)
- Slowmotion (whyyyy soooo sloooooooow ?)
- Lego (Build your own castle)
- Some anti-noob protections (It will display warning whenever you're close to get marked as cheater)
- Anticheat disabler (Let other people cheat on your server too)
- Easy configuration (Do you want to turn on various cheats on game start or tweak some ? Now it is easy!)
- Abillity to localizate trainer or use already done localizations
- And many more ...

Keys:
5 - Equipment spawn menu
6 - Place prop
7 - Switch to previous prop
8 - Switch to next prop

Numpad 1 - Character menu in game/Inventory cheats in menu
Numpad 2 - Job menu/Stealth menu
Numpad 3 - Spawn menu
Numpad 4 - Troll menu (Donor's or higher have full version)
Numpad 5 - Interaction menu
Numpad 6 - Inventory menu (Bags and in game money related menu)
Numpad 7 - Weapon list
Numpad 8 - Equipment menu
Numpad 9 - Mission menu
Numpad + - Pregame menu

END - Instant win
HOME - Normalizer

F1 - Help menu
F2 - Mod menu
F4 - Carry stacker (frequently tap it in order to drop all stored bags)
F5 - User script
F6 - Configuration menu

Z - Replenish all ammo and health, restore standard state
X - Xray

Middle Mouse Button - Teleport
X7 Extra Button 1 - Slowmotion

Mods control:
	Superman mod: Page Up - Fly up.
		      Page Down - Fly down.
				  
	Driver mod:   arrow left/right/up/down - Move left/right/up/down.
	
	Lego mod:     Page Up - Place lego.
		      Page Down - Remove lego.

Installation:

If you had Pirate Perfection v16 and a lower installed earlier, remove it first.
Extract the content of the rar file you download at our website into the Payday 2 game directory (usually located at /Program Files (x86)/Steam/steamapps/common/PAYDAY 2)
Don't forget to customize the trainer to your taste, the trainer comes with a lot of extra options you can easily enable/disable in config.lua with notepad.

(+) - Addition
(*) - Fix

Version story:
v0.97a
(*) Synced underground light hook with latest changes.
(*) Greatly improved lego mod. Now you can place more props on map, place them using binded key and even quickswitch between them using same binds.
(*) Configs structure updated, so now config related problems are easier to detect. Update all your configs with current structure, including config.lua, key configs, game configs.
(*) Announcements, update checker and version checker are working again.
(*) restart_pro_missions.lua updated
(*) Fixed bug, where cheat control got unloaded for game session, when game configs were switched or game was normalized.
(*) Localizator changes, preparation for upcoming changes related to localizations.
(*) Added menu, where you can configure waypoints filter. (For show waypoints in mission menu)
(*) Autocooker improved, so now it doesn't require "Interact with all" to be enabled in order to properly work.
(+) Added shut down dialogs (can be found in mission menu)
(*) Probably fixed issue, where convert all stopped converting others, when it failed to convert atleast 1 enemy.
(+) Added "Secure All" script. Now you can secure any type of bag in special zones for that.
(*) Improvements in xray
(*) New interactions were added in interaction menu
(*) General improvements with scripts, so now trainer do less queries to disk for some trainer scripts.

v0.96i
(+) Moved trainer to new hook
(*) Fixed props sub menu in spawn menu not opening
(*) Improved text input and multi choice elements. Now you can hold key in text input to remove text and move carret; in multi choice you can use arrows to select some item.
(+) Added abillity to change permission and kick settings in job menu.

v0.95
(*) Now secure bags chooses the most expensive bag automatically
(*) Fixed equipments not being binded on alt. click in equipment menu
(*) Bag throw multiplier can be changed in config
(*) Fixed normalizer, so now it restores and reboots properly
(*) Updated drop-in pause script (more proof to updates, show join status in chat)
(*) Applied some optimisations, where they needed
(*) Slowmotion updated (you gonna like it)
(*) Fixed aimbot targeting some friendly units
(*) Fixed crash in spawn menu
(*) Fixed infinite cable ties not working
(*) Fixed description issues in custom menu
(*) Updated lasecolor.lua (Noob proofed in general)
(*) Updated some descriptions in config.lua
(*) Fixed issue, where game could crash, if some plugin in opened menu isn't found
(-) Removed headshot sounds, trainer size greatly decreased
(*) Reworked disable_anticheat.lua
(*) Fixed Job Menu's glitch with permissions
(*) Remade equipment control. Turned into plugin and much better code.
(*) A lot of work with the trainer's scripts
(*) Improved First launch and Crash Noticer messaging logic a bit.

(+) Added multiple configs feature. Currently you can create/rename/delete configs, save your active cheats to some config and change them on fly.
(+) Added script, that remove delays between melee attacks (can be found in Character menu)
(+) Added menu, from where you can load user plugins (located in trainer/plugins). Menu located in trainer/menu/custom_plugins.lua. Bind it in keyconfig or use pp_dofile in your custom script. This is experimental feature.
(+) Added plugin "Noone shall down". (Can be found in interaction menu)
(+) Added new interactions to interaction menu.
(+) Added check to menus, so if some plugin isn't found, button for this plugin will not be visible.
(+) Added escapes to Job menu
(+) Added grenade shooting weapon
(+) Added change armor and melee weapon
(+) Added new units to spawn menu

v0.91
->Added unlock/lock all perks.
->Added unlock old hoxton script.
->Added new units to spawn menu.
->Added revive all players and open all doors to interaction menu, also added new interactions.
->Added possibility to choose a heist day in job menu.
->Added equipment spawn menu.

->*Updated troll menu.
->Improved xray.
->Fixed instant intimidation.
->Fixed correct engine menu.
->Fixed weapon menu.
->Fixed driver.
->Updated inventory menu.
->Improved AimBot (It's no longer refill your health, refill ammo as option, also you can choose damage).
And some other fixes.

v0.9
->Added unlock skill tiers.
->Added text input.
->Added fix for miami dlc.
->Added remove exclamation mark.
->Added use all perks.
->Added option to add perk points.

->Fixed interaction menu.
->Fixed instant interaction.
->Fixed spawn menu and added new units to it.
->Improved shoot through walls script.

v0.85

Added:
-> Added new menu.
-> Added equipment changer.
-> Added spawn on random spawn position to spawn menu.
-> Added crazy firerate to grenade launcher.
-> Added key config option in main config.
-> Added multi choice to menu.

Updated:
-> Weapon mods in all items menu sorted by categories.
-> Updated main menu.
-> Updated spawn menu.
-> Updated weapon menu.
-> Improved menu slider.
-> Fixed inventory menu.
-> Fixed and updated job menu.

v0.8
Added:
-> Added lock all achievements.
-> Added tie all civilians.
-> Added script to make player invisible for AI.
-> Added change FOV on mouse scroll.
-> Added increase bag throw force.
-> Added make all bags explosive.
-> Added no penalty movement with bag.
-> Added experimental menu to character and inventory menu.

Updated:
-> Updated troll menu.
-> Updated trainer structure.
-> Fixed lobotomize AI.
-> Fixed bug with F2 button.

And other fixes and changes.

v0.7
Added:
-> Reduce detection level.
-> Correct engine menu.
-> Convert all.
-> Instantly charge melee weapon.
-> Host check to some scripts.
-> Remove limit of installed modifications.
-> Option to choose weapon from inventory.
-> Included unlimited saw ammo to unlimited weapon ammo

Updated:
-> Upgraded inventory menu.
-> Updated waypoints.
-> Fixed crash with laser color.
-> Fixed instant intimidation crashes
-> Fixed no fall damage, now it works as intended.
-> Fixed lobotomize all ai.
-> Removed old menu pp_require from some scripts, now conflicts should gone
-> pp_dofile() shoudn't cause crashes, if file wasn't found
-> Updated error messages around, they should be more detail now.

And other changes.

v0.6
Added:
-> New translations made by community
-> Returned open all ATMs.
-> Returned instant intimidation.
-> Returned Anti-kicky name.
-> Returned instant deployment.
-> Returned weapon instant kill
-> Returned very cutted troll menu version for public release

Updated:
-> Trainer structure updated
-> Xray marks friendly units properly now
-> Modified menu.
-> Troll menu updated.
-> Added save settings option.
-> Fixed some bugs.

And other changes, these we didn't log

F.A.Q.

A. My DLC items locked again/DLC unlocker isn't working/DLCs aren't working, what to do ?
R. Look into config.lua and set DLCUnlocker to true. (DLCUnlocker = true)
We disabled it by default, because it causes kicks/cheater tags for using DLC item you don't own (see colored list below for more information)

A. Why achievements are not working ?
R. Because stats synchronisation disabled by default, you can enable in config.lua by changing NoStatsSynced = true to NoStatsSynced = false Just make sure you will set your profile visibility from public to other.

A. Name spoofing broken, fix it!
R. Name spoofing is fixed for premium members as of version 1

A. My game crashes with error "Engine stopped working" after I installed trainer. How to fix it ?
R. In 99% of cases that means you installed trainer wrong or have other mods installed, like Hoxhud. Try to reinstall trainer properly and everything should work fine. If you're 100% sure that you installed trainer properly, then you can create new topic in "Support" forum section and we'll try our best to help you.

A. I've installed trainer, but nothing works or shows up, what I have to do?
R. To repeat, trainer will not work on Windows XP.
Uninstall old versions of Pirate Perfection (applies only to those, who still have v16), uninstall other lua mods/trainers. Make sure you unpacked everything from release/donor folder to main game folder. Also delete file called "PD2APIDLL1.dll".

A. How to enable *some option* ?
R. Checkout config.lua and explore menus.

A. NVAPI error in dll hook, how to fix it ?
R. Try to run game as Administrator

A. Do trainer have *some feature* ?
R. Maybe we will write full list of what trainer can do, but why not to explore it yourself ? ;)

A. Can I be banned from using this trainer ?
R. No way! And I doubt if OVERKILL will care to add some kind of banning system. Currently you can be visually marked on client's or server's side if you spawn illegal equipments from server and client side or illegal bags from client side. Though in next big update, they will mark you for having DLC item/heist without actually owning it.

A. I have CHEATER tag above my name, I didn't used cheats. Will you ever fix this ?
R. Recently OVERKILL added code to verify ownership of DLCs. In case you have some DLC item from DLC you don't own, host will see CHEATER tag above your name and also you maybe automatically kicked, if server choosed to do so. Though it is applicable that you used some cheat randomly.
We currently trying our best at fixing this issue. If we'll manage to get something working it will probably appear only for premium/donor users, but not sure if we'll ever succeed.

This is list of things these will give you cheater tag for game session/kick you outta game if you're client (if server choosed to do so):

From client side:

	-> Spawning equipment, different from last equipment you spawned.
	-> Throwing more, than allowed amount of grenades. (Picking up grenade from grenades crate case increases limit)
	-> Spawning more than allowed amount of equipments.
	-> Attempting to secure bag different from what you currently carring. (When you secure bag, host suspects that you no longer have any bags)
	-> Attempting to spawn bag different from what you currently carring. (When you drop any bag, host suspects that you no longer have any bags)
	-> Wearing item from DLC you don't own (The most common way of being detected)

From server side:

	-> Spawning equipment, different from last equipment you spawned.
	-> Throwing more, than allowed amount of grenades. (Picking up grenade from grenades crate case increases limit)
	-> Spawning more than allowed amount of equipments.
	-> Wearing item or hosting heist from DLC you don't own (The most common way of being detected)

Credits:
DLL Hook: ThisJazzman (https://bitbucket.org/SoulHipHop/underground-light-lua-hook)
Main Development: Simplity, baldwin, v00d00, ThisJazzman
Separate scripts development: Harfatus, OJSimpson (dlc unlocker), Transcend
Also thanks to: KIU_Stinger, folks who tested night versions and some people, these wished to remain annonymous

DISCLAIMER:

Though it's impropable that your account will ever be banned for using this trainer, we take no responsibility for any ban, corrupted game files, not limited to save files, game content(bundle files); We also take no responsibility in the way you chose to use this software and results caused by it, use at your own risk and be nice to others.
If we forget to credit someone, we're really sorry for that (wasn't on purpose), please let us know about it and you will be credited in next release!