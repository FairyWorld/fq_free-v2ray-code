return function( cfg )
	cfg.instant_interaction=true
	cfg.no_recoil=true
	cfg.god_mode=true
	cfg.infinite_ammo=true
	cfg.no_headbob=true
	cfg.max_accurate=true
end
