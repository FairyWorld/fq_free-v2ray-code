backuper:backup('MenuCallbackHandler.singleplayer_restart')
function MenuCallbackHandler.singleplayer_restart() 
	return true 
end