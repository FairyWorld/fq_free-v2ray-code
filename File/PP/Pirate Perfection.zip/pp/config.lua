return function( cfg )
end
