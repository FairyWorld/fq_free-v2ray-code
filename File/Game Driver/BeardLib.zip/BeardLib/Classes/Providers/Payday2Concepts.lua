ModAssetsModule._providers.payday2concepts = {}
local pd2c = ModAssetsModule._providers.payday2concepts
pd2c.version_api_url = "http://payday2maps.net/crimenet/checkversion/$id$.txt"
pd2c.download_url = "http://payday2maps.net/crimenet/downloads/$id$.zip"
pd2c.version_is_number = true