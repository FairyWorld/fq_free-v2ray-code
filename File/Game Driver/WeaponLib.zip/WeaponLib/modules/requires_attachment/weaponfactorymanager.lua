function WeaponFactoryManager:change_part_blueprint_only(factory_id, part_id, blueprint, remove_part)
	local factory = tweak_data.weapon.factory
	local part = factory.parts[part_id]

	if not part then
		Application:error("WeaponFactoryManager:change_part Part", part_id, " doesn't exist!")

		return false
	end

	local type = part.type

	if remove_part then
		table.delete(blueprint, part_id)

		local forbidden = WeaponFactoryManager:_get_forbidden_parts(factory_id, blueprint) or {}

		for _, rem_id in ipairs(blueprint) do
			if forbidden[rem_id] then
				table.delete(blueprint, rem_id)

				local default_blueprint = self:get_default_blueprint_by_factory_id(factory_id)
				for _, add_id in ipairs(default_blueprint) do
					if ( not table.contains(forbidden, add_id) ) and ( factory.parts[add_id].type == factory.parts[rem_id].type ) then
						if not table.contains(blueprint, add_id) then
							table.insert(blueprint, add_id)
						end
					end
				end
			end
		end
	elseif self._parts_by_weapon[factory_id][type] then
		if table.contains(self._parts_by_weapon[factory_id][type], part_id) then
			for _, rem_id in ipairs(blueprint) do
				if factory.parts[rem_id].type == type then
					table.delete(blueprint, rem_id)

					break
				end
			end

			table.insert(blueprint, part_id)

			local forbidden = WeaponFactoryManager:_get_forbidden_parts(factory_id, blueprint) or {}

			for _, rem_id in ipairs(blueprint) do
				if forbidden[rem_id] then
					table.delete(blueprint, rem_id)

					local default_blueprint = self:get_default_blueprint_by_factory_id(factory_id)
					for _, add_id in ipairs(default_blueprint) do
						if ( not table.contains(forbidden, add_id) ) and ( factory.parts[add_id].type == factory.parts[rem_id].type ) then
							if not table.contains(blueprint, add_id) then
								table.insert(blueprint, add_id)
							end
						end
					end
				end
			end

			return true
		end
	end

	return false
end

function WeaponFactoryManager:_get_forbidden_parts(factory_id, blueprint)
	local factory = tweak_data.weapon.factory
	local forbidden = {}
	local override = self:_get_override_parts(factory_id, blueprint)

	for _, part_id in ipairs(blueprint) do
		local part = self:_part_data(part_id, factory_id, override)

		local filtered_requires = {}

		if part.requires then
			for _, part_id in pairs(part.requires) do
				if table.contains(factory[factory_id].uses_parts, part_id) then
					table.insert(filtered_requires, part_id)
				end
			end
		end

		if part.depends_on or #filtered_requires > 0 then
			local part_forbidden = true

			for _, other_part_id in ipairs(blueprint) do
				local other_part = self:_part_data(other_part_id, factory_id, override)

				if part.depends_on and (part.depends_on == other_part.type) then
					part_forbidden = false

					break
				end

				if #filtered_requires > 0 and table.contains(filtered_requires, other_part_id) then
					part_forbidden = false

					break
				end
			end

			if part_forbidden == false then
				for _, other_part_id in ipairs(blueprint) do
					local other_part = self:_part_data(other_part_id, factory_id, override)

					if other_part.forbids and table.contains( other_part.forbids, part_id ) then part_forbidden = true break end
				end
			end

			if part_forbidden then
				forbidden[part_id] = part.depends_on or filtered_requires	
			end
		end

		if part.forbids then
			for _, forbidden_id in ipairs(part.forbids) do
				forbidden[forbidden_id] = forbidden[forbidden_id] or part_id
			end
		end

		if part.adds then
			local add_forbidden = self:_get_forbidden_parts(factory_id, part.adds)

			for forbidden_id, part_id in pairs(add_forbidden) do
				forbidden[forbidden_id] = forbidden[forbidden_id] or part_id
			end
		end
	end

	return forbidden
end