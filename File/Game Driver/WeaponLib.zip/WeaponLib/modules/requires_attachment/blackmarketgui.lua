local vowels = { "a", "e", "i", "o", "u" }
local part_td = tweak_data.weapon.factory.parts

local function get_forbids(weapon_id, part_id)
	local weapon_data = tweak_data.weapon.factory[weapon_id]

	if not weapon_data then
		return {}
	end

	local default_parts = {}

	for _, part in ipairs(weapon_data.default_blueprint) do
		table.insert(default_parts, part)

		local part_data = part_td[part]

		if part_data and part_data.adds then
			for _, part in ipairs(part_data.adds) do
				table.insert(default_parts, part)
			end
		end
	end

	local weapon_mods = {}

	for _, part in ipairs(weapon_data.uses_parts) do
		if not table.contains(default_parts, part) then
			local part_data = part_td[part]

			if part_data and not part_data.unatainable then
				weapon_mods[part] = {}
			end
		end
	end

	for part, _ in pairs(weapon_mods) do
		local part_data = part_td[part]

		if part_data.forbids then
			for other_part, _ in pairs(weapon_mods) do
				local other_part_data = part_td[part]

				if table.contains(part_data.forbids, other_part) then
					if not table.contains(weapon_mods[part], other_part) then
						table.insert(weapon_mods[part], other_part)
					end


					if not table.contains(weapon_mods[other_part], part) then
						table.insert(weapon_mods[other_part], part)
					end
				end
			end
		end
	end

	return weapon_mods[part_id]
end

Hooks:PostHook( BlackMarketGui, "update_info_text", "RequiresAttachment_update_info_text", function(self)
	local slot_data = self._slot_data
	local tab_data = self._tabs[self._selected]._data
	local prev_data = tab_data.prev_node_data
	local identifier = tab_data.identifier

	if identifier == self.identifiers.weapon_mod then
		local output_text_other = nil

		local weapon_id = managers.weapon_factory:get_factory_id_by_weapon_id(prev_data.name)
		local weapon_data = tweak_data.weapon.factory[weapon_id]

		if slot_data.conflict then
			local forbid = managers.blackmarket:can_modify_weapon(slot_data.category, slot_data.slot, slot_data.name)
			local output_text = nil
			output_text_other = ""

			if type(forbid) == "table" then
				output_text = "     " .. managers.localization:to_upper_text("bm_menu_requires")

				local forbid_count = #forbid
				for index, part_id in ipairs(forbid) do
					if table.contains(weapon_data.uses_parts or {}, part_id) then
						local name_id = part_td[part_id].name_id or "fail"
						local localised = managers.localization:to_upper_text(name_id)

						local seperator = ","
						if index == forbid_count - 1 then
							seperator = ", " .. managers.localization:to_upper_text("bm_menu_or")
						elseif index == forbid_count then
							seperator = "!"
						end

						output_text = output_text .. " " .. localised .. seperator
					end
				end
			else
				if not part_td[forbid] then
					output_text = "     " .. managers.localization:to_upper_text("bm_menu_requires")

					local name_id = "bm_menu_" .. tostring(forbid)
					local localised = managers.localization:to_upper_text(name_id)

					if table.contains( vowels, string.lower(string.sub(localised, 1, 1)) ) then
						localised = managers.localization:to_upper_text("bm_menu_an") .. " " .. localised
					else
						localised = managers.localization:to_upper_text("bm_menu_a") .. " " .. localised
					end

					output_text = output_text .. " " .. localised .. "!"
				end
			end

			if output_text then
				self:set_info_text(3, output_text)

				local info_text = self._info_texts[3]
				local _, _, _, th = info_text:text_rect()
				info_text:set_h(th)
			end
		end

		if not ( slot_data.removes and #slot_data.removes > 0 ) then
			local forbidden_parts = get_forbids( weapon_id, slot_data.name )
			local droppable_mods = managers.blackmarket:get_dropable_mods_by_weapon_id(prev_data.name)

			if forbidden_parts and #forbidden_parts > 0 then
				local free_spaces = 3
				local forbids = {}

				for i, forbidden_part in ipairs(forbidden_parts) do
					local data = part_td[forbidden_part]

					if data then
						forbids[data.type] = (forbids[data.type] or 0) + 1
					end
				end

				for category, _ in pairs(forbids) do
					if not droppable_mods[category] then
						forbids[category] = nil
					end
				end
				
				local size = table.size(forbids)

				local categories = {}
				local parts = {}

				for category, amount in pairs(forbids) do
					local category_count = 0

					for _, part_name in ipairs(weapon_data.uses_parts) do
						local part_data = part_td[part_name]

						if part_data and not part_data.unatainable and part_data.type == category and not table.contains(weapon_data.default_blueprint, part_name) then
							category_count = category_count + 1
						end
					end

					if ( amount > free_spaces ) or ( size >= free_spaces ) then
						local percent_forbidden = amount / category_count
						local localised_category = managers.localization:to_upper_text("bm_menu_" .. tostring(category) .. "_plural")
						local quantifier = ( ( percent_forbidden == 1 ) and "all" ) or ( ( percent_forbidden > 0.66 ) and "most" ) or ( ( percent_forbidden > 0.33 ) and "few" ) or "some"
						quantifier = managers.localization:to_upper_text("bm_mod_incompatibility_" .. tostring(quantifier))

						if amount == 1 then
							localised_category = managers.localization:to_upper_text("bm_menu_" .. tostring(category))
							if table.contains( vowels, string.lower(string.sub(localised_category, 1, 1)) ) then
								quantifier = managers.localization:to_upper_text("bm_menu_an")
							else
								quantifier = managers.localization:to_upper_text("bm_menu_a")
							end
						end

						local specific_quantifier = false
						if specific_quantifier then
							quantifier = tostring(amount)
						end

						table.insert(categories,{
							category = localised_category,
							quantifier = quantifier
						})

						free_spaces = free_spaces - 1
					else
						for index, part_id in ipairs(forbidden_parts) do
							local part_category = part_td[part_id].type
							if part_category == category then
								table.insert(parts, managers.localization:to_upper_text(part_td[part_id].name_id or "bm_w_" .. part_id))
							end
						end

						free_spaces = free_spaces - 1
					end
				end

				local output_text_other = managers.localization:to_upper_text("bm_menu_incompatiblity")
				local total_amount = #parts + #categories
				local index = 1

				for _, part_name in ipairs(parts) do
					local seperator = ","
					if index == total_amount - 1 then
						seperator = ", " .. managers.localization:to_upper_text("bm_menu_and")
					elseif index == total_amount then
						seperator = "!"
					end

					output_text_other = output_text_other .. " " .. part_name .. seperator

					index = index + 1
				end

				for _, category_info in ipairs(categories) do
					local seperator = ","
					if index == total_amount - 1 then
						seperator = ", " .. managers.localization:to_upper_text("bm_menu_and")
					elseif index == total_amount then
						seperator = "!"
					end

					output_text_other = output_text_other .. " " .. category_info.quantifier .. " " .. category_info.category .. seperator

					index = index + 1
				end

				self:set_info_text(5, output_text_other)

				local info_text = self._info_texts[5]
				local _, _, _, th = info_text:text_rect()
				info_text:set_h(th)
			end
		end
	end
end)