Hooks:PostHook( PlayerStandard, "enter", "CustomScopeEffect_StateEnter", function(self)
	self:_update_steelsight_color_grading()
end)

Hooks:PostHook( PlayerStandard, "_start_action_equip_weapon", "CustomScopeEffect_WeaponSwitch", function(self)
	self:_update_steelsight_color_grading()
end)

Hooks:PostHook( PlayerStandard, "_steelsight_on_end", "CustomScopeEffect_SteelsightOn", function(self)
	local weap_base = self._ext_inventory:equipped_unit():base()

	if weap_base and weap_base:is_second_sight_on() then
		self:_set_colour_grading( self._state_data._second_sight_colour_grading )
	else
		self:_set_colour_grading( self._state_data._sight_colour_grading )
	end
end)

Hooks:PostHook( PlayerStandard, "_steelsight_off_start", "CustomScopeEffect_SteelsightOff", function(self)
	self:_set_colour_grading( false )
end)

Hooks:PostHook( PlayerStandard, "_toggle_second_sight", "CustomScopeEffect_ToggleSecondSight", function(self, second_sight_on)
	if self:in_steelsight() then
		if second_sight_on then
			self:_set_colour_grading( self._state_data._second_sight_colour_grading )
		else
			self:_set_colour_grading( self._state_data._sight_colour_grading )
		end
	end
end)

function PlayerStandard:_update_steelsight_color_grading()
	local weapon = self._equipped_unit:base()

	for index, part_id in ipairs(weapon._blueprint) do
		local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon(part_id, weapon._factory_id, weapon._blueprint)

		if part_data.scope_effect then
			if ( part_data.type and ( part_data.type == "sight" ) ) then
				self._state_data._sight_colour_grading = part_data.scope_effect
			elseif ( part_data.sub_type and ( part_data.sub_type == "second_sight" ) ) then
				self._state_data._second_sight_colour_grading = part_data.scope_effect
			end
		end
	end
end

function PlayerStandard:_set_colour_grading( colour_grading_value )
	if not managers.environment_controller then return end

	local ignore_user_setting = not not colour_grading_value
	if ( colour_grading_value == false ) then
		colour_grading_value = managers.environment_controller:game_default_color_grading()
	end

	managers.environment_controller:set_default_color_grading(colour_grading_value, ignore_user_setting)
	managers.environment_controller:refresh_render_settings()
end