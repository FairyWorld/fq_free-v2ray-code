ContourExt._types.mark_infrared = {
	priority = 1,
	fadeout = 0,
	material_swap_required = true,
	color = Vector3(0.5, 0.5, 1)
}