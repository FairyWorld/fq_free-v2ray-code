Hooks:PostHook( NewRaycastWeaponBase, "_update_stats_values", "InfraredHighlighting__update_stats_values", function( self, disallow_replenish )
	self._can_infrared_highlight = managers.weapon_factory:has_perk("infrared", self._factory_id, self._blueprint)
end)

local slot_mask = World:make_slot_mask(2, 3, 4, 5, 12, 16, 17, 21, 22, 24, 25, 33, 34)
function NewRaycastWeaponBase:check_infrared_highlight( from, forward )
	if not self._can_infrared_highlight then
		return
	end

	local range = 4000
	local to = from + ( forward * range )

	local bodies = World:find_bodies("intersect", "cylinder", from, to, 1500, slot_mask)
	for i, hit in ipairs(bodies) do
		if alive(hit) then
			local unit = hit:unit()
			local key = unit:key()
			
			if unit and alive(unit) and unit:character_damage() and ( not unit:character_damage()._dead ) and unit.contour and unit:contour() then
				unit:contour():add("mark_infrared", false, 0)
				unit:contour():_upd_opacity(1)
			end
		end
	end
end