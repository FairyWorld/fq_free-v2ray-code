Hooks:PostHook( PlayerStandard, "_update_fwd_ray", "InfraredHighlighting__update_fwd_ray", function(self)
	if alive(self._equipped_unit) then
		if self:fully_scoped() and self._equipped_unit:base().check_infrared_highlight and not self._equipped_unit:base():is_second_sight_on() then
			local from = self._unit:movement():m_head_pos()

			self._equipped_unit:base():check_infrared_highlight(from, self._cam_fwd)
		end
	end
end)