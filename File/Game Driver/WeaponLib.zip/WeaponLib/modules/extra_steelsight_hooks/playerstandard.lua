Hooks:PostHook(PlayerStandard, "init", "_ExtraSteelsightHooks_Init", function(self)
	self._state_data._in_steelsight_last = false
	self._state_data._in_secondsight_last = false

	self._state_data._fully_scoped = false

	self._state_data._steelsight_anim_started = false
	self._state_data._steelsight_anim_complete = true
end)

Hooks:PostHook( PlayerStandard, "enter", "_ExtraSteelsightHook_StateEnter", function(self)
	local weapon = self._equipped_unit:base()

	self._last_equipped_fix = self._equipped_unit
	self._just_switched_weapon = false
end)

--Hook to stop overkill doing retarded shit.
Hooks:PreHook(PlayerStandard, "update", "_ExtraSteelsightHooks_Pre_Update", function(self, t, dt)
	if self._last_equipped_fix then
		if self._last_equipped_fix ~= self._equipped_unit then
			self._last_equipped_fix = self._equipped_unit
			
			self._just_switched_weapon = true
			self._equipped_visibility_timer = t + 0.1
		end

		if self._just_switched_weapon and self._equipped_visibility_timer and self._equipped_visibility_timer < t and alive(self._equipped_unit) then
			self._equipped_unit:base():set_visibility_state(true)
			self._just_switched_weapon = false
		end
	end

	self._last_equipped = nil
end)

Hooks:PostHook(PlayerStandard, "_check_action_steelsight", "_ExtraSteelsightHooks_SteelsightCheck", function(self)
	if self:in_steelsight() == nil then return end

	if self._state_data._in_steelsight_last ~= self:in_steelsight() then
		self._state_data._in_steelsight_last = self:in_steelsight()		

		self._state_data._steelsight_anim_started = true
	end

	local weapon = self._equipped_unit:base()

	if self._state_data._in_secondsight_last ~= weapon:is_second_sight_on() then
		self._state_data._in_secondsight_last = weapon:is_second_sight_on()

		self:_toggle_second_sight( weapon:is_second_sight_on() )
	end

	if self._state_data._steelsight_anim_started == false then return end

	if not self._camera_unit then return end
	if not self._camera_unit:base() then return end
	if self._camera_unit:base():is_stance_done() == nil then return end

	local stance_done = self._camera_unit:base():is_stance_done()

	if self._state_data._steelsight_anim_complete ~= stance_done then
		self._state_data._steelsight_anim_complete = stance_done	

		if not self._state_data._steelsight_anim_complete then
			if self:in_steelsight() then
				self:_steelsight_on_start()
			else
				self._state_data._fully_scoped = false
				self:_steelsight_off_start()
			end
		else
			self._state_data._steelsight_anim_started = false

			if self:in_steelsight() then
				self._state_data._fully_scoped = true
				self:_steelsight_on_end()
			else
				self:_steelsight_off_end()
			end
		end
	end
end)

function PlayerStandard:fully_scoped() return self._state_data._fully_scoped end

function PlayerStandard:_steelsight_on_start() end
function PlayerStandard:_steelsight_on_end() end
	
function PlayerStandard:_steelsight_off_start() end
function PlayerStandard:_steelsight_off_end() end

function PlayerStandard:_toggle_second_sight( second_sight_on ) end