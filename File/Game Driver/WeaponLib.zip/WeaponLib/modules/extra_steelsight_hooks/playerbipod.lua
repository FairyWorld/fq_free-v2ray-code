Hooks:PostHook(PlayerBipod, "_update_check_actions", "_ExtraSteelsightHooks_Bipod_SteelsightCheck", function(self)
	if self:in_steelsight() == nil then return end

	if self._state_data._in_steelsight_last ~= self:in_steelsight() then
		self._state_data._in_steelsight_last = self:in_steelsight()		

		self._state_data._steelsight_anim_started = true
	end

	local weapon = self._equipped_unit:base()

	if self._state_data._in_secondsight_last ~= weapon:is_second_sight_on() then
		self._state_data._in_secondsight_last = weapon:is_second_sight_on()

		self:_toggle_second_sight( weapon:is_second_sight_on() )
	end

	if self._state_data._steelsight_anim_started == false then return end

	if not self._camera_unit then return end
	if not self._camera_unit:base() then return end
	if self._camera_unit:base():is_stance_done() == nil then return end

	local stance_done = self._camera_unit:base():is_stance_done()

	if self._state_data._steelsight_anim_complete ~= stance_done then
		self._state_data._steelsight_anim_complete = stance_done	

		if not self._state_data._steelsight_anim_complete then
			if self:in_steelsight() then
				self:_steelsight_on_start()
			else
				self._state_data._fully_scoped = false
				self:_steelsight_off_start()
			end
		else
			self._state_data._steelsight_anim_started = false

			if self:in_steelsight() then
				self._state_data._fully_scoped = true
				self:_steelsight_on_end()
			else
				self:_steelsight_off_end()
			end
		end
	end
end)