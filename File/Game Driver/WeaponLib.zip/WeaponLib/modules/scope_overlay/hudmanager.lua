ScopeOverlayGUI = ScopeOverlayGUI or class()

function ScopeOverlayGUI:init()
	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	local _ws = managers.hud._workspace

	self._panel = self._panel or hud and hud.panel or self._ws:panel({ name = "2DWeaponGUI" })

	self._scope_bitmap = self._panel:bitmap({
		name = "scope_bitmap",
		visible = false,
		valign = "bottom",
		layer = 0,
		color = Color.white
	})
end

function ScopeOverlayGUI:set_sights_visible( state )
	local player = managers.player:player_unit()
	local inventory = player:inventory()

	local unit = inventory:equipped_unit()
	if unit then
		local weapon = unit:base()

		if weapon._parts then
			local factory = tweak_data.weapon.factory

			for part_id, part in pairs(weapon._parts) do
				if ( factory.parts[part_id].type == "sight" ) or ( factory.parts[part_id].sub_type == "second_sight" ) then
					if part.unit and alive(part.unit) then
						part.unit:set_visible( state )
					end
				end
			end
		end
	end
end

function ScopeOverlayGUI:set_gun_visible( state )
	local player = managers.player:player_unit()
	local inventory = player:inventory()

	inventory:set_visibility_state(state)
	player:camera():camera_unit():set_visible(state)
end

function ScopeOverlayGUI:set( texture, hide_weapon )
	self._hide_weapon = hide_weapon

	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
	self._scope_bitmap:set_image( texture )

	local t_width = self._scope_bitmap:texture_width()
	local t_height = self._scope_bitmap:texture_height()
	local t_aspect_ratio = t_height/t_width

	local width = hud.panel:w()
	local height = hud.panel:h()
	local aspect_ratio = height/width

	if aspect_ratio < t_aspect_ratio then
		t_width = width
		t_height = width / t_aspect_ratio
	else
		t_height = height
		t_width = height / t_aspect_ratio
	end

	self._scope_bitmap:set_size( t_width, t_height )
	self._scope_bitmap:set_position( width/2 - t_width/2, height/2 - t_height/2 )
end

function ScopeOverlayGUI:hide()
	local player = managers.player:player_unit()

	self._visible = false
	self._scope_bitmap:set_visible(false)

	if ( player ) then
		self:set_gun_visible(true)
	end
end

function ScopeOverlayGUI:show()
	self._visible = true
	self._scope_bitmap:set_visible(true)

	if ( self._hide_weapon ) then
		self:set_gun_visible(false)
	else
		self:set_sights_visible(false)
	end
end

Hooks:PostHook(HUDManager, "init_finalize", "ScopeOverlayGUI", function(self)
	self._ScopeOverlayGUI = ScopeOverlayGUI:new()
end )