function BowWeaponBase:trigger_released(...)
	local fired = nil

	if self._charging and not self._cancelled and self:start_shooting_allowed() then
		fired = self:fire(...)

		if fired then
			self:play_tweak_data_sound(self:charge_fail() and "charge_release_fail" or "charge_release")

			local next_fire = (self:weapon_tweak_data().fire_mode_data and self:weapon_tweak_data().fire_mode_data.fire_rate or 0) / self:fire_rate_multiplier()
			self._next_fire_allowed = self._next_fire_allowed + next_fire
		end
	end

	self._charging = nil
	self._cancelled = nil

	return fired
end