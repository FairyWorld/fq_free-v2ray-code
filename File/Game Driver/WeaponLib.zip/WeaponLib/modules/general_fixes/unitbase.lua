function UnitBase:is_in_original_material()
	return false
end