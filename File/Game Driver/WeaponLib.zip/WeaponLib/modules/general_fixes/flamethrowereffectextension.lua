function FlamethrowerEffectExtension:setup_default()
	self._flame_effect = {
		effect = Idstring("effects/payday2/particles/explosions/flamethrower")
	}
	self._nozzle_effect = {
		effect = Idstring("effects/payday2/particles/explosions/flamethrower_nosel")
	}
	self._pilot_light = {
		effect = Idstring("effects/payday2/particles/explosions/flamethrower_pilot")
	}
	self._flame_max_range = self:weapon_tweak_data().flame_max_range
	self._single_flame_effect_duration = self:weapon_tweak_data().single_flame_effect_duration
	self._distance_to_gun_tip = 50
	self._flamethrower_effect_collection = {}
end