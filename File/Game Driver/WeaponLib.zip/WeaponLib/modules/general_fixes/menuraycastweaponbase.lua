function NewRaycastWeaponBase:init(unit)
	if NewRaycastWeaponBase.super then
		NewRaycastWeaponBase.super.init(self, unit)

		self._gadgets = {}
	end

	self._unit = unit
	self._name_id = self._name_id or self.name_id or "test_raycast_weapon"
	self.name_id = nil
	self._textures = {}
	self._cosmetics_data = nil
	self._materials = nil
end

function NewRaycastWeaponBase:_check_second_sight()
	self._second_sight_data = nil

	if self:has_gadget() then
		local factory = tweak_data.weapon.factory

		for _, part_id in ipairs(self._gadgets) do
			if factory.parts[part_id].sub_type == "second_sight" then
				self._second_sight_data = {
					part_id = part_id,
					unit = self._parts and self._parts[part_id] and alive(self._parts[part_id].unit) and self._parts[part_id].unit
				}

				break
			end
		end
	end
end

function NewRaycastWeaponBase:_check_thq_align_anim()
	if not self:is_npc() then
		return
	end

	if not self:use_thq() then
		return
	end

	local tweak_data = self:weapon_tweak_data()
	local thq_anim_name = tweak_data.animations and tweak_data.animations.thq_align_anim

	if thq_anim_name then
		self._unit:anim_set_time(Idstring(thq_anim_name), self._unit:anim_length(Idstring(thq_anim_name)))
	end
end