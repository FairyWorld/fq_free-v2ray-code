function NewFlamethrowerBase:setup_default()
	self._rays = self:weapon_tweak_data().rays or 6
	self._range = self:weapon_tweak_data().flame_max_range or 1000
	self._flame_max_range = self:weapon_tweak_data().flame_max_range
	self._single_flame_effect_duration = self:weapon_tweak_data().single_flame_effect_duration
	self._bullet_class = FlameBulletBase
	self._bullet_slotmask = self._bullet_class:bullet_slotmask()
	self._blank_slotmask = self._bullet_class:blank_slotmask()
end

function NewFlamethrowerBase:_create_use_setups()
	local use_data = {}
	local player_setup = {
		selection_index = self:selection_index(),
		equip = {
			align_place = self:weapon_tweak_data().use_data.align_place or "left_hand"
		},
		unequip = {
			align_place = "back"
		}
	}
	use_data.player = player_setup
	self._use_data = use_data
end