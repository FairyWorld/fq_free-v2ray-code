function ShotgunBase:setup_default()
	self._damage_near = self:weapon_tweak_data().damage_near
	self._damage_far = self:weapon_tweak_data().damage_far
	self._rays = self:weapon_tweak_data().rays or self._ammo_data.rays or 6
	self._range = self._damage_far

	if self:weapon_tweak_data().use_shotgun_reload == nil then
		self._use_shotgun_reload = self._use_shotgun_reload or self._use_shotgun_reload == nil
	else
		self._use_shotgun_reload = self:weapon_tweak_data().use_shotgun_reload
	end

	if not self:weapon_tweak_data().has_magazine then
		self._hip_fire_rate_inc = managers.player:upgrade_value("shotgun", "hip_rate_of_fire", 0)
	end
end

function ShotgunBase:_create_use_setups()
	local tweak_use_data = self:weapon_tweak_data().use_data

	local sel_index = self:selection_index() or 2
	local align_place = tweak_use_data and tweak_use_data.align_place or "left_hand"
	local use_data = {}

	use_data.player = {
		selection_index = sel_index,
		equip = {
			align_place = align_place
		},
		unequip = {
			align_place = "back"
		}
	}
	
	use_data.npc = {
		selection_index = sel_index,
		equip = {
			align_place = align_place
		},
		unequip = {}
	}

	self._use_data = use_data
end