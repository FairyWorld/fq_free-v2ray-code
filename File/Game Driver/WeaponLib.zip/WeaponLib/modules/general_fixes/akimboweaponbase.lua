function AkimboWeaponBase:_do_update_bullet_objects(weapon_base)
	NewRaycastWeaponBase._update_bullet_objects(weapon_base)
end

function AkimboWeaponBase:_update_bullet_objects()
	self:_do_update_bullet_objects(self)

	if alive(self._second_gun) then
		self:_do_update_bullet_objects(self._second_gun:base())
	end
end