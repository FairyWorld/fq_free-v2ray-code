function NewRaycastWeaponBase:_material_config_name(part_id, unit_name, use_cc_material_config, force_third_person)
	force_third_person = force_third_person or _G.IS_VR

	local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon(part_id, self._factory_id, self._blueprint)

	if self:is_npc() or force_third_person then
		if use_cc_material_config and part_data.cc_thq_material_config then
			return part_data.cc_thq_material_config
		end

		if part_data.thq_material_config then
			return part_data.thq_material_config
		end

		local cc_string = use_cc_material_config and "_cc" or ""
		local thq_string = (self:use_thq() or force_third_person) and "_thq" or ""

		return Idstring(unit_name .. cc_string .. thq_string)
	end

	if use_cc_material_config and part_data.cc_material_config then
		return part_data.cc_material_config
	end

	return Idstring(unit_name .. "_cc")
end