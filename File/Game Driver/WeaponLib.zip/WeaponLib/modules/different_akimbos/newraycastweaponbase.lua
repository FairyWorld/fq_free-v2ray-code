if not NewRaycastWeaponBase._assemble_completed then
	function NewRaycastWeaponBase:assemble_from_blueprint(factory_id, blueprint, clbk, second_gun)
		local third_person = self:_third_person()
		local skip_queue = self:skip_queue()

		local new_blueprint = {}

		for _, part_id in ipairs( blueprint ) do
			local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon( part_id, factory_id, blueprint )

			if ( not part_data.left_only ) and ( not part_data.right_only ) then
				table.insert( new_blueprint, part_id )
			elseif part_data.left_only and second_gun then
				table.insert( new_blueprint, part_id )
			elseif part_data.right_only and not second_gun then
				table.insert( new_blueprint, part_id )
			end
		end

		self._parts, self._blueprint = managers.weapon_factory:assemble_from_blueprint(factory_id, self._unit, new_blueprint, third_person, self:is_npc(), callback(self, self, "clbk_assembly_complete", clbk or function ()
		end), skip_queue)

		self:_check_thq_align_anim()
		self:_update_stats_values()
	end
end