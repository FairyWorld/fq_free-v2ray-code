function MenuSceneManager:spawn_item_weapon(factory_id, blueprint, cosmetics, texture_switches, custom_data)
	local factory_weapon = tweak_data.weapon.factory[factory_id]
	local ids_unit_name = Idstring(factory_weapon.unit)

	if not managers.dyn_resource:is_resource_ready(Idstring("unit"), ids_unit_name, DynamicResourceManager.DYN_RESOURCES_PACKAGE) then
		managers.dyn_resource:load(Idstring("unit"), ids_unit_name, DynamicResourceManager.DYN_RESOURCES_PACKAGE, false)
	end

	self._item_pos = custom_data and custom_data.item_pos or Vector3(0, 0, 200)

	mrotation.set_zero(self._item_rot_mod)

	self._item_yaw = custom_data and custom_data.item_yaw or 0
	self._item_pitch = 0
	self._item_roll = 0

	mrotation.set_zero(self._item_rot)

	local function spawn_weapon(pos, rot, second_gun)
		local new_blueprint = {}

		if blueprint then
			for _, part_id in ipairs( blueprint ) do
				local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon( part_id, factory_id, blueprint )

				if ( not part_data.left_only ) and ( not part_data.right_only ) then
					table.insert( new_blueprint, part_id )
				elseif part_data.left_only and second_gun then
					table.insert( new_blueprint, part_id )
				elseif part_data.right_only and not second_gun then
					table.insert( new_blueprint, part_id )
				end
			end
		end

		local w_unit = World:spawn_unit(ids_unit_name, pos, rot)

		w_unit:base():set_factory_data(factory_id)
		w_unit:base():set_cosmetics_data(cosmetics)
		w_unit:base():set_texture_switches(texture_switches)

		if blueprint then
			w_unit:base():assemble_from_blueprint(factory_id, new_blueprint, true, nil, true)
		else
			w_unit:base():assemble(factory_id, true)
		end

		return w_unit
	end

	local new_unit = spawn_weapon(self._item_pos, self._item_rot, false)
	local second_unit = nil

	if new_unit:base().AKIMBO then
		ids_unit_name = Idstring(factory_weapon.second_unit or factory_weapon.unit)

		if not managers.dyn_resource:is_resource_ready(Idstring("unit"), ids_unit_name, DynamicResourceManager.DYN_RESOURCES_PACKAGE) then
			managers.dyn_resource:load(Idstring("unit"), ids_unit_name, DynamicResourceManager.DYN_RESOURCES_PACKAGE, false)
		end

		second_unit = spawn_weapon(self._item_pos + self._item_rot:x() * -10 + self._item_rot:z() * -7 + self._item_rot:y() * -5, self._item_rot * Rotation(0, 8, -10), true)

		new_unit:link(new_unit:orientation_object():name(), second_unit)
		second_unit:base():tweak_data_anim_stop("unequip")
		second_unit:base():tweak_data_anim_play("equip")
	end

	new_unit:base():tweak_data_anim_stop("unequip")
	new_unit:base():tweak_data_anim_play("equip")

	custom_data = custom_data or {}
	custom_data.id = managers.weapon_factory:get_weapon_id_by_factory_id(factory_id)

	self:_set_item_unit(new_unit, nil, nil, nil, second_unit, custom_data)
	mrotation.set_yaw_pitch_roll(self._item_rot_mod, 90, 0, 0)

	return new_unit
end