function FPCameraPlayerBase:play_sound(unit, event)
	if alive(self._parent_unit) then
		local weapon = self._parent_unit:inventory():equipped_unit()

		if weapon then
			local weapon_tweak_data = weapon:base():weapon_tweak_data()

			if weapon_tweak_data.sounds and ( weapon_tweak_data.sounds.replacements or weapon_tweak_data.sounds.reload ) then
				local sound_replacements = weapon_tweak_data.sounds.replacements or weapon_tweak_data.sounds.reload
				event = sound_replacements[event] or event
			end
		end

		self._parent_unit:sound():play(event)
	end
end
