Hooks:PostHook( WeaponTweakData, "_init_stats", "LimitRiser__init_stats", function(self)
	self.stats.damage = {}
	for i = 1, 100000, 1 do
		table.insert(self.stats.damage, i/10)
	end

	self.stats.extra_ammo = {}
	for i = -100, 100000, 2 do
		table.insert(self.stats.extra_ammo, i)
	end

	self.stats.total_ammo_mod = {}
	for i = -100, 100000, 5 do
		table.insert(self.stats.total_ammo_mod, i / 100)
	end
end)