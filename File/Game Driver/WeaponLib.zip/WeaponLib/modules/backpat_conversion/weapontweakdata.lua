local function needs_shit( part_data )
	if part_data.stats and ( part_data.stats.extra_ammo_new or part_data.stats.total_ammo_mod_new ) then
		return true
	end

	if part_data.custom_stats and ( part_data.custom_stats.rof_mult ) then
		return true
	end

	if part_data.weapon_reload_override or part_data.weapon_hold_override or part_data.weapon_stance_override or part_data.timer_multiplier or part_data.timer_adder then
		return true
	end

	return false
end

local name_id_to_factory_id = {}

local function super_fun_conversion( part_id_for_warning, part_data )
	if not needs_shit( part_data ) then return end

	log("[WeaponLib] [Backwards Compatibility] WARNING: '" .. part_id_for_warning .. "' is using outdated/deprecated tweak data!")

	part_data.stats = part_data.stats or {}
	part_data.custom_stats = part_data.custom_stats or {}
	part_data.override_weapon = part_data.override_weapon or {}
	part_data.override_weapon_add = part_data.override_weapon_add or {}
	part_data.override_weapon_multiply = part_data.override_weapon_multiply or {}

	part_data.override_weapon_add["CLIP_AMMO_MAX"] = part_data.stats.extra_ammo_new
	part_data.override_weapon_add["AMMO_MAX"] = part_data.stats.total_ammo_mod_new

	if part_data.weapon_reload_override then
		for name_id, value in pairs(part_data.weapon_reload_override) do
			part_data.override_weapon["animations"] = part_data.override_weapon["animations"] or {}
			part_data.override_weapon["animations"]["reload_name_id"] = value
		end
	end

	if part_data.weapon_hold_override then
		for name_id, value in pairs(part_data.weapon_hold_override) do
			part_data.override_weapon["weapon_hold"] = value
		end
	end

	if part_data.weapon_stance_override then
		for name_id, value in pairs(part_data.weapon_stance_override) do
			part_data.override_weapon["use_stance"] = value
		end
	end

	if part_data.timer_multiplier then
		part_data.override_weapon_multiply["timers"] = part_data.override_weapon_multiply["timers"] or {}

		for timer_name, value in pairs(part_data.timer_multiplier) do
			part_data.override_weapon_multiply["timers"][timer_name] = value
		end
	end

	if part_data.timer_adder then
		part_data.override_weapon_add["timers"] = part_data.override_weapon_add["timers"] or {}

		for timer_name, value in pairs(part_data.timer_adder) do
			part_data.override_weapon_add["timers"][timer_name] = value
		end
	end

	if part_data.custom_stats.rof_mult then
		part_data.override_weapon_multiply["fire_mode_data"] = part_data.override_weapon_multiply["fire_mode_data"] or {}
		part_data.override_weapon_multiply["fire_mode_data"]["fire_rate"] = 1/part_data.custom_stats.rof_mult
	end

	-- Recursive Fun!
	if part_data.override then
		for part_id, part_data in pairs(part_data.override) do
			super_fun_conversion( part_id_for_warning .. ".override." .. part_id, part_data )
		end
	end
end

Hooks:PostHook( WeaponTweakData, "_init_data_player_weapons", "BackPatConversion", function(self)
	local parts = self.factory.parts

	for part_id, part_data in pairs(parts) do
		super_fun_conversion( part_id, part_data )
	end
end)