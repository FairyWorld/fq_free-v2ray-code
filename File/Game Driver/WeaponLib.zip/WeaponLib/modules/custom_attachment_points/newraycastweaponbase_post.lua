local function clone_meta_object( original_object )
	local meta_table = getmetatable(original_object)

	local output_object = { _original_object = original_object }

	for key, value in pairs(meta_table) do
		output_object[key] = function( self, ... )
			return self._original_object[key]( self._original_object, ... )
		end
	end

	return output_object
end

local function edit_object_function( object, func_name, new_func )
	object["old_" .. func_name] = object[func_name]
	object[func_name] = new_func
end

local function is_idstring( questionable_variable )
	local var_string = tostring(questionable_variable)

	if string.match(var_string, "Idstring") then
		return true
	else
		return false
	end
end

-- New Function
local old_get_object = function ( self, ... ) return {} end
local get_object_replacement = function( self, object_id, ... )
	if self.base and self:base() and self:base().cap_objects then
		local base_data = self:base()
		local cap_objects = base_data.cap_objects

		if cap_objects[tostring(object_id)] then
			local object_data = cap_objects[tostring(object_id)]

			if object_data.base_obj then
				object_id = object_data.base_obj
			end

			local object = self:old_get_object(object_id)
			if not object then
				object = self:old_get_object(Idstring("a_body"))
				if not object then
					object = self:orientation_object()
				end
			end

			if object_data.forced_object then
				object = object_data.forced_object
			end

			local output_object_data = clone_meta_object(object)

			if object_data.offset then
				if object_data.offset.position then
					edit_object_function( output_object_data, "position", function( self )
						local base_position = self:old_position()
						local a_position = object_data.offset.position

						local new_position = ( base_position + a_position ) or Vector3(0,0,0)

						if object_data.extra_offset and object_data.extra_offset.position then
							new_position = base_position + object_data.extra_offset.position
						end

						return new_position
					end )

					edit_object_function( output_object_data, "local_position", function( self )
						local base_position = self:old_local_position()
						local a_position = object_data.offset.position

						local new_position = ( base_position + a_position ) or Vector3(0,0,0)

						if object_data.extra_offset and object_data.extra_offset.position then
							new_position = base_position + object_data.extra_offset.position
						end

						return new_position
					end )
				end

				if object_data.offset.rotation then
					edit_object_function( output_object_data, "rotation", function( self )
						local base_rotation = self:old_rotation()
						local a_rotation = object_data.offset.rotation

						local new_rotation = Rotation(
							(base_rotation:yaw() + a_rotation:yaw() ) % 360,
							(base_rotation:pitch() + a_rotation:pitch() ) % 360,
							(base_rotation:roll() + a_rotation:roll() ) % 360
						) or Rotation(0,0,0)

						if object_data.extra_offset and object_data.extra_offset.rotation then
							new_position = Rotation(
								(base_rotation:yaw() + object_data.extra_offset.rotation:yaw() ) % 360,
								(base_rotation:pitch() + object_data.extra_offset.rotation:pitch() ) % 360,
								(base_rotation:roll() + object_data.extra_offset.rotation:roll() ) % 360
							) or Rotation(0,0,0)
						end

						return new_rotation
					end )

					edit_object_function( output_object_data, "local_rotation", function( self )
						local base_rotation = self:old_local_rotation()
						local a_rotation = object_data.offset.rotation

						local new_rotation = Rotation(
							(base_rotation:yaw() + a_rotation:yaw() ) % 360,
							(base_rotation:pitch() + a_rotation:pitch() ) % 360,
							(base_rotation:roll() + a_rotation:roll() ) % 360
						) or Rotation(0,0,0)

						if object_data.extra_offset and object_data.extra_offset.rotation then
							new_position = Rotation(
								(base_rotation:yaw() + object_data.extra_offset.rotation:yaw() ) % 360,
								(base_rotation:pitch() + object_data.extra_offset.rotation:pitch() ) % 360,
								(base_rotation:roll() + object_data.extra_offset.rotation:roll() ) % 360
							) or Rotation(0,0,0)
						end

						return new_rotation
					end )
				end
			end

			return output_object_data
		end
	end

	return self:old_get_object(object_id, ...)
end

local last_valid_weapon_unit
local old_link = function ( self, ... ) return {} end
local link_replacement = function( self, ... )
	local args = {...}
	local object_id = args[1]
	local unit = args[2]

	if is_idstring(object_id) then
		if not object_id then return false end
		if not unit then return false end

		local res = nil

		local new_position = nil
		local new_rotation = nil

		if ( self.base and self:base() and self:base().cap_objects ) or ( not ( self.base and self:base() and self:base()._name_id ) and ( last_valid_weapon_unit and alive(last_valid_weapon_unit) ) ) then
			if ( self.base and self:base() and self:base().cap_objects ) then
				last_valid_weapon_unit = self
			end

			local weapon_base = last_valid_weapon_unit:base()
			local cap_objects = weapon_base.cap_objects

			if cap_objects[tostring(object_id)] then
				local object_data = cap_objects[tostring(object_id)]
				local object = last_valid_weapon_unit:old_get_object(Idstring("a_body"))
				if not object then
					object = last_valid_weapon_unit:orientation_object()
				end
				local object_id = object:name()

				if object_data.base_obj then
					if last_valid_weapon_unit:old_get_object(object_data.base_obj) then
						object_id = object_data.base_obj
						object = last_valid_weapon_unit:old_get_object(object_id)
					else
						log("[WeaponLib] [Custom Attachment Points] WARNING: Attachment point '" .. object_data.name .. "' failed to find base object '" .. object_data.base_a_obj .. "' for '" .. weapon_base._name_id .. "'!")
					end
				end

				if object and object_data.offset then
					if object_data.offset.position then
						local base_position = object:position() or Vector3()
						local a_position = object_data.offset.position

						new_position = ( base_position + a_position ) or Vector3(0,0,0)
					end

					if object_data.offset.rotation then
						local base_rotation = object:rotation() or Rotation()
						local a_rotation = object_data.offset.rotation

						new_rotation = Rotation(
							(base_rotation:yaw() + a_rotation:yaw() ) % 360,
							(base_rotation:pitch() + a_rotation:pitch() ) % 360,
							(base_rotation:roll() + a_rotation:roll() ) % 360
						) or Rotation(0,0,0)
					end
				end

				table.remove( args, 1 )
				table.remove( args, 1 )

				local res = last_valid_weapon_unit:old_link( object_id, unit, unpack( args ) )

				if new_position then unit:set_position( new_position ) end
				if new_rotation then unit:set_rotation( new_rotation ) end

				return res
			end
		end
	end

	return self:old_link( ... )
end

-- Have to do this because for some reason I can't access the `Unit` global consistently.
cap_get_object_override_is_complete = cap_get_object_override_is_complete or false
function NewRaycastWeaponBase:setup_cap_overrides( unit )
	local meta_table = getmetatable(unit) -- Get the global metatable.

	if not cap_get_object_override_is_complete then -- Check to see if we've done it before.
		meta_table.old_get_object = meta_table.get_object -- Store the old function, Another backup check.
		meta_table.get_object = get_object_replacement -- Replace with new function.

		meta_table.old_link = meta_table.link -- Store the old function, Another backup check.
		meta_table.link = link_replacement -- Replace with new function.

		cap_get_object_override_is_complete = true
	end

	local weapon_tweak_data = tweak_data.weapon[self._name_id]

	if weapon_tweak_data and weapon_tweak_data.attachment_points then
		self.cap_objects = self.cap_objects or {}

		local attachment_points = weapon_tweak_data.attachment_points
		for _, attachment_point_data in pairs(attachment_points) do
			if string.sub(_, 1, 1) ~= "_" then
				local ids_name = tostring(Idstring(attachment_point_data.name))

				self.cap_objects[ids_name] = self.cap_objects[ids_name] or {
					name = attachment_point_data.name,
					offset = {
						position = attachment_point_data.position,
						rotation = attachment_point_data.rotation
					},
					part_attach_data = attachment_point_data.part_attach_data
				}

				if attachment_point_data.base_a_obj then
					local base_id = Idstring(attachment_point_data.base_a_obj)
					if base_id then
						self.cap_objects[ids_name].base_a_obj = self.cap_objects[ids_name].base_a_obj or attachment_point_data.base_a_obj
						self.cap_objects[ids_name].base_obj = self.cap_objects[ids_name].base_obj or base_id
					end
				end
			end
		end
	end
end

function NewRaycastWeaponBase:assembly_after_party()
	local part_factory = tweak_data.weapon.factory.parts
	local cap_objects = self.cap_objects

	if not part_factory then return end
	if not cap_objects then return end

	for part_id, part_int_data in pairs(self._parts) do
		if part_int_data and part_int_data.unit then

			local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon(part_id, self._factory_id, self._blueprint)
			local a_obj = part_data.a_obj
			if a_obj then
				local ids_a_obj = Idstring(a_obj)
				local cap_data = cap_objects[tostring(ids_a_obj)]

				if cap_data and cap_data.part_attach_data then

					local possible_parts = cap_data.part_attach_data[1]
					local part_object = Idstring(cap_data.part_attach_data[2])

					for _, part_id_2 in ipairs(possible_parts) do
						local part = self._parts[part_id_2]
						if part and part.unit then
							local object = part.unit:old_get_object(part_object)
							if object then
								local res = part.unit:old_link(part_object, part_int_data.unit, part_int_data.unit:orientation_object():name())
								cap_data.forced_object = object

								local base_position = object:local_position()
								local base_rotation = object:local_rotation()

								if cap_data.base_obj then
									local base_obj = self._unit:old_get_object(cap_data.base_obj)
									if not base_obj then
										base_obj = self._unit:old_get_object(Idstring("a_body"))
									end
									if base_obj then
										local base_obj_position = base_obj:local_position()
										local base_obj_rotation = base_obj:local_rotation()

										local part_attach_position = Vector3()
										local part_attach_rotation = Vector3()

										local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon(part_id_2, self._factory_id, self._blueprint)
										local a_obj = part_data.a_obj
										if a_obj then
											local part_2_a_obj = self._unit:old_get_object(Idstring(a_obj))
											if not part_2_a_obj then
												part_2_a_obj = self:old_get_object(Idstring("a_body"))
												if not part_2_a_obj then
													part_2_a_obj = self:orientation_object()
												end
											end

											part_attach_position = part_2_a_obj:local_position()
											part_attach_rotation = part_2_a_obj:local_rotation()
										end

										base_position = base_obj_position - part_attach_position
										base_rotation = Rotation(
											(base_obj_rotation:yaw() - part_attach_rotation:yaw() ) % 360,
											(base_obj_rotation:pitch() - part_attach_rotation:pitch() ) % 360,
											(base_obj_rotation:roll() - part_attach_rotation:roll() ) % 360
										)

										cap_data.extra_offset = cap_data.extra_offset or {}
										cap_data.extra_offset.position = base_position
										cap_data.extra_offset.rotation = base_rotation
									end
								end

								local a_position = cap_data.offset.position or Vector3(0,0,0)
								new_position = ( base_position + a_position ) or Vector3(0,0,0)

								local a_rotation = cap_data.offset.rotation or Rotation(0,0,0)
								new_rotation = Rotation(
									(base_rotation:yaw() + a_rotation:yaw() ) % 360,
									(base_rotation:pitch() + a_rotation:pitch() ) % 360,
									(base_rotation:roll() + a_rotation:roll() ) % 360
								) or Rotation(0,0,0)

								part_int_data.unit:set_position( new_position )
								part_int_data.unit:set_rotation( new_rotation )
							end

							break
						end
					end
				end
			end
		end
	end
end

Hooks:PostHook( NewRaycastWeaponBase, "init", "CustomAttachmentPoints_SetupCAPOverrides", NewRaycastWeaponBase.setup_cap_overrides )
Hooks:PostHook( NewRaycastWeaponBase, "_assemble_completed", "CustomAttachmentPoints_AssemblyCompleted_PartAttachmentStuff_Menu", NewRaycastWeaponBase.assembly_after_party )