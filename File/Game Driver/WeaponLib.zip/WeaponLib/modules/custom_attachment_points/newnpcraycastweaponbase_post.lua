Hooks:PostHook( NewNPCRaycastWeaponBase, "init", "CustomAttachmentPoints_NPCThirdPersonAttachments", function( self, unit )
	local weapon_tweak_data = tweak_data.weapon[self._name_id]

	if weapon_tweak_data and weapon_tweak_data.attachment_points then
		self.cap_objects = self.cap_objects or {}

		local attachment_points = weapon_tweak_data.attachment_points
		for _, attachment_point_data in pairs(attachment_points) do
			local ids_name = tostring(Idstring(attachment_point_data.name))

			self.cap_objects[ids_name] = self.cap_objects[ids_name] or {
				offset = {
					position = attachment_point_data.position,
					rotation = attachment_point_data.rotation
				},
				part_attach_data = attachment_point_data.part_attach_data
			}

			if attachment_point_data.base_a_obj then
				local base_id = Idstring(attachment_point_data.base_a_obj)
				if base_id then
					self.cap_objects[ids_name].base_obj = self.cap_objects[ids_name].base_a_obj or base_id
				end
			end
		end
	end
end)