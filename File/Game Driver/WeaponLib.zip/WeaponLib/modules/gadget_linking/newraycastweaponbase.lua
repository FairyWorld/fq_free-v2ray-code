Hooks:PostHook( NewRaycastWeaponBase, "_update_stats_values", "ParentGadget__update_stats_values", function(self)
	for part_id, part in pairs(self._parts) do
		local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon(part_id, self._factory_id, self._blueprint)

		if part_data and part_data.parent_gadget then
			local parent_gadget_id = part_data.parent_gadget

			if self._parts and self._parts[parent_gadget_id] and self._parts[parent_gadget_id].unit and alive(self._parts[parent_gadget_id].unit) then
				local parent_gadget = self._parts[parent_gadget_id].unit

				if part.unit and alive(part.unit) then
					parent_gadget:base():add_child_gadget( part_id, part.unit )
				end
			end
		end
	end
end)