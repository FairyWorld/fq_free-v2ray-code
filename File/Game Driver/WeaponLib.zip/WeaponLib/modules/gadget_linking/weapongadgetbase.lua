function WeaponGadgetBase:add_child_gadget( part_id, unit )
	self._child_gadgets = self._child_gadgets or {}
	
	self._child_gadgets[part_id] = self._child_gadgets[part_id] or unit
end

local gadget_functions = {
	"set_npc",
	"set_state",
	"set_on",
	"set_off",
	"toggle"
}

for index, func_name in ipairs(gadget_functions) do
	Hooks:PostHook( WeaponGadgetBase, func_name, "ParentGadget_" .. func_name, function(self, ...) 
		for part_id, unit in pairs(self._child_gadgets or {}) do
			if unit:base()[func_name] then
				unit:base()[func_name](unit:base(), ...)
			end
		end
	end)
end