function WeaponFactoryManager:_cleanup_blueprint( blueprint )
	local cleaned = {}

	for _, part_id in ipairs(blueprint or {}) do
		if ( part_id ~= nil ) then
			table.insert(cleaned, part_id)
		end
	end

	return cleaned
end

local tsort = table.sort
local tconcat = table.concat
function WeaponFactoryManager:_get_cache_key( factory_id, blueprint )
	blueprint = self:_cleanup_blueprint(blueprint)

	tsort(blueprint)
	return factory_id .. tconcat(blueprint)
end

WeaponFactoryManager._caches = {}

local fac_id_blueprint_functions_to_cache = {
	"get_assembled_blueprint",
	"_get_forbidden_parts",
	"_get_override_parts",
	"get_custom_stats_from_weapon",
	"get_ammo_data_from_weapon",
	"is_weapon_unmodded",
	"blueprint_to_string",
	"get_perks"
}

local now = os.clock
local st

for _, function_name in ipairs(fac_id_blueprint_functions_to_cache) do
	WeaponFactoryManager._caches[function_name] = {}

	WeaponFactoryManager["_wfmc_old" .. function_name] = WeaponFactoryManager["_wfmc_old_" .. function_name] or WeaponFactoryManager[function_name]

	WeaponFactoryManager[function_name] = function(self, factory_id, blueprint)
		local cache_key = self:_get_cache_key( factory_id, blueprint )

		if self._caches[function_name][cache_key] then
			return self._caches[function_name][cache_key]
		end

		st = now()
		local new_output = WeaponFactoryManager["_wfmc_old" .. function_name]( self, factory_id, blueprint )
		self._caches[function_name][cache_key] = new_output

		return self._caches[function_name][cache_key]
	end
end

WeaponFactoryManager._caches["_part_data"] = {}

WeaponFactoryManager["_wfmc_old_part_data"] = WeaponFactoryManager["_wfmc_old_part_data"] or WeaponFactoryManager["_part_data"]

function WeaponFactoryManager:_part_data( part_id, factory_id, override )
	local extra_one = ""
	if override and override[part_id] then
		extra_one = tostring(override)
	end

	local cache_key = part_id .. factory_id .. extra_one

	if self._caches["_part_data"][cache_key] then
		return self._caches["_part_data"][cache_key]
	end

	st = now()
	local new_output = WeaponFactoryManager["_wfmc_old_part_data"]( self, part_id, factory_id, override )
	self._caches["_part_data"][cache_key] = new_output

	return self._caches["_part_data"][cache_key]
end

-- Cache Clearing Hooks!
function WeaponFactoryManager:clear_cache()
	self._caches = {}

	for _, function_name in ipairs(fac_id_blueprint_functions_to_cache) do
		self._caches[function_name] = {}
	end
	self._caches["_part_data"] = {}
end

Hooks:PostHook( WeaponFactoryManager, "init", "WFMC_Init", function(self)
	self:clear_cache()
end)