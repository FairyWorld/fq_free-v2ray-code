Hooks:PreHook( BlackMarketGui, "choose_weapon_mods_callback", "WFMC_ClearForNewGun", function(self)
	managers.weapon_factory:clear_cache()
end)