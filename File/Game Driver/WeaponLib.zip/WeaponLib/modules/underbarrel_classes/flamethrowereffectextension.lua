UBFlamethrowerEffectExtension = UBFlamethrowerEffectExtension or class(FlamethrowerEffectExtension)

function UBFlamethrowerEffectExtension:_spawn_muzzle_effect(from_pos, direction)
	local nozzle_obj = self._unit:get_object(Idstring("g_base"))
	local nozzle_pos = nozzle_obj:position()
	local attach_obj = self._unit
	local effect_id = World:effect_manager():spawn({
		effect = self._flame_effect.effect,
		position = nozzle_pos,
		normal = math.UP
	})
	self._last_fire_time = managers.player:player_timer():time()

	table.insert(self._flamethrower_effect_collection, {
		been_alive = false,
		id = effect_id,
		position = nozzle_pos,
		direction = direction
	})
end