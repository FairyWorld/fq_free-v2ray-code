function WeaponUnderbarrel:reload_speed_stat()
	return 1
end

function WeaponUnderbarrel:weapon_tweak_data()
	local weapon_tweak_data_id = self.name_id

	if not tweak_data.weapon[weapon_tweak_data_id] then
		log("[WeaponLib] [Underbarrel Classes] IMPORTANT: You've funked up somewhere and '" .. weapon_tweak_data_id .. "' doesn't exist in the weapon tweak data!" )
		return tweak_data.weapon["glock_17"]
	end

	return tweak_data.weapon[weapon_tweak_data_id]
end

WeaponUnderbarrelShotgun = WeaponUnderbarrelShotgun or class(WeaponUnderbarrel)
WeaponUnderbarrelShotgun.GADGET_TYPE = "underbarrel_shotgun"

function WeaponUnderbarrelShotgun:init(unit)
	WeaponUnderbarrelLauncher.super.init(self, unit)
	self._name_id = self.name_id
	self._damage = tweak_data.weapon[self._name_id].DAMAGE
	self._rays = tweak_data.weapon[self._name_id].rays
	self._damage_near = tweak_data.weapon[self._name_id].damage_near
	self._damage_far = tweak_data.weapon[self._name_id].damage_far
	self._spread_index = tweak_data.weapon[self._name_id].stats.spread
end

function WeaponUnderbarrelShotgun:get_name_id()
	return self._name_id
end

function WeaponUnderbarrelShotgun:get_current_weapon()
	local current_selected = managers.player:player_unit():inventory()._equipped_selection or 2
	return managers.player:player_unit():inventory()._available_selections[current_selected].unit
end

function WeaponUnderbarrelShotgun:_get_spread_indices(current_state)
	local spread_index = self._spread_index or 1
	local spread_idx_x, spread_idx_y = nil

	if type(spread_index) == "number" then
		spread_idx_x = tweak_data.weapon.stats.spread[spread_index]
		spread_idx_y = spread_idx_x
	else
		spread_idx_x = tweak_data.weapon.stats.spread[spread_index[1]]
		spread_idx_y = tweak_data.weapon.stats.spread[spread_index[2]]
	end

	return spread_idx_x, spread_idx_y
end

function WeaponUnderbarrelShotgun:_get_spread_from_number(user_unit, current_state, current_spread_value)
	local spread = self:_get_spread_indices(current_state)

	return math.max(spread * current_spread_value, 0)
end

function WeaponUnderbarrelShotgun:_get_spread_from_table(user_unit, current_state, current_spread_value)
	local spread_idx_x, spread_idx_y = self:_get_spread_indices(current_state)

	return math.max(spread_idx_x * current_spread_value[1], 0), math.max(spread_idx_y * current_spread_value[2], 0)
end

function WeaponUnderbarrelShotgun:_get_spread(user_unit)
	local current_state = user_unit:movement()._current_state

	if not current_state then
		return 0, 0
	end

	local spread_values = tweak_data.weapon[self._name_id].spread

	if not spread_values then
		return 0, 0
	end

	local current_spread_value = spread_values[current_state:get_movement_state()]
	local spread_x, spread_y = nil

	if type(current_spread_value) == "number" then
		spread_x = self:_get_spread_from_number(user_unit, current_state, current_spread_value)
		spread_y = spread_x
	else
		spread_x, spread_y = self:_get_spread_from_table(user_unit, current_state, current_spread_value)
	end

	if current_state:in_steelsight() then
		local steelsight_tweak = spread_values.steelsight
		local multi_x, multi_y = nil

		if type(steelsight_tweak) == "number" then
			multi_x = 1 + 1 - steelsight_tweak
			multi_y = multi_x
		else
			multi_x = 1 + 1 - steelsight_tweak[1]
			multi_y = 1 + 1 - steelsight_tweak[2]
		end

		spread_x = spread_x * multi_x
		spread_y = spread_y * multi_y
	end

	return spread_x, spread_y
end

function WeaponUnderbarrelShotgun:_get_current_damage(dmg_mul)
	local damage = self._damage * (dmg_mul or 1)
	damage = damage * managers.player:temporary_upgrade_value("temporary", "combat_medic_damage_multiplier", 1)

	return damage
end

local mvec_spread_direction = Vector3()
local mvec_to = Vector3()
function WeaponUnderbarrelShotgun:_fire_raycast(weapon_base, user_unit, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, shoot_through_data)
	local result = {}
	local hit_enemies = {}
	local damage = self:_get_current_damage(dmg_mul)
	local function hit_enemy(col_ray)
		if col_ray.unit:character_damage() and col_ray.unit:character_damage().is_head then
			local enemy_key = col_ray.unit:key()
			if not hit_enemies[enemy_key] or col_ray.unit:character_damage():is_head(col_ray.body) then
				hit_enemies[enemy_key] = col_ray
			end
		else
			InstantBulletBase:on_collision(col_ray, self:get_current_weapon(), user_unit, damage)
		end
	end
	local right = direction:cross(Vector3(0, 0, 1)):normalized()
	local up = direction:cross(right):normalized()
	for ray = 1, self._rays or 20 do
		local spread_x, spread_y = self:_get_spread(user_unit)
		local theta = math.random() * 360
		local ax = math.sin(theta) * (math.random() * spread_x) * (spread_mul or 1)
		local ay = math.cos(theta) * (math.random() * spread_y) * (spread_mul or 1)
		mvector3.set(mvec_spread_direction, direction)
		mvector3.add(mvec_spread_direction, right * math.rad(ax))
		mvector3.add(mvec_spread_direction, up * math.rad(ay))
		mvector3.set(mvec_to, mvec_spread_direction)
		mvector3.multiply(mvec_to, 20000)
		mvector3.add(mvec_to, from_pos)
		local col_ray = World:raycast("ray", from_pos, mvec_to, "slot_mask", InstantBulletBase:bullet_slotmask(), "ignore_unit", {})
		if col_ray then
			hit_enemy(col_ray)
		end
	end
	for _, col_ray in pairs(hit_enemies) do
		local dist = mvector3.distance(col_ray.unit:position(), user_unit:position())
		damage = (1 - math.min(1, math.max(0, dist - self._damage_near) / self._damage_far)) * damage
		local result = InstantBulletBase:on_collision(col_ray, self:get_current_weapon(), user_unit, damage)
		if result and result.type == "death" and col_ray.distance < 500 then
			if col_ray.unit:movement()._active_actions[1] and col_ray.unit:movement()._active_actions[1]:type() == "hurt" then
				col_ray.unit:movement()._active_actions[1]:force_ragdoll()
			end
			local scale = math.clamp(1 - col_ray.distance / 500, 0.5, 1)
			local unit = col_ray.unit
			local height = mvector3.distance(col_ray.position, col_ray.unit:position()) - 100
			local twist_dir = math.random(2) == 1 and 1 or -1
			local rot_acc = (col_ray.ray:cross(math.UP) + math.UP * (0.5 * twist_dir)) * (-1000 * math.sign(height))
			local rot_time = 1 + math.rand(2)
			local nr_u_bodies = unit:num_bodies()
			local i_u_body = 0
			while nr_u_bodies > i_u_body do
				local u_body = unit:body(i_u_body)
				if u_body:enabled() and u_body:dynamic() then
					local body_mass = u_body:mass()
					World:play_physic_effect(Idstring("physic_effects/shotgun_hit"), u_body, Vector3(col_ray.ray.x, col_ray.ray.y, col_ray.ray.z + 0.5) * 600 * scale, 4 * body_mass / math.random(2), rot_acc, rot_time)
				end
				i_u_body = i_u_body + 1
			end
		end
	end
	result.hit_enemy = next(hit_enemies) and true or false
	weapon_base:check_bullet_objects()
	return result
end

WeaponUnderbarrelFlamethrower = WeaponUnderbarrelFlamethrower or class(WeaponUnderbarrel)
WeaponUnderbarrelFlamethrower.GADGET_TYPE = "underbarrel_flamethrower"

function WeaponUnderbarrelFlamethrower:init(unit)
	WeaponUnderbarrelLauncher.super.init(self, unit)
	self._name_id = self.name_id
	self._damage = tweak_data.weapon[self._name_id].DAMAGE
	self._flame_max_range = tweak_data.weapon[self._name_id].flame_max_range
	self._damage_far = tweak_data.weapon[self._name_id].damage_far
	self._spread_index = tweak_data.weapon[self._name_id].stats.spread

	self._bullet_class = FlameBulletBase
	if self._bullet_class then
		self._bullet_slotmask = self._bullet_class:bullet_slotmask()
		self._blank_slotmask = self._bullet_class:blank_slotmask()
	end
end

function WeaponUnderbarrelFlamethrower:get_name_id()
	return self._name_id
end

function WeaponUnderbarrelFlamethrower:_get_spread_indices(current_state)
	local spread_index = self._spread_index or 1
	local spread_idx_x, spread_idx_y = nil

	if type(spread_index) == "number" then
		spread_idx_x = tweak_data.weapon.stats.spread[spread_index]
		spread_idx_y = spread_idx_x
	else
		spread_idx_x = tweak_data.weapon.stats.spread[spread_index[1]]
		spread_idx_y = tweak_data.weapon.stats.spread[spread_index[2]]
	end

	return spread_idx_x, spread_idx_y
end

function WeaponUnderbarrelFlamethrower:_get_spread_from_number(user_unit, current_state, current_spread_value)
	local spread = self:_get_spread_indices(current_state)

	return math.max(spread * current_spread_value, 0)
end

function WeaponUnderbarrelFlamethrower:_get_spread_from_table(user_unit, current_state, current_spread_value)
	local spread_idx_x, spread_idx_y = self:_get_spread_indices(current_state)

	return math.max(spread_idx_x * current_spread_value[1], 0), math.max(spread_idx_y * current_spread_value[2], 0)
end

function WeaponUnderbarrelFlamethrower:_get_spread(user_unit)
	local current_state = user_unit:movement()._current_state

	if not current_state then
		return 0, 0
	end

	local spread_values = tweak_data.weapon[self._name_id].spread

	if not spread_values then
		return 0, 0
	end

	local current_spread_value = spread_values[current_state:get_movement_state()]
	local spread_x, spread_y = nil

	if type(current_spread_value) == "number" then
		spread_x = self:_get_spread_from_number(user_unit, current_state, current_spread_value)
		spread_y = spread_x
	else
		spread_x, spread_y = self:_get_spread_from_table(user_unit, current_state, current_spread_value)
	end

	if current_state:in_steelsight() then
		local steelsight_tweak = spread_values.steelsight
		local multi_x, multi_y = nil

		if type(steelsight_tweak) == "number" then
			multi_x = 1 + 1 - steelsight_tweak
			multi_y = multi_x
		else
			multi_x = 1 + 1 - steelsight_tweak[1]
			multi_y = 1 + 1 - steelsight_tweak[2]
		end

		spread_x = spread_x * multi_x
		spread_y = spread_y * multi_y
	end

	return spread_x, spread_y
end

function WeaponUnderbarrelFlamethrower:_get_current_damage(dmg_mul)
	local damage = self._damage * (dmg_mul or 1)
	damage = damage * managers.player:temporary_upgrade_value("temporary", "combat_medic_damage_multiplier", 1)

	return damage
end

function WeaponUnderbarrelFlamethrower:_fire_raycast(weapon_base, user_unit, from_pos, direction, dmg_mul, shoot_player, spread_mul, autohit_mul, suppr_mul, shoot_through_data)
	self._unit:flamethrower_effect_extension():_spawn_muzzle_effect( from_pos, direction )
	
	local result = {}
	local hit_enemies = 0
	local damage = self:_get_current_damage(dmg_mul)
	local damage_range = self._flame_max_range
	local spread_x, spread_y = self:_get_spread(user_unit)

	mvector3.set(mvec_to, direction)
	mvector3.multiply(mvec_to, damage_range)
	mvector3.add(mvec_to, from_pos)

	local col_ray = World:raycast("ray", from_pos, mvec_to, "slot_mask", self._bullet_slotmask, "ignore_unit", {})

	if col_ray then
		damage_range = math.min(damage_range, col_ray.distance)
	end

	local cone_spread = math.rad(spread_x) * damage_range

	mvector3.set(mvec_to, direction)
	mvector3.multiply(mvec_to, damage_range)
	mvector3.add(mvec_to, from_pos)

	local hit_bodies = World:find_bodies(user_unit, "intersect", "cone", from_pos, mvec_to, cone_spread, self._bullet_slotmask)

	for idx, body in ipairs(hit_bodies) do
		local unit = body:unit()
		local fake_ray = {
			body = body,
			unit = body:unit(),
			ray = direction,
			normal = direction,
			position = from_pos
		}

		self._bullet_class:on_collision(fake_ray, self._unit, user_unit, damage)

		if unit:character_damage() and unit:character_damage().is_head then
			hit_enemies = hit_enemies + 1
		end
	end

	result.hit_enemy = hit_enemies > 0 and true or false

	if self._alert_events then
		result.rays = {{position = from_pos}}
	end

	return result
end