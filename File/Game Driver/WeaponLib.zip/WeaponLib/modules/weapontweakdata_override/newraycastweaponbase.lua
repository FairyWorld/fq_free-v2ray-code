function NewRaycastWeaponBase:weapon_tweak_data( overriden_weapon_tweak_data_id )
	local weapon_tweak_data_id = self._name_id

	local underbarrel_id = nil
	if ( self._cached_gadget and self._cached_gadget.is_on and self._cached_gadget:is_on() and self._cached_gadget.name_id ) then
		underbarrel_id = self._cached_gadget.name_id
	end
	weapon_tweak_data_id = overriden_weapon_tweak_data_id or weapon_tweak_data_id

	if ( self._factory_id and self._blueprint ) then
		local connector = ( underbarrel_id and "_" or "" )

		self._patched_weapon_tweak_data = self._patched_weapon_tweak_data or {}

		if ( self._patched_weapon_tweak_data[weapon_tweak_data_id .. connector .. ( underbarrel_id or "" )] ) then
			return self._patched_weapon_tweak_data[weapon_tweak_data_id .. connector .. ( underbarrel_id or "" )]
		else
			if ( underbarrel_id ) then
				self._patched_weapon_tweak_data[weapon_tweak_data_id .. "_" .. underbarrel_id] = managers.weapon_factory:get_modded_weapon_tweak_data_underbarrel( underbarrel_id, weapon_tweak_data_id, self._factory_id, self._blueprint )
			else
				self._patched_weapon_tweak_data[weapon_tweak_data_id] = managers.weapon_factory:get_modded_weapon_tweak_data( weapon_tweak_data_id, self._factory_id, self._blueprint )
			end

			return self._patched_weapon_tweak_data[weapon_tweak_data_id .. connector .. ( underbarrel_id or "" )]
		end
	end

	if not tweak_data.weapon[underbarrel_id or weapon_tweak_data_id] then
		log("[WeaponLib] [WeaponTweakData Override] IMPORTANT: You've funked up somewhere and '" .. (underbarrel_id or weapon_tweak_data_id) .. "' doesn't exist in the weapon tweak data!" )
		return tweak_data.weapon["glock_17"]
	end

	return tweak_data.weapon[underbarrel_id or weapon_tweak_data_id]
end