-- Thanks BeardLib, I'm too lazy to make my own merge functions!

local function none( var1, var2 )
	return ( var2 or 0 )
end

local function add( var1, var2 )
	if ( ( type(var1) == "string" ) or ( type(var2) == "string" ) ) then
		return tostring(var1) .. tostring(var2)
	end

	if ( type(var1) == "table" ) then
		return table.insert(var1, var2)
	end

	return ( var1 or 0 ) + ( var2 or 0 )
end

local function multiply( var1, var2 )
	-- Can't really multiply tables can we.
	if ( ( type(var1) == "table" ) or ( type(var2) == "table" ) ) then
		return table.insert(var1, var2)
	end

	return ( var1 or 0 ) * ( var2 or 0 )
end

local function merge_operator(og_table, new_table, operator)
	og_table = og_table or {}

	if not new_table then
		return og_table
	end

	for i, data in pairs(new_table) do
		if string.sub(tostring(i), 1, 1) ~= "_" then
			i = type(data) == "table" and data.index or i

			if type(data) == "table" and og_table[i] == nil then
				og_table[i] = {}
			end

			if type(data) == "table" and type(og_table[i]) == "table" then
				og_table[i] = merge_operator(og_table[i], data, operator)
			else
				og_table[i] = operator( og_table[i], data )
			end
		end
	end

	return og_table
end

function WeaponFactoryManager:get_modded_weapon_tweak_data( weapon_id, factory_id, blueprint )
	if not tweak_data.weapon[weapon_id] then return {} end

	local modded_weapon_tweak_data = deep_clone( tweak_data.weapon[weapon_id] )

	for index, part_id in ipairs(blueprint) do
		local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon( part_id, factory_id, blueprint )
		if part_data.override_weapon then
			modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, part_data.override_weapon, none )
		end
		if part_data.override_weapon_add then
			modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, part_data.override_weapon_add, add )
		end
		if part_data.override_weapon_multiply then
			modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, part_data.override_weapon_multiply, multiply )
		end
	end

	return modded_weapon_tweak_data
end

function WeaponFactoryManager:get_modded_weapon_tweak_data_underbarrel( weapon_id, old_id, factory_id, blueprint )
	if not tweak_data.weapon[weapon_id] then return {} end

	local modded_weapon_tweak_data = deep_clone( tweak_data.weapon[old_id] )
	modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, tweak_data.weapon[weapon_id], none )

	for index, part_id in ipairs(blueprint) do
		local part_data = managers.weapon_factory:get_part_data_by_part_id_from_weapon( part_id, factory_id, blueprint )
		if part_data.override_weapon then
			modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, part_data.override_weapon, none )
		end
		if part_data.override_weapon_add then
			modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, part_data.override_weapon_add, add )
		end
		if part_data.override_weapon_multiply then
			modded_weapon_tweak_data = merge_operator( modded_weapon_tweak_data, part_data.override_weapon_multiply, multiply )
		end
	end

	return modded_weapon_tweak_data
end