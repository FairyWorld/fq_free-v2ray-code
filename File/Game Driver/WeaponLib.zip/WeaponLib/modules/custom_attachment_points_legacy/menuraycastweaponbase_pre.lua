require("lib/units/weapons/RaycastWeaponBase")
NewRaycastWeaponBase = NewRaycastWeaponBase or class(RaycastWeaponBase)