HUDTeammate._patched_weapon_tweak_data = {}

function HUDTeammate:weapon_tweak_data( weapon_id, factory_id, blueprint )
	if self._patched_weapon_tweak_data and self._patched_weapon_tweak_data[weapon_id] then
		return self._patched_weapon_tweak_data[weapon_id] or tweak_data.weapon[weapon_id]
	end

	if ( factory_id and blueprint ) then
		self._patched_weapon_tweak_data[weapon_id] = managers.weapon_factory:get_modded_weapon_tweak_data( weapon_id, factory_id, blueprint )
	else
		return tweak_data.weapon[weapon_id]
	end

	return self._patched_weapon_tweak_data[weapon_id]
end

function HUDTeammate:_create_primary_weapon_firemode()
	local primary_weapon_panel = self._player_panel:child("weapons_panel"):child("primary_weapon_panel")
	local weapon_selection_panel = primary_weapon_panel:child("weapon_selection")
	local old_single = weapon_selection_panel:child("firemode_single")
	local old_auto = weapon_selection_panel:child("firemode_auto")

	if alive(old_single) then
		weapon_selection_panel:remove(old_single)
	end

	if alive(old_auto) then
		weapon_selection_panel:remove(old_auto)
	end

	if self._main_player then
		local equipped_primary = managers.blackmarket:equipped_primary()
		local weapon_tweak_data = self:weapon_tweak_data( equipped_primary.weapon_id, equipped_primary.factory_id, equipped_primary.blueprint )
		local fire_mode = weapon_tweak_data.FIRE_MODE
		local can_toggle_firemode = weapon_tweak_data.CAN_TOGGLE_FIREMODE
		local locked_to_auto = managers.weapon_factory:has_perk("fire_mode_auto", equipped_primary.factory_id, equipped_primary.blueprint)
		local locked_to_single = managers.weapon_factory:has_perk("fire_mode_single", equipped_primary.factory_id, equipped_primary.blueprint)
		local single_id = "firemode_single" .. ((not can_toggle_firemode or locked_to_single) and "_locked" or "")
		local texture, texture_rect = tweak_data.hud_icons:get_icon_data(single_id)
		local firemode_single = weapon_selection_panel:bitmap({
			name = "firemode_single",
			blend_mode = "mul",
			layer = 1,
			x = 2,
			texture = texture,
			texture_rect = texture_rect
		})

		firemode_single:set_bottom(weapon_selection_panel:h() - 2)
		firemode_single:hide()

		local auto_id = "firemode_auto" .. ((not can_toggle_firemode or locked_to_auto) and "_locked" or "")
		local texture, texture_rect = tweak_data.hud_icons:get_icon_data(auto_id)
		local firemode_auto = weapon_selection_panel:bitmap({
			name = "firemode_auto",
			blend_mode = "mul",
			layer = 1,
			x = 2,
			texture = texture,
			texture_rect = texture_rect
		})

		firemode_auto:set_bottom(weapon_selection_panel:h() - 2)
		firemode_auto:hide()

		if locked_to_single or not locked_to_auto and fire_mode == "single" then
			firemode_single:show()
		else
			firemode_auto:show()
		end
	end
end

function HUDTeammate:_create_secondary_weapon_firemode()
	local secondary_weapon_panel = self._player_panel:child("weapons_panel"):child("secondary_weapon_panel")
	local weapon_selection_panel = secondary_weapon_panel:child("weapon_selection")
	local old_single = weapon_selection_panel:child("firemode_single")
	local old_auto = weapon_selection_panel:child("firemode_auto")

	if alive(old_single) then
		weapon_selection_panel:remove(old_single)
	end

	if alive(old_auto) then
		weapon_selection_panel:remove(old_auto)
	end

	if self._main_player then
		local equipped_secondary = managers.blackmarket:equipped_secondary()
		local weapon_tweak_data = self:weapon_tweak_data( equipped_secondary.weapon_id, equipped_secondary.factory_id, equipped_secondary.blueprint )
		local fire_mode = weapon_tweak_data.FIRE_MODE
		local can_toggle_firemode = weapon_tweak_data.CAN_TOGGLE_FIREMODE
		local locked_to_auto = managers.weapon_factory:has_perk("fire_mode_auto", equipped_secondary.factory_id, equipped_secondary.blueprint)
		local locked_to_single = managers.weapon_factory:has_perk("fire_mode_single", equipped_secondary.factory_id, equipped_secondary.blueprint)
		local single_id = "firemode_single" .. ((not can_toggle_firemode or locked_to_single) and "_locked" or "")
		local texture, texture_rect = tweak_data.hud_icons:get_icon_data(single_id)
		local firemode_single = weapon_selection_panel:bitmap({
			name = "firemode_single",
			blend_mode = "mul",
			layer = 1,
			x = 2,
			texture = texture,
			texture_rect = texture_rect
		})

		firemode_single:set_bottom(weapon_selection_panel:h() - 2)
		firemode_single:hide()

		local auto_id = "firemode_auto" .. ((not can_toggle_firemode or locked_to_auto) and "_locked" or "")
		local texture, texture_rect = tweak_data.hud_icons:get_icon_data(auto_id)
		local firemode_auto = weapon_selection_panel:bitmap({
			name = "firemode_auto",
			blend_mode = "mul",
			layer = 1,
			x = 2,
			texture = texture,
			texture_rect = texture_rect
		})

		firemode_auto:set_bottom(weapon_selection_panel:h() - 2)
		firemode_auto:hide()

		if locked_to_single or not locked_to_auto and fire_mode == "single" then
			firemode_single:show()
		else
			firemode_auto:show()
		end
	end
end