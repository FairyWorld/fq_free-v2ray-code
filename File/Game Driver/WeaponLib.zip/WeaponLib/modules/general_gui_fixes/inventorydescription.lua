local function is_weapon_category(weapon_tweak, ...)
	local arg = {
		...
	}
	local categories = weapon_tweak.categories

	for i = 1, #arg, 1 do
		if table.contains(categories, arg[i]) then
			return true
		end
	end

	return false
end

function WeaponDescription._get_skill_stats(name, category, slot, base_stats, mods_stats, silencer, single_mod, auto_mod, blueprint)
	local skill_stats = {}
	local tweak_stats = tweak_data.weapon.stats

	for _, stat in pairs(WeaponDescription._stats_shown) do
		skill_stats[stat.name] = {
			value = 0
		}
	end

	local detection_risk = 0

	if category then
		local custom_data = {
			[category] = managers.blackmarket:get_crafted_category_slot(category, slot)
		}
		detection_risk = managers.blackmarket:get_suspicion_offset_from_custom_data(custom_data, tweak_data.player.SUSPICION_OFFSET_LERP or 0.75)
		detection_risk = detection_risk * 100
	end

	local base_value, base_index, modifier, multiplier = nil
	local factory_id = managers.weapon_factory:get_factory_id_by_weapon_id(name)
	local weapon_tweak = managers.weapon_factory:get_modded_weapon_tweak_data(name, factory_id, blueprint)
	local primary_category = weapon_tweak.categories[1]

	for _, stat in ipairs(WeaponDescription._stats_shown) do
		if weapon_tweak.stats[stat.stat_name or stat.name] or stat.name == "totalammo" or stat.name == "fire_rate" then
			if stat.name == "magazine" then
				skill_stats[stat.name].value = managers.player:upgrade_value(name, "clip_ammo_increase", 0)
				local has_magazine = weapon_tweak.has_magazine
				local add_modifier = false

				if is_weapon_category(weapon_tweak, "shotgun") and has_magazine then
					skill_stats[stat.name].value = skill_stats[stat.name].value + managers.player:upgrade_value("shotgun", "magazine_capacity_inc", 0)
					add_modifier = managers.player:has_category_upgrade("shotgun", "magazine_capacity_inc")

					if primary_category == "akimbo" then
						skill_stats[stat.name].value = skill_stats[stat.name].value * 2
					end
				elseif is_weapon_category(weapon_tweak, "pistol") and not is_weapon_category(weapon_tweak, "revolver") and managers.player:has_category_upgrade("pistol", "magazine_capacity_inc") then
					skill_stats[stat.name].value = skill_stats[stat.name].value + managers.player:upgrade_value("pistol", "magazine_capacity_inc", 0)

					if primary_category == "akimbo" then
						skill_stats[stat.name].value = skill_stats[stat.name].value * 2
					end

					add_modifier = true
				elseif is_weapon_category(weapon_tweak, "smg", "assault_rifle", "lmg") then
					skill_stats[stat.name].value = skill_stats[stat.name].value + managers.player:upgrade_value("player", "automatic_mag_increase", 0)
					add_modifier = managers.player:has_category_upgrade("player", "automatic_mag_increase")

					if primary_category == "akimbo" then
						skill_stats[stat.name].value = skill_stats[stat.name].value * 2
					end
				end

				if not weapon_tweak.upgrade_blocks or not weapon_tweak.upgrade_blocks.weapon or not table.contains(weapon_tweak.upgrade_blocks.weapon, "clip_ammo_increase") then
					skill_stats[stat.name].value = skill_stats[stat.name].value + managers.player:upgrade_value("weapon", "clip_ammo_increase", 0)
				end

				if not weapon_tweak.upgrade_blocks or not weapon_tweak.upgrade_blocks[primary_category] or not table.contains(weapon_tweak.upgrade_blocks[primary_category], "clip_ammo_increase") then
					skill_stats[stat.name].value = skill_stats[stat.name].value + managers.player:upgrade_value(primary_category, "clip_ammo_increase", 0)
				end

				skill_stats[stat.name].skill_in_effect = managers.player:has_category_upgrade(name, "clip_ammo_increase") or managers.player:has_category_upgrade("weapon", "clip_ammo_increase") or add_modifier
			elseif stat.name == "totalammo" then
				-- Nothing
			elseif stat.name == "reload" then
				local skill_in_effect = false
				local mult = 1

				for _, category in ipairs(weapon_tweak.categories) do
					if managers.player:has_category_upgrade(category, "reload_speed_multiplier") then
						mult = mult + 1 - managers.player:upgrade_value(category, "reload_speed_multiplier", 1)
						skill_in_effect = true
					end
				end

				mult = 1 / managers.blackmarket:_convert_add_to_mul(mult)
				local diff = base_stats[stat.name].value * mult - base_stats[stat.name].value
				skill_stats[stat.name].value = skill_stats[stat.name].value + diff
				skill_stats[stat.name].skill_in_effect = skill_in_effect
			else
				base_value = math.max(base_stats[stat.name].value + mods_stats[stat.name].value, 0)

				if base_stats[stat.name].index and mods_stats[stat.name].index then
					base_index = base_stats[stat.name].index + mods_stats[stat.name].index
				end

				multiplier = 1
				modifier = 0
				local is_single_shot = managers.weapon_factory:has_perk("fire_mode_single", factory_id, blueprint)

				if stat.name == "damage" then
					multiplier = managers.blackmarket:damage_multiplier(name, weapon_tweak.categories, silencer, detection_risk, nil, blueprint)
					modifier = math.floor(managers.blackmarket:damage_addend(name, weapon_tweak.categories, silencer, detection_risk, nil, blueprint) * tweak_data.gui.stats_present_multiplier * multiplier)
				elseif stat.name == "spread" then
					local fire_mode = single_mod and "single" or auto_mod and "auto" or weapon_tweak.FIRE_MODE or "single"
					multiplier = managers.blackmarket:accuracy_multiplier(name, weapon_tweak.categories, silencer, nil, nil, fire_mode, blueprint, nil, is_single_shot)
					modifier = managers.blackmarket:accuracy_addend(name, weapon_tweak.categories, base_index, silencer, nil, fire_mode, blueprint, nil, is_single_shot) * tweak_data.gui.stats_present_multiplier
				elseif stat.name == "recoil" then
					multiplier = managers.blackmarket:recoil_multiplier(name, weapon_tweak.categories, silencer, blueprint)
					modifier = managers.blackmarket:recoil_addend(name, weapon_tweak.categories, base_index, silencer, blueprint, nil, is_single_shot) * tweak_data.gui.stats_present_multiplier
				elseif stat.name == "suppression" then
					multiplier = managers.blackmarket:threat_multiplier(name, weapon_tweak.categories, silencer)
				elseif stat.name == "concealment" then
					if silencer and managers.player:has_category_upgrade("player", "silencer_concealment_increase") then
						modifier = managers.player:upgrade_value("player", "silencer_concealment_increase", 0)
					end

					if silencer and managers.player:has_category_upgrade("player", "silencer_concealment_penalty_decrease") then
						local stats = managers.weapon_factory:get_perk_stats("silencer", factory_id, blueprint)

						if stats and stats.concealment then
							modifier = modifier + math.min(managers.player:upgrade_value("player", "silencer_concealment_penalty_decrease", 0), math.abs(stats.concealment))
						end
					end
				elseif stat.name == "fire_rate" then
					multiplier = managers.blackmarket:fire_rate_multiplier(name, weapon_tweak.categories, silencer, detection_risk, nil, blueprint)
				end

				if modifier ~= 0 then
					local offset = math.min(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]]) * tweak_data.gui.stats_present_multiplier

					if stat.revert then
						modifier = -modifier
					end

					if stat.percent then
						local max_stat = stat.index and #tweak_stats[stat.name] or math.max(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]]) * tweak_data.gui.stats_present_multiplier

						if stat.offset then
							max_stat = max_stat - offset
						end

						local ratio = modifier / max_stat
						modifier = ratio * 100
					end
				end

				if stat.revert then
					multiplier = 1 / math.max(multiplier, 0.01)
				end

				skill_stats[stat.name].skill_in_effect = multiplier ~= 1 or modifier ~= 0
				skill_stats[stat.name].value = modifier + base_value * multiplier - base_value
			end
		end
	end

	return skill_stats
end

local function get_reload_time( weapon_id, tweak_data )
	if tweak_data.timers.reload_empty then
		return tweak_data.timers.reload_empty, tweak_data.timers.reload_not_empty
	elseif tweak_data.timers.shotgun_reload_shell then
		local empty = 0
		local tactical = 0
		empty = tweak_data.timers.shotgun_reload_shell * tweak_data.CLIP_AMMO_MAX
		empty = empty + tweak_data.timers.shotgun_reload_first_shell_offset + tweak_data.timers.shotgun_reload_enter
		empty = empty + tweak_data.timers.shotgun_reload_exit_empty
		tactical = tweak_data.timers.shotgun_reload_shell
		tactical = tactical + tweak_data.timers.shotgun_reload_first_shell_offset + tweak_data.timers.shotgun_reload_enter
		tactical = tactical + tweak_data.timers.shotgun_reload_exit_not_empty

		return empty, tactical
	else
		return managers.blackmarket:get_reload_animation_time(weapon_id), managers.blackmarket:get_reload_animation_time(weapon_id)
	end
end

function WeaponDescription._get_modded_base_stats(name, factory_id, blueprint)
	local modded_base_stats = {}
	local index = nil
	local tweak_stats = tweak_data.weapon.stats

	local base_stats = WeaponDescription._get_base_stats(name)
	local modded_tweak_data = managers.weapon_factory:get_modded_weapon_tweak_data(name, factory_id, blueprint)
	local modifier_stats = modded_tweak_data.stats_modifiers

	for _, stat in pairs(WeaponDescription._stats_shown) do
		modded_base_stats[stat.name] = {}

		if stat.name == "magazine" then
			modded_base_stats[stat.name].index = 0
			modded_base_stats[stat.name].value = modded_tweak_data.CLIP_AMMO_MAX
		elseif stat.name == "totalammo" then
			index = math.clamp(modded_tweak_data.stats.total_ammo_mod, 1, #tweak_stats.total_ammo_mod)
			modded_base_stats[stat.name].index = modded_tweak_data.stats.total_ammo_mod
			modded_base_stats[stat.name].value = modded_tweak_data.AMMO_MAX
		elseif stat.name == "fire_rate" then
			local fire_rate = 60 / modded_tweak_data.fire_mode_data.fire_rate
			modded_base_stats[stat.name].value = fire_rate / 10 * 10
		elseif stat.name == "reload" then
			index = math.clamp(modded_tweak_data.stats[stat.name], 1, #tweak_stats[stat.name])
			modded_base_stats[stat.name].index = modded_tweak_data.stats[stat.name]
			local reload_time = get_reload_time(name, modded_tweak_data)
			local mult = 1 / tweak_data.weapon.stats[stat.name][index]
			modded_base_stats[stat.name].value = reload_time * mult
		elseif tweak_stats[stat.name] then
			index = math.clamp(modded_tweak_data.stats[stat.name], 1, #tweak_stats[stat.name])
			modded_base_stats[stat.name].index = index
			modded_base_stats[stat.name].value = stat.index and index or tweak_stats[stat.name][index] * tweak_data.gui.stats_present_multiplier
			local offset = math.min(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]]) * tweak_data.gui.stats_present_multiplier

			if stat.offset then
				modded_base_stats[stat.name].value = modded_base_stats[stat.name].value - offset
			end

			if stat.revert then
				local max_stat = math.max(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]]) * tweak_data.gui.stats_present_multiplier

				if stat.offset then
					max_stat = max_stat - offset
				end

				modded_base_stats[stat.name].value = max_stat - modded_base_stats[stat.name].value
			end

			if modifier_stats and modifier_stats[stat.name] then
				local mod = modifier_stats[stat.name]

				if stat.revert and not stat.index then
					local real_base_value = tweak_stats[stat.name][index]
					local modded_value = real_base_value * mod
					local offset = math.min(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]])

					if stat.offset then
						modded_value = modded_value - offset
					end

					local max_stat = math.max(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]])

					if stat.offset then
						max_stat = max_stat - offset
					end

					local new_value = (max_stat - modded_value) * tweak_data.gui.stats_present_multiplier

					if mod ~= 0 and (tweak_stats[stat.name][1] < modded_value or modded_value < tweak_stats[stat.name][#tweak_stats[stat.name]]) then
						new_value = (new_value + base_stats[stat.name].value / mod) / 2
					end

					modded_base_stats[stat.name].value = new_value
				else
					modded_base_stats[stat.name].value = modded_base_stats[stat.name].value * mod
				end
			end

			if stat.percent then
				local max_stat = stat.index and #tweak_stats[stat.name] or math.max(tweak_stats[stat.name][1], tweak_stats[stat.name][#tweak_stats[stat.name]]) * tweak_data.gui.stats_present_multiplier

				if stat.offset then
					max_stat = max_stat - offset
				end

				local ratio = modded_base_stats[stat.name].value / max_stat
				modded_base_stats[stat.name].value = ratio * 100
			end
		end

		if base_stats[stat.name] then
			if base_stats[stat.name].value then
				modded_base_stats[stat.name].value = modded_base_stats[stat.name].value - base_stats[stat.name].value
			end
			if base_stats[stat.name].index then
				modded_base_stats[stat.name].index = modded_base_stats[stat.name].index - base_stats[stat.name].index
			end
		end
	end

	return modded_base_stats
end

function WeaponDescription.get_stats_for_mod(mod_name, weapon_name, category, slot)
	local equipped_mods = nil
	local blueprint = managers.blackmarket:get_weapon_blueprint(category, slot)
	local factory_id = managers.weapon_factory:get_factory_id_by_weapon_id(weapon_name)

	if blueprint then
		equipped_mods = deep_clone(blueprint)
		local default_blueprint = managers.weapon_factory:get_default_blueprint_by_factory_id(factory_id)

		for _, default_part in ipairs(default_blueprint) do
			table.delete(equipped_mods, default_part)
		end
	end

	local base_stats = WeaponDescription._get_base_stats(weapon_name)
	local mods_stats = WeaponDescription._get_mods_stats(weapon_name, base_stats, equipped_mods)
	local weapon_mod_stats = WeaponDescription._get_weapon_mod_stats(mod_name, weapon_name, base_stats, mods_stats, equipped_mods)

	local tweak_stats = tweak_data.weapon.stats

	for _, mod in pairs(weapon_mod_stats) do
		local modded_base_stats = WeaponDescription._get_modded_base_stats(weapon_name, factory_id, {mod.name})

		for __, stat in pairs(WeaponDescription._stats_shown) do
			if modded_base_stats[stat.name] then
				mod[stat.name] = mod[stat.name] or 0

				if modded_base_stats[stat.name].value and modded_base_stats[stat.name].value ~= 0 then
					mod[stat.name] = mod[stat.name] + modded_base_stats[stat.name].value
				end
				if modded_base_stats[stat.name].index and modded_base_stats[stat.name].index > 0 then
					local wanted_index = mod[stat.name] + modded_base_stats[stat.name].index

					if tweak_stats[stat.name] then
						wanted_index = math.clamp(wanted_index, 1, #tweak_stats[stat.name])
					end

					mod[stat.name] = wanted_index
				end
			end
		end
	end

	return weapon_mod_stats
end

function WeaponDescription._get_stats(name, category, slot, blueprint)
	local equipped_mods = nil
	local silencer = false
	local single_mod = false
	local auto_mod = false
	local factory_id = managers.weapon_factory:get_factory_id_by_weapon_id(name)
	local blueprint = blueprint or slot and managers.blackmarket:get_weapon_blueprint(category, slot) or managers.weapon_factory:get_default_blueprint_by_factory_id(factory_id)
	local cosmetics = managers.blackmarket:get_weapon_cosmetics(category, slot)
	local bonus_stats = {}

	if cosmetics and cosmetics.id and cosmetics.bonus and not managers.job:is_current_job_competitive() and not managers.weapon_factory:has_perk("bonus", factory_id, blueprint) then
		bonus_stats = tweak_data:get_raw_value("economy", "bonuses", tweak_data.blackmarket.weapon_skins[cosmetics.id].bonus, "stats") or {}
	end

	if blueprint then
		equipped_mods = deep_clone(blueprint)
		local factory_id = managers.weapon_factory:get_factory_id_by_weapon_id(name)
		local default_blueprint = managers.weapon_factory:get_default_blueprint_by_factory_id(factory_id)

		if equipped_mods then
			silencer = managers.weapon_factory:has_perk("silencer", factory_id, equipped_mods)
			single_mod = managers.weapon_factory:has_perk("fire_mode_single", factory_id, equipped_mods)
			auto_mod = managers.weapon_factory:has_perk("fire_mode_auto", factory_id, equipped_mods)
		end
	end

	local base_stats = WeaponDescription._get_base_stats(name)
	local mods_stats = WeaponDescription._get_mods_stats(name, base_stats, equipped_mods, bonus_stats)
	local skill_stats = WeaponDescription._get_skill_stats(name, category, slot, base_stats, mods_stats, silencer, single_mod, auto_mod, blueprint)
	local clip_ammo, max_ammo, ammo_data = WeaponDescription.get_weapon_ammo_info(name, tweak_data.weapon[name].stats.extra_ammo, base_stats.totalammo.index + mods_stats.totalammo.index)
	base_stats.totalammo.value = ammo_data.base
	mods_stats.totalammo.value = ammo_data.mod
	skill_stats.totalammo.value = ammo_data.skill
	skill_stats.totalammo.skill_in_effect = ammo_data.skill_in_effect
	local my_clip = base_stats.magazine.value + mods_stats.magazine.value + skill_stats.magazine.value

	if max_ammo < my_clip then
		mods_stats.magazine.value = mods_stats.magazine.value + max_ammo - my_clip
	end

	local tweak_stats = tweak_data.weapon.stats
	local modded_base_stats = WeaponDescription._get_modded_base_stats(name, factory_id, equipped_mods)

	for __, stat in pairs(WeaponDescription._stats_shown) do
		if mods_stats[stat.name] and modded_base_stats[stat.name] then
			mods_stats[stat.name] = mods_stats[stat.name] or { value = 0, index = 0 }
			if modded_base_stats[stat.name].value and modded_base_stats[stat.name].value ~= 0 then
				mods_stats[stat.name].value = mods_stats[stat.name].value + modded_base_stats[stat.name].value
			end
			if modded_base_stats[stat.name].index and modded_base_stats[stat.name].index > 0 then
				local wanted_index = ( mods_stats[stat.name].index or 0 ) + modded_base_stats[stat.name].index

				if tweak_stats[stat.name] then
					wanted_index = math.clamp(wanted_index, 1, #tweak_stats[stat.name])
				end

				mods_stats[stat.name].index = wanted_index
			end
		end
	end

	return base_stats, mods_stats, skill_stats
end