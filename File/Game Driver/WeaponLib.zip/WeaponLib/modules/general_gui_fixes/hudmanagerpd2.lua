function GetProperSelectionIndex( selection_index )
	if ( selection_index == 1 ) or ( selection_index == 4 ) then
		selection_index = 1
	elseif ( selection_index == 2 ) or ( selection_index == 3 ) then
		selection_index = 2
	end

	return selection_index
end

HUDManager.set_teammate_ammo_amount_orig = HUDManager.set_teammate_ammo_amount_orig or HUDManager.set_teammate_ammo_amount
function HUDManager:set_teammate_ammo_amount(id, selection_index, max_clip, current_clip, current_left, max)
	return self:set_teammate_ammo_amount_orig(id, GetProperSelectionIndex(selection_index), max_clip, current_clip, current_left, max)
end