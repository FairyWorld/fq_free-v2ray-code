function string.startswith(String, Start)
	return string.sub(String, 1, string.len(Start)) == Start
end
 
if Network and Network:is_server() then
	local elem_names = { "ai_spawn_", "cop", "cloaker", "dozer", "gangster", "shield", "sniper", "swat", "tazer", "thug", "phalanx" }
	for _, data in pairs(managers.mission._scripts) do
		for _, element in pairs(data:elements()) do
			if element and element._values and element._values.enabled then
				for _, name in pairs(elem_names) do
					if string.startswith(element._editor_name, name) then
						element._values.enabled = false
					end
				end
			end
		end
	end
end