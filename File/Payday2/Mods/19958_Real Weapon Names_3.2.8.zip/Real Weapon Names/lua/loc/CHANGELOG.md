## Unreleased:


## v3.2.8

### mods.en.json
|id|old string| new string
|--|--|--|
|bm_wp_m1911_m_extended|Extended Magazine|Chip McCormick Power Mag|
|bm_wp_m1911_sl_hardballer|Tussey Custom Caspian Arms 1911 Long Slide|AMT Javelina 10mm Slide|
|bm_wp_m1911_sl_match|Match Slide with Bomar Rib Sight|Series 70 National Match Slide with Bo-Mar Sight|

## v3.2.7:

### mods.en.json
|id|old string| new string
|--|--|--|
|bm_wp_pm9_b_short||No Flame Arrester|
|bm_wp_pm9_g_wood||Wooden Grip|
|bm_wp_pm9_m_quick||Speedpul Magazine|
|bm_wp_pm9_s_tactical||Custom Stock|
|bm_wp_groza_b_suppressed||Custom Suppressor|
|bm_wp_groza_m_speed||Speedpul Magazine|
|bm_wp_qbu88_b_long||Long Barrel|
|bm_wp_qbu88_b_short||Short Barrel|
|bm_wp_qbu88_m_extended||Extended Magazine|
|bm_wp_qbu88_o_standard||QBU-88 Iron Sights|
|bm_wp_pis_ppk_g_laser||Crimson Trace LG-480 Laser Grip|
|bm_wp_p226_g_ergo||Hogue MONOGRIP P226|

### weapons.en.json
|id|old string| new string
|--|--|--|
|bm_w_pm9||Minebea PM-9|
|bm_w_groza||OTs-14-4A Groza|
|bm_w_qbu88||Norinco QBU-88|
