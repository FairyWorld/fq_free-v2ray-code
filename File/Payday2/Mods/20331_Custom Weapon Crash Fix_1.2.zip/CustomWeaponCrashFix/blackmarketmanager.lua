function BlackMarketManager:get_silencer_concealment_modifiers(weapon)
	return 0
end

function BlackMarketManager:weapon_unlocked_by_crafted(category, slot)
	local crafted = self._global.crafted_items[category][slot]

	if not crafted then
		return false
	end

	local weapon_id = crafted.weapon_id
	local cosmetics = crafted.cosmetics
	local cosmetics_data = cosmetics and cosmetics.id and tweak_data.blackmarket.weapon_skins[cosmetics.id]
	local cosmetic_blueprint = cosmetics_data and cosmetics_data.default_blueprint or {}
	local data = Global.blackmarket_manager.weapons[weapon_id]
	
	-- Fixed check
	if not data then
		return false
	end
	
	local unlocked = data.unlocked

	if _G.IS_VR then
		unlocked = unlocked and not data.vr_locked
	end

	if unlocked then
		local is_any_part_dlc_locked = false

		for part_id, dlc in pairs(crafted.global_values or {}) do
			if not table.contains(cosmetic_blueprint, part_id) and dlc ~= "normal" and dlc ~= "infamous" and not managers.dlc:is_dlc_unlocked(dlc) then
				return false, dlc
			end
		end

		if cosmetics_data then
			local dlc = cosmetics_data.dlc or managers.dlc:global_value_to_dlc(cosmetics_data.global_value)

			if dlc and not managers.dlc:is_dlc_unlocked(dlc) then
				return false, dlc
			end
		end
	end

	if data.func_based and not self[data.func_based](self) then
		return false
	end

	if crafted.previewing then
		return false
	end

	return unlocked
end
