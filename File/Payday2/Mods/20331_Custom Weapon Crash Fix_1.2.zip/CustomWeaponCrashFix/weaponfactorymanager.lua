function WeaponFactoryManager:has_perk(perk_name, factory_id, blueprint)
	return false
end