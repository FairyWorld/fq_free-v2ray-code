local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)



-- SMGs --

self.hajk.CLIP_AMMO_MAX = 30
self.hajk.AMMO_MAX = 180  
self.hajk.stats.damage = 66
self.hajk.stats.spread = 20
self.hajk.stats.spread_moving = 16
self.hajk.stats.recoil = 18
self.hajk.stats.suppression = 10
self.hajk.fire_mode_data.fire_rate = 0.08
self.hajk.can_shoot_through_shield = false
self.hajk.armor_piercing_chance = 0.6
self.hajk.AMMO_PICKUP = {3, 5}
self.hajk.kick = {standing = { 1.2, 1.4, -0.3, 0.3 } }
self.hajk.kick.crouching = { 1, 1.2, -0.3, 0.3 }
self.hajk.kick.steelsight = { 1, 1.1, -0.3, 0.3 }



self.x_hajk.CLIP_AMMO_MAX = 60
self.x_hajk.AMMO_MAX = 240
self.x_hajk.stats.damage = 66
self.x_hajk.stats.spread = 16
self.x_hajk.stats.spread_moving = 14
self.x_hajk.stats.recoil = 16
self.x_hajk.stats.suppression = 8
self.x_hajk.fire_mode_data.fire_rate = 0.08
self.x_hajk.armor_piercing_chance = 0.6
self.x_hajk.AMMO_PICKUP = {4, 6}
self.x_hajk.kick = {standing = { 1.2, 1.4, -0.3, 0.3 } }
self.x_hajk.kick.crouching = { 1.1, 1.2, -0.3, 0.3 }
self.x_hajk.kick.steelsight = { 1, 1.1, -0.3, 0.3 }





self.polymer.CLIP_AMMO_MAX = 25
self.polymer.AMMO_MAX = 150
self.polymer.stats.damage = 56
self.polymer.stats.spread = 16
self.polymer.stats.spread_moving = 12
self.polymer.stats.recoil = 20
self.polymer.stats.suppression = 9
self.polymer.fire_mode_data.fire_rate = 0.05
self.polymer.can_shoot_through_shield = false
self.polymer.AMMO_PICKUP = {3, 6}
self.polymer.armor_piercing_chance = 0
self.polymer.kick = {standing = { 0.5, 0.7, -0.2, 0.2 } }
self.polymer.kick.crouching = { 0.4, 0.6, -0.2, 0.2 }
self.polymer.kick.steelsight = { 0.4, 0.6, -0.2, 0.2 }



self.x_polymer.CLIP_AMMO_MAX = 50
self.x_polymer.AMMO_MAX = 300
self.x_polymer.stats.damage = 56
self.x_polymer.stats.spread = 12
self.x_polymer.stats.spread_moving = 8
self.x_polymer.stats.recoil = 16
self.x_polymer.stats.suppression = 7
self.x_polymer.fire_mode_data.fire_rate = 0.05
self.x_polymer.can_shoot_through_shield = false
self.x_polymer.AMMO_PICKUP = {3, 6}
self.x_polymer.armor_piercing_chance = 0
self.x_polymer.kick = {standing = { 0.5, 0.7, -0.4, 0.4 } }
self.x_polymer.kick.crouching = { 0.5, 0.7, -0.3, 0.3 }
self.x_polymer.kick.steelsight = { 0.5, 0.6, -0.3, 0.3 }

self.m1928.CLIP_AMMO_MAX = 50
self.m1928.AMMO_MAX = 200
self.m1928.stats.damage = 58
self.m1928.stats.spread = 16
self.m1928.stats.spread_moving = 8
self.m1928.stats.recoil = 18
self.m1928.stats.suppression = 7
self.m1928.fire_mode_data.fire_rate = 0.08
self.m1928.can_shoot_through_shield = false
self.m1928.AMMO_PICKUP = {3, 5}
self.m1928.armor_piercing_chance = 0
self.m1928.kick = {standing = { 0.7, 0.9, -0.4, 0.4 } }
self.m1928.kick.crouching = { 0.6, 0.8, -0.4, 0.4 }
self.m1928.kick.steelsight = { 0.5, 0.7, -0.4, 0.4 }



self.x_m1928.CLIP_AMMO_MAX = 100
self.x_m1928.AMMO_MAX = 300
self.x_m1928.stats.damage = 58
self.x_m1928.stats.spread = 10
self.x_m1928.stats.spread_moving = 5
self.x_m1928.stats.recoil = 16
self.x_m1928.stats.suppression = 5
self.x_m1928.fire_mode_data.fire_rate = 0.08
self.x_m1928.can_shoot_through_shield = false
self.x_m1928.AMMO_PICKUP = {3, 5}
self.x_m1928.armor_piercing_chance = 0
self.x_m1928.kick = {standing = { 0.7, 0.9, -0.4, 0.4 } }
self.x_m1928.kick.crouching = { 0.6, 0.8, -0.4, 0.4 }
self.x_m1928.kick.steelsight = { 0.5, 0.7, -0.4, 0.4 }


self.schakal.CLIP_AMMO_MAX = 25
self.schakal.AMMO_MAX = 125
self.schakal.stats.damage = 56
self.schakal.stats.spread = 19
self.schakal.stats.spread_moving = 12
self.schakal.stats.recoil = 18
self.schakal.stats.suppression = 10
self.schakal.fire_mode_data.fire_rate = 0.1
self.schakal.can_shoot_through_shield = false
self.schakal.AMMO_PICKUP = {3, 6}
self.schakal.armor_piercing_chance = 0
self.schakal.kick = {standing = { 0.6, 0.7, -0.2, 0.2 } }
self.schakal.kick.crouching = { 0.5, 0.6, -0.2, 0.2 }
self.schakal.kick.steelsight = { 0.4, 0.5, -0.2, 0.2 }




self.x_schakal.CLIP_AMMO_MAX = 50
self.x_schakal.AMMO_MAX = 200
self.x_schakal.stats.damage = 56
self.x_schakal.stats.spread = 16
self.x_schakal.stats.spread_moving = 10
self.x_schakal.stats.recoil = 16
self.x_schakal.stats.suppression = 8
self.x_schakal.fire_mode_data.fire_rate = 0.1
self.x_schakal.can_shoot_through_shield = false
self.x_schakal.AMMO_PICKUP = {3, 6}
self.x_schakal.armor_piercing_chance = 0
self.x_schakal.kick = {standing = { 0.6, 0.7, -0.2, 0.2 } }
self.x_schakal.kick.crouching = { 0.5, 0.6, -0.2, 0.2 }
self.x_schakal.kick.steelsight = { 0.4, 0.5, -0.2, 0.2 }


self.new_mp5.CLIP_AMMO_MAX = 30
self.new_mp5.AMMO_MAX = 180
self.new_mp5.stats.damage = 42
self.new_mp5.stats.spread = 20
self.new_mp5.stats.spread_moving = 16
self.new_mp5.stats.recoil = 22
self.new_mp5.stats.suppression = 12
self.new_mp5.fire_mode_data.fire_rate = 0.075
self.new_mp5.can_shoot_through_shield = false
self.new_mp5.AMMO_PICKUP = {4, 8}
self.new_mp5.armor_piercing_chance = 0
self.new_mp5.kick = {standing = { 0.3, 0.5, -0.3, 0.3 } }
self.new_mp5.kick.crouching = { 0.2, 0.4, -0.3, 0.3 }
self.new_mp5.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }

self.x_mp5.CLIP_AMMO_MAX = 60
self.x_mp5.AMMO_MAX = 180
self.x_mp5.stats.damage = 42
self.x_mp5.stats.spread = 15
self.x_mp5.stats.spread_moving = 10
self.x_mp5.stats.recoil = 20
self.x_mp5.stats.suppression = 10
self.x_mp5.fire_mode_data.fire_rate = 0.075
self.x_mp5.can_shoot_through_shield = false
self.x_mp5.AMMO_PICKUP = {5, 9}
self.x_mp5.armor_piercing_chance = 0
self.x_mp5.kick = {standing = { 0.3, 0.5, -0.3, 0.3 } }
self.x_mp5.kick.crouching = { 0.2, 0.4, -0.3, 0.3 }
self.x_mp5.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }

self.sr2.CLIP_AMMO_MAX = 30
self.sr2.AMMO_MAX = 180
self.sr2.stats.damage = 44
self.sr2.stats.spread = 16
self.sr2.stats.spread_moving = 12
self.sr2.stats.recoil = 18
self.sr2.stats.suppression = 12
self.sr2.fire_mode_data.fire_rate = 0.08
self.sr2.can_shoot_through_shield = false
self.sr2.AMMO_PICKUP = {4, 6}
self.sr2.armor_piercing_chance = 0.2
self.sr2.kick = {standing = { 0.4, 0.5, -0.3, 0.3 } }
self.sr2.kick.crouching = { 0.4, 0.5, -0.3, 0.3 }
self.sr2.kick.steelsight = { 0.3, 0.4, -0.3, 0.3 }

self.x_sr2.CLIP_AMMO_MAX = 60
self.x_sr2.AMMO_MAX = 180
self.x_sr2.stats.damage = 44
self.x_sr2.stats.spread = 12
self.x_sr2.stats.spread_moving = 8
self.x_sr2.stats.recoil = 16
self.x_sr2.stats.suppression = 10
self.x_sr2.fire_mode_data.fire_rate = 0.08
self.x_sr2.can_shoot_through_shield = false
self.x_sr2.AMMO_PICKUP = {4, 8}
self.x_sr2.armor_piercing_chance = 0.2
self.x_sr2.kick = {standing = { 0.4, 0.5, -0.3, 0.3 } }
self.x_sr2.kick.crouching = { 0.4, 0.5, -0.3, 0.3 }
self.x_sr2.kick.steelsight = { 0.3, 0.4, -0.3, 0.3 }

self.sterling.CLIP_AMMO_MAX = 34
self.sterling.AMMO_MAX = 136
self.sterling.stats.damage = 42
self.sterling.stats.spread = 14
self.sterling.stats.spread_moving = 8
self.sterling.stats.recoil = 18
self.sterling.stats.suppression = 10
self.sterling.fire_mode_data.fire_rate = 0.109090
self.sterling.can_shoot_through_shield = false
self.sterling.AMMO_PICKUP = {4, 7}
self.sterling.armor_piercing_chance = 0
self.sterling.kick = {standing = { 0.4, 0.5, -0.4, 0.4 } }
self.sterling.kick.crouching = { 0.3, 0.4, -0.4, 0.4 }
self.sterling.kick.steelsight = { 0.3, 0.4, -0.4, 0.4 }


self.x_sterling.CLIP_AMMO_MAX = 68
self.x_sterling.AMMO_MAX = 272
self.x_sterling.stats.damage = 42
self.x_sterling.stats.spread = 10
self.x_sterling.stats.spread_moving = 8
self.x_sterling.stats.recoil = 16
self.x_sterling.stats.suppression = 8
self.x_sterling.fire_mode_data.fire_rate = 0.109090
self.x_sterling.can_shoot_through_shield = false
self.x_sterling.AMMO_PICKUP = {5, 8}
self.x_sterling.armor_piercing_chance = 0
self.x_sterling.kick = {standing = { 0.4, 0.5, -0.4, 0.4 } }
self.x_sterling.kick.crouching = { 0.3, 0.4, -0.4, 0.4 }
self.x_sterling.kick.steelsight = { 0.3, 0.4, -0.4, 0.4 }



self.m45.CLIP_AMMO_MAX = 36
self.m45.AMMO_MAX = 180
self.m45.stats.damage = 42
self.m45.stats.spread = 16
self.m45.stats.spread_moving = 10
self.m45.stats.recoil = 18
self.m45.stats.suppression = 10
self.m45.fire_mode_data.fire_rate = 0.1
self.m45.can_shoot_through_shield = false
self.m45.AMMO_PICKUP = {4, 7}
self.m45.armor_piercing_chance = 0
self.m45.kick = {standing = { 0.3, 0.5, -0.3, 0.3 } }
self.m45.kick.crouching = { 0.3, 0.4, -0.3, 0.3 }
self.m45.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }

self.x_m45.CLIP_AMMO_MAX = 72
self.x_m45.AMMO_MAX = 288
self.x_m45.stats.damage = 42
self.x_m45.stats.spread = 12
self.x_m45.stats.spread_moving = 8
self.x_m45.stats.recoil = 16
self.x_m45.stats.suppression = 8
self.x_m45.fire_mode_data.fire_rate = 0.1
self.x_m45.can_shoot_through_shield = false
self.x_m45.AMMO_PICKUP = {5, 9}
self.x_m45.armor_piercing_chance = 0
self.x_m45.kick = {standing = { 0.3, 0.5, -0.3, 0.3 } }
self.x_m45.kick.crouching = { 0.3, 0.4, -0.3, 0.3 }
self.x_m45.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }

self.uzi.CLIP_AMMO_MAX = 32
self.uzi.AMMO_MAX = 192
self.uzi.stats.damage = 42
self.uzi.stats.spread = 15
self.uzi.stats.spread_moving = 9
self.uzi.stats.recoil = 18
self.uzi.stats.suppression = 12
self.uzi.fire_mode_data.fire_rate = 0.0923
self.uzi.can_shoot_through_shield = false
self.uzi.AMMO_PICKUP = {4, 8}
self.uzi.armor_piercing_chance = 0
self.uzi.kick = {standing = { 0.4, 0.5, -0.4, 0.4 } }
self.uzi.kick.crouching = { 0.3, 0.4, -0.4, 0.4 }
self.uzi.kick.steelsight = { 0.2, 0.4, -0.4, 0.4 }



self.x_uzi.CLIP_AMMO_MAX = 64
self.x_uzi.AMMO_MAX = 320
self.x_uzi.stats.damage = 42
self.x_uzi.stats.spread = 9
self.x_uzi.stats.spread_moving = 6
self.x_uzi.stats.recoil = 16
self.x_uzi.stats.suppression = 8
self.x_uzi.fire_mode_data.fire_rate = 0.0923
self.x_uzi.can_shoot_through_shield = false
self.x_uzi.AMMO_PICKUP = {5, 9}
self.x_uzi.armor_piercing_chance = 0
self.x_uzi.kick = {standing = { 0.4, 0.5, -0.4, 0.4 } }
self.x_uzi.kick.crouching = { 0.3, 0.4, -0.4, 0.4 }
self.x_uzi.kick.steelsight = { 0.2, 0.4, -0.4, 0.4 }

self.baka.CLIP_AMMO_MAX = 32
self.baka.AMMO_MAX = 224
self.baka.stats.damage = 41
self.baka.stats.spread = 8
self.baka.stats.spread_moving = 6
self.baka.stats.recoil = 16
self.baka.stats.suppression = 10
self.baka.fire_mode_data.fire_rate = 0.06
self.baka.can_shoot_through_shield = false
self.baka.AMMO_PICKUP = {4.5, 7.5}
self.baka.armor_piercing_chance = 0
self.baka.kick = {standing = { 0.5, 0.5, -0.6, 0.6 } }
self.baka.kick.crouching = { 0.5, 0.5, -0.6, 0.6 }
self.baka.kick.steelsight = { 0.4, 0.4, -0.6, 0.6 }

self.x_baka.CLIP_AMMO_MAX = 64
self.x_baka.AMMO_MAX = 320
self.x_baka.stats.damage = 41
self.x_baka.stats.spread = 6
self.x_baka.stats.spread_moving = 4
self.x_baka.stats.recoil = 15
self.x_baka.stats.suppression = 7
self.x_baka.fire_mode_data.fire_rate = 0.06
self.x_baka.can_shoot_through_shield = false
self.x_baka.AMMO_PICKUP = {5, 9}
self.x_baka.armor_piercing_chance = 0
self.x_baka.kick = {standing = { 0.5, 0.5, -0.6, 0.6 } }
self.x_baka.kick.crouching = { 0.5, 0.5, -0.6, 0.6 }
self.x_baka.kick.steelsight = { 0.4, 0.4, -0.6, 0.6 }

self.scorpion.CLIP_AMMO_MAX = 20
self.scorpion.AMMO_MAX = 120
self.scorpion.stats.damage = 39
self.scorpion.stats.spread = 10
self.scorpion.stats.spread_moving = 5
self.scorpion.stats.recoil = 20
self.scorpion.stats.suppression = 12
self.scorpion.fire_mode_data.fire_rate = 0.0705882
self.scorpion.can_shoot_through_shield = false
self.scorpion.stats.concealment = 30
self.scorpion.AMMO_PICKUP = {5, 9}
self.scorpion.armor_piercing_chance = 0
self.scorpion.kick = {standing = { 0.2, 0.3, -0.2, 0.2 } }
self.scorpion.kick.crouching = { 0.2, 0.3, -0.2, 0.2 }
self.scorpion.kick.steelsight = { 0.2, 0.2, -0.2, 0.2 }


self.x_scorpion.CLIP_AMMO_MAX = 40
self.x_scorpion.AMMO_MAX = 240
self.x_scorpion.stats.damage = 39
self.x_scorpion.stats.spread = 6
self.x_scorpion.stats.spread_moving = 4
self.x_scorpion.stats.recoil = 18
self.x_scorpion.stats.suppression = 8
self.x_scorpion.fire_mode_data.fire_rate = 0.0705882
self.x_scorpion.can_shoot_through_shield = false
self.x_scorpion.stats.concealment = 28
self.x_scorpion.AMMO_PICKUP = {6, 9}
self.x_scorpion.armor_piercing_chance = 0
self.x_scorpion.kick = {standing = { 0.2, 0.3, -0.2, 0.2 } }
self.x_scorpion.kick.crouching = { 0.2, 0.3, -0.2, 0.2 }
self.x_scorpion.kick.steelsight = { 0.2, 0.2, -0.2, 0.2 }

self.mp9.CLIP_AMMO_MAX = 20
self.mp9.AMMO_MAX = 120
self.mp9.stats.damage = 41
self.mp9.stats.spread = 15
self.mp9.stats.spread_moving = 10
self.mp9.stats.recoil = 20
self.mp9.stats.suppression = 12
self.mp9.fire_mode_data.fire_rate = 0.06666
self.mp9.can_shoot_through_shield = false
self.mp9.AMMO_PICKUP = {5, 8}
self.mp9.armor_piercing_chance = 0
self.mp9.kick = {standing = { 0.4, 0.5, -0.3, 0.3 } }
self.mp9.kick.crouching = { 0.3, 0.4, -0.3, 0.3 }
self.mp9.kick.steelsight = { 0.3, 0.3, -0.3, 0.3 }


self.x_mp9.CLIP_AMMO_MAX = 40
self.x_mp9.AMMO_MAX = 240
self.x_mp9.stats.damage = 41
self.x_mp9.stats.spread = 13
self.x_mp9.stats.spread_moving = 8
self.x_mp9.stats.recoil = 18
self.x_mp9.stats.suppression = 8
self.x_mp9.fire_mode_data.fire_rate = 0.06666
self.x_mp9.can_shoot_through_shield = false
self.x_mp9.AMMO_PICKUP = {5, 9}
self.x_mp9.armor_piercing_chance = 0
self.x_mp9.kick = {standing = { 0.4, 0.5, -0.3, 0.3 } }
self.x_mp9.kick.crouching = { 0.3, 0.4, -0.3, 0.3 }
self.x_mp9.kick.steelsight = { 0.3, 0.3, -0.3, 0.3 }

self.mac10.CLIP_AMMO_MAX = 20
self.mac10.AMMO_MAX = 120
self.mac10.stats.damage = 55
self.mac10.stats.spread = 12
self.mac10.stats.spread_moving = 8
self.mac10.stats.recoil = 16
self.mac10.stats.suppression = 10
self.mac10.fire_mode_data.fire_rate = 0.06
self.mac10.can_shoot_through_shield = false
self.mac10.AMMO_PICKUP = {3, 6}
self.mac10.armor_piercing_chance = 0
self.mac10.timers.reload_not_empty = 1.65
self.mac10.timers.reload_empty = 2.35
self.mac10.kick = {standing = { 0.5, 0.7, -0.6, 0.6 } }
self.mac10.kick.crouching = { 0.4, 0.6, -0.6, 0.6 }
self.mac10.kick.steelsight = { 0.4, 0.5, -0.5, 0.5 }

self.x_mac10.CLIP_AMMO_MAX = 40
self.x_mac10.AMMO_MAX = 200
self.x_mac10.stats.damage = 55
self.x_mac10.stats.spread = 8
self.x_mac10.stats.spread_moving = 4
self.x_mac10.stats.recoil = 14
self.x_mac10.stats.suppression = 8
self.x_mac10.fire_mode_data.fire_rate = 0.06
self.x_mac10.can_shoot_through_shield = false
self.x_mac10.AMMO_PICKUP = {4, 8}
self.x_mac10.armor_piercing_chance = 0
self.x_mac10.kick = {standing = { 0.5, 0.7, -0.6, 0.6 } }
self.x_mac10.kick.crouching = { 0.4, 0.6, -0.6, 0.6 }
self.x_mac10.kick.steelsight = { 0.4, 0.5, -0.5, 0.5 }

self.cobray.CLIP_AMMO_MAX = 32
self.cobray.AMMO_MAX = 224
self.cobray.stats.damage = 42
self.cobray.stats.spread = 11
self.cobray.stats.spread_moving = 7
self.cobray.stats.recoil = 18
self.cobray.stats.suppression = 10
self.cobray.fire_mode_data.fire_rate = 0.0705882
self.cobray.can_shoot_through_shield = false
self.cobray.AMMO_PICKUP = {4, 8}
self.cobray.armor_piercing_chance = 0
self.cobray.kick = {standing = { 0.4, 0.5, -0.5, 0.5 } }
self.cobray.kick.crouching = { 0.3, 0.4, -0.5, 0.5 }
self.cobray.kick.steelsight = { 0.2, 0.4, -0.4, 0.4 }


self.x_cobray.CLIP_AMMO_MAX = 64
self.x_cobray.AMMO_MAX = 256
self.x_cobray.stats.damage = 42
self.x_cobray.stats.spread = 9
self.x_cobray.stats.spread_moving = 5
self.x_cobray.stats.recoil = 16
self.x_cobray.stats.suppression = 8
self.x_cobray.fire_mode_data.fire_rate = 0.0705882
self.x_cobray.can_shoot_through_shield = false
self.x_cobray.AMMO_PICKUP = {5, 8}
self.x_cobray.armor_piercing_chance = 0
self.x_cobray.kick = {standing = { 0.4, 0.5, -0.5, 0.5 } }
self.x_cobray.kick.crouching = { 0.3, 0.4, -0.5, 0.5 }
self.x_cobray.kick.steelsight = { 0.2, 0.4, -0.5, 0.5 }


self.mp7.CLIP_AMMO_MAX = 20
self.mp7.AMMO_MAX = 140
self.mp7.stats.damage = 58
self.mp7.stats.spread = 20
self.mp7.stats.spread_moving = 16
self.mp7.stats.recoil = 22
self.mp7.stats.suppression = 12
self.mp7.fire_mode_data.fire_rate = 0.06666
self.mp7.can_shoot_through_shield = false
self.mp7.armor_piercing_chance = 0.5
self.mp7.AMMO_PICKUP = {3, 5}
self.mp7.kick = {standing = { 0.4, 0.4, -0.2, 0.2 } }
self.mp7.kick.crouching = { 0.3, 0.3, -0.2, 0.2 }
self.mp7.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.x_mp7.CLIP_AMMO_MAX = 40
self.x_mp7.AMMO_MAX = 200
self.x_mp7.stats.damage = 58
self.x_mp7.stats.spread = 16
self.x_mp7.stats.spread_moving = 14
self.x_mp7.stats.recoil = 20
self.x_mp7.stats.suppression = 8
self.x_mp7.fire_mode_data.fire_rate = 0.06666
self.x_mp7.can_shoot_through_shield = false
self.x_mp7.armor_piercing_chance = 0.5
self.x_mp7.AMMO_PICKUP = {4, 7}
self.x_mp7.kick = {standing = { 0.4, 0.4, -0.2, 0.2 } }
self.x_mp7.kick.crouching = { 0.3, 0.3, -0.2, 0.2 }
self.x_mp7.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }

self.p90.CLIP_AMMO_MAX = 50
self.p90.AMMO_MAX = 250
self.p90.stats.damage = 59
self.p90.stats.spread = 22
self.p90.stats.spread_moving = 16
self.p90.stats.recoil = 18
self.p90.stats.suppression = 10
self.p90.fire_mode_data.fire_rate = 0.06666
self.p90.can_shoot_through_shield = false
self.p90.armor_piercing_chance = 0.5
self.p90.AMMO_PICKUP = {2, 4}
self.p90.kick = {standing = { 0.4, 0.4, -0.4, 0.4 } }
self.p90.kick.crouching = { 0.3, 0.3, -0.4, 0.4 }
self.p90.kick.steelsight = { 0.3, 0.3, -0.4, 0.4 }


self.x_p90.CLIP_AMMO_MAX = 100
self.x_p90.AMMO_MAX = 400
self.x_p90.stats.damage = 59
self.x_p90.stats.spread = 16
self.x_p90.stats.spread_moving = 14
self.x_p90.stats.recoil = 16
self.x_p90.stats.suppression = 7
self.x_p90.fire_mode_data.fire_rate = 0.06666
self.x_p90.can_shoot_through_shield = false
self.x_p90.armor_piercing_chance = 0.5
self.x_p90.AMMO_PICKUP = {3, 5}
self.x_p90.kick = {standing = { 0.4, 0.4, -0.4, 0.4 } }
self.x_p90.kick.crouching = { 0.3, 0.3, -0.4, 0.4 }
self.x_p90.kick.steelsight = { 0.3, 0.3, -0.4, 0.4 }

self.coal.CLIP_AMMO_MAX = 64
self.coal.AMMO_MAX = 256
self.coal.stats.damage = 40
self.coal.stats.spread = 18
self.coal.stats.spread_moving = 10
self.coal.stats.recoil = 21
self.coal.stats.suppression = 10
self.coal.fire_mode_data.fire_rate = 0.0920245
self.coal.can_shoot_through_shield = false
self.coal.AMMO_PICKUP = {4, 8}
self.coal.armor_piercing_chance = 0
self.coal.kick = {standing = { 0.3, 0.5, -0.2, 0.2 } }
self.coal.kick.crouching = { 0.2, 0.4, -0.2, 0.2 }
self.coal.kick.steelsight = { 0.2, 0.3, -0.2, 0.2 }

self.x_coal.CLIP_AMMO_MAX = 128
self.x_coal.AMMO_MAX = 384
self.x_coal.stats.damage = 40
self.x_coal.stats.spread = 16
self.x_coal.stats.spread_moving = 8
self.x_coal.stats.recoil = 18
self.x_coal.stats.suppression = 8
self.x_coal.fire_mode_data.fire_rate = 0.0920245
self.x_coal.can_shoot_through_shield = false
self.x_coal.AMMO_PICKUP = {5, 9}
self.x_coal.armor_piercing_chance = 0
self.x_coal.kick = {standing = { 0.3, 0.5, -0.2, 0.2 } }
self.x_coal.kick.crouching = { 0.2, 0.4, -0.2, 0.2 }
self.x_coal.kick.steelsight = { 0.2, 0.3, -0.2, 0.2 }

self.tec9.CLIP_AMMO_MAX = 20
self.tec9.AMMO_MAX = 120
self.tec9.stats.damage = 41
self.tec9.stats.spread = 12
self.tec9.stats.spread_moving = 8
self.tec9.stats.recoil = 18
self.tec9.stats.suppression = 12
self.tec9.fire_mode_data.fire_rate = 0.06741573
self.tec9.can_shoot_through_shield = false
self.tec9.AMMO_PICKUP = {5, 8}
self.tec9.armor_piercing_chance = 0
self.tec9.CAN_TOGGLE_FIREMODE = false
self.tec9.FIRE_MODE = "single"
self.tec9.kick = {standing = { 0.3, 0.4, -0.6, 0.6 } }
self.tec9.kick.crouching = { 0.2, 0.3, -0.6, 0.6 }
self.tec9.kick.steelsight = { 0.2, 0.3, -0.5, 0.5 }


self.x_tec9.CLIP_AMMO_MAX = 40
self.x_tec9.AMMO_MAX = 240
self.x_tec9.stats.damage = 41
self.x_tec9.stats.spread = 8
self.x_tec9.stats.spread_moving = 6
self.x_tec9.stats.recoil = 14
self.x_tec9.stats.suppression = 8
self.x_tec9.fire_mode_data.fire_rate = 0.06741573
self.x_tec9.can_shoot_through_shield = false
self.x_tec9.AMMO_PICKUP = {5, 9}
self.x_tec9.armor_piercing_chance = 0
self.x_tec9.CAN_TOGGLE_FIREMODE = false
self.x_tec9.FIRE_MODE = "single"
self.x_tec9.kick = {standing = { 0.3, 0.4, -0.6, 0.6 } }
self.x_tec9.kick.crouching = { 0.2, 0.3, -0.6, 0.6 }
self.x_tec9.kick.steelsight = { 0.2, 0.3, -0.5, 0.5 }


self.erma.CLIP_AMMO_MAX = 32
self.erma.AMMO_MAX = 192
self.erma.stats.damage = 42
self.erma.stats.spread = 15
self.erma.stats.spread_moving = 12
self.erma.stats.recoil = 20
self.erma.stats.suppression = 12
self.erma.fire_mode_data.fire_rate = 0.109090
self.erma.can_shoot_through_shield = false
self.erma.AMMO_PICKUP = {4, 8}
self.erma.armor_piercing_chance = 0
self.erma.kick = {standing = { 0.3, 0.5, -0.4, 0.4 } }
self.erma.kick.crouching = { 0.3, 0.4, -0.4, 0.4 }
self.erma.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }


self.x_erma.CLIP_AMMO_MAX = 64
self.x_erma.AMMO_MAX = 320
self.x_erma.stats.damage = 42
self.x_erma.stats.spread = 12
self.x_erma.stats.spread_moving = 9
self.x_erma.stats.recoil = 18
self.x_erma.stats.suppression = 9
self.x_erma.fire_mode_data.fire_rate = 0.109090
self.x_erma.can_shoot_through_shield = false
self.x_erma.AMMO_PICKUP = {5, 9}
self.x_erma.armor_piercing_chance = 0
self.x_erma.kick = {standing = { 0.3, 0.5, -0.4, 0.4 } }
self.x_erma.kick.crouching = { 0.3, 0.4, -0.4, 0.4 }
self.x_erma.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }


self.shepheard.CLIP_AMMO_MAX = 20
self.shepheard.AMMO_MAX = 140
self.shepheard.stats.damage = 42
self.shepheard.stats.spread = 23
self.shepheard.stats.spread_moving = 16
self.shepheard.stats.recoil = 20
self.shepheard.stats.suppression = 12
self.shepheard.AMMO_PICKUP = {4, 8}
self.shepheard.armor_piercing_chance = 0
self.shepheard.kick = {standing = { 0.3, 0.4, -0.2, 0.2 } }
self.shepheard.kick.crouching = { 0.2, 0.4, -0.2, 0.2 }
self.shepheard.kick.steelsight = { 0.2, 0.3, -0.2, 0.2 }

self.x_shepheard.CLIP_AMMO_MAX = 40
self.x_shepheard.AMMO_MAX = 160
self.x_shepheard.stats.damage = 42
self.x_shepheard.stats.spread = 18
self.x_shepheard.stats.spread = 20
self.x_shepheard.stats.recoil = 16
self.x_shepheard.AMMO_PICKUP = {5, 9}
self.x_shepheard.armor_piercing_chance = 0
self.x_shepheard.stats.suppression = 9
self.x_shepheard.kick = {standing = { 0.3, 0.4, -0.2, 0.2 } }
self.x_shepheard.kick.crouching = { 0.2, 0.4, -0.2, 0.2 }
self.x_shepheard.kick.steelsight = { 0.2, 0.3, -0.2, 0.2 }

self.vityaz.CLIP_AMMO_MAX = 30
self.vityaz.AMMO_MAX = 180
self.vityaz.stats.damage = 42
self.vityaz.stats.spread = 20
self.vityaz.stats.spread_moving = 15
self.vityaz.stats.recoil = 22
self.vityaz.stats.suppression = 10
self.vityaz.AMMO_PICKUP = {5, 9}
self.vityaz.fire_mode_data.fire_rate = 0.075
self.vityaz.armor_piercing_chance = 0
self.vityaz.kick = {standing = { 0.3, 0.4, -0.4, 0.4 } }
self.vityaz.kick.crouching = { 0.3, 0.3, -0.4, 0.4 }
self.vityaz.kick.steelsight = { 0.3, 0.3, -0.4, 0.4 }

self.x_vityaz.CLIP_AMMO_MAX = 60
self.x_vityaz.AMMO_MAX = 300
self.x_vityaz.stats.damage = 42
self.x_vityaz.stats.spread = 16
self.x_vityaz.stats.spread_moving = 8
self.x_vityaz.stats.recoil = 18
self.x_vityaz.stats.suppression = 16
self.x_vityaz.AMMO_PICKUP = {6, 12}
self.x_vityaz.fire_mode_data.fire_rate = 0.075
self.x_vityaz.armor_piercing_chance = 0
self.x_vityaz.kick = {standing = { 0.3, 0.4, -0.4, 0.4 } }
self.x_vityaz.kick.crouching = { 0.3, 0.3, -0.4, 0.4 }
self.x_vityaz.kick.steelsight = { 0.3, 0.3, -0.4, 0.4 }

self.pm9.CLIP_AMMO_MAX = 25
self.pm9.AMMO_MAX = 250
self.pm9.stats.damage = 41
self.pm9.stats.spread = 12
self.pm9.stats.spread_moving = 10
self.pm9.stats.recoil = 20
self.pm9.stats.suppression = 8
self.pm9.fire_mode_data.fire_rate = 0.05
self.pm9.can_shoot_through_shield = false
self.pm9.AMMO_PICKUP = {5.5, 8}
self.pm9.armor_piercing_chance = 0
self.pm9.kick = {standing = { 0.5, 0.5, -0.3, 0.3 } }
self.pm9.kick.crouching = { 0.5, 0.5, -0.3, 0.3 }
self.pm9.kick.steelsight = { 0.4, 0.4, -0.3, 0.3 }

self.x_pm9.CLIP_AMMO_MAX = 50
self.x_pm9.AMMO_MAX = 450
self.x_pm9.stats.damage = 41
self.x_pm9.stats.spread = 12
self.x_pm9.stats.spread_moving = 10
self.x_pm9.stats.recoil = 20
self.x_pm9.stats.suppression = 4
self.x_pm9.fire_mode_data.fire_rate = 0.05
self.x_pm9.can_shoot_through_shield = false
self.x_pm9.AMMO_PICKUP = {7, 10}
self.x_pm9.armor_piercing_chance = 0
self.x_pm9.kick = {standing = { 0.5, 0.5, -0.3, 0.3 } }
self.x_pm9.kick.crouching = { 0.5, 0.5, -0.3, 0.3 }
self.x_pm9.kick.steelsight = { 0.4, 0.4, -0.3, 0.3 }






-- AR15s/HK416 --

self.olympic.CLIP_AMMO_MAX = 20
self.olympic.AMMO_MAX = 120
self.olympic.stats.damage = 62
self.olympic.stats.spread = 16
self.olympic.stats.spread_moving = 10
self.olympic.stats.recoil = 20
self.olympic.stats.suppression = 12
self.olympic.fire_mode_data.fire_rate = 0.0923
self.olympic.can_shoot_through_shield = false
self.olympic.armor_piercing_chance = 0.6
self.olympic.AMMO_PICKUP = {3, 6}
self.olympic.kick = {standing = { 1.4, 1.4, -0.5, 0.5 } }
self.olympic.kick.crouching = { 1.4, 1.4, -0.5, 0.5 }
self.olympic.kick.steelsight = { 1.3, 1.3, -0.4, 0.4 }

self.x_olympic.CLIP_AMMO_MAX = 40
self.x_olympic.AMMO_MAX = 240
self.x_olympic.stats.damage = 62
self.x_olympic.stats.spread = 12
self.x_olympic.stats.spread_moving = 8
self.x_olympic.stats.recoil = 18
self.x_olympic.stats.suppression = 8
self.x_olympic.fire_mode_data.fire_rate = 0.0923
self.x_olympic.can_shoot_through_shield = false
self.x_olympic.armor_piercing_chance = 0.6
self.x_olympic.AMMO_PICKUP = {4, 7}
self.x_olympic.kick = {standing = { 1.4, 1.4, -0.5, 0.5 } }
self.x_olympic.kick.crouching = { 1.4, 1.4, -0.5, 0.5 }
self.x_olympic.kick.steelsight = { 1.3, 1.3, -0.4, 0.4 }

self.amcar.CLIP_AMMO_MAX = 20
self.amcar.AMMO_MAX = 180     
self.amcar.stats.damage = 65
self.amcar.stats.spread = 18
self.amcar.stats.spread_moving = 12
self.amcar.stats.recoil = 19
self.amcar.stats.suppression = 12
self.amcar.fire_mode_data.fire_rate = 0.1
self.amcar.can_shoot_through_shield = false
self.amcar.armor_piercing_chance = 0.6
self.amcar.AMMO_PICKUP = {3, 6}
self.amcar.kick = {standing = { 1, 1.2, -0.4, 0.4 } }
self.amcar.kick.crouching = { 1, 1.1, -0.3, 0.3 }
self.amcar.kick.steelsight = { 0.8, 1, -0.3, 0.3 }




self.new_m4.CLIP_AMMO_MAX = 30
self.new_m4.AMMO_MAX = 180
self.new_m4.stats.damage = 66
self.new_m4.stats.spread = 20
self.new_m4.stats.spread_moving = 16
self.new_m4.stats.recoil = 20
self.new_m4.stats.suppression = 12
self.new_m4.fire_mode_data.fire_rate = 0.0857
self.new_m4.can_shoot_through_shield = false
self.new_m4.armor_piercing_chance = 0.6
self.new_m4.AMMO_PICKUP = {3, 6}
self.new_m4.kick = {standing = { 1, 1.2, -0.3, 0.3 } }
self.new_m4.kick.crouching = { 1, 1.1, -0.3, 0.3 }
self.new_m4.kick.steelsight = { 0.8, 1, -0.3, 0.3 }

self.m16.CLIP_AMMO_MAX = 20
self.m16.AMMO_MAX = 180
self.m16.stats.damage = 68
self.m16.stats.spread = 23
self.m16.stats.spread_moving = 18
self.m16.stats.recoil = 21
self.m16.stats.suppression = 10
self.m16.fire_mode_data.fire_rate = 0.08
self.m16.can_shoot_through_shield = false
self.m16.armor_piercing_chance = 0.7
self.m16.AMMO_PICKUP = {3, 6}
self.m16.kick = {standing = { 1, 1.2, -0.4, 0.4 } }
self.m16.kick.crouching = { 0.9, 1, -0.3, 0.3 }
self.m16.kick.steelsight = { 1, 1.2, -0.4, 0.4 }



self.tecci.CLIP_AMMO_MAX = 100 
self.tecci.AMMO_MAX = 200     
self.tecci.stats.damage = 65 
self.tecci.stats.spread = 17
self.tecci.stats.spread_moving = 12
self.tecci.stats.recoil = 18
self.tecci.stats.suppression = 8
self.tecci.fire_mode_data.fire_rate = 0.085714
self.tecci.can_shoot_through_shield = false
self.tecci.armor_piercing_chance = 0.6
self.tecci.AMMO_PICKUP = {3, 5}
self.tecci.kick = {standing = { 1, 1.2, -0.5, 0.5 } }
self.tecci.kick.crouching = { 1, 1.1, -0.5, 0.5 }
self.tecci.kick.steelsight = { 0.8, 1, -0.4, 0.4 }

self.contraband.CLIP_AMMO_MAX = 20
self.contraband.AMMO_MAX = 80
self.contraband.stats.damage = 95
self.contraband.stats.spread = 23
self.contraband.stats.spread_moving = 14
self.contraband.stats.recoil = 15
self.contraband.stats.suppression = 12
self.contraband.armor_piercing_chance = 0.8
self.contraband.fire_mode_data.fire_rate = 0.1
self.contraband.can_shoot_through_shield = false
self.contraband.AMMO_PICKUP = {1, 2}
self.contraband.FIRE_MODE = "auto"
self.contraband.kick = {standing = { 1.6, 1.6, -0.4, 0.4 } }
self.contraband.kick.crouching = { 1.6, 1.6, -0.4, 0.4 }
self.contraband.kick.steelsight = { 1.6, 1.6, -0.3, 0.3 }

self.contraband_m203.CLIP_AMMO_MAX = 1
self.contraband_m203.AMMO_MAX = 3
self.contraband_m203.stats.damage = 80
self.contraband_m203.stats.spread = 12
self.contraband_m203.stats.recoil = 8
self.contraband_m203.stats.suppression = 4
self.contraband_m203.fire_mode_data.fire_rate = 1
self.contraband_m203.can_shoot_through_shield = false
self.contraband_m203.AMMO_PICKUP = {0.2, 0.5}











-- Assault Rifles --

self.galil.CLIP_AMMO_MAX = 25
self.galil.AMMO_MAX = 100
self.galil.stats.damage = 95
self.galil.stats.spread = 18
self.galil.stats.spread_moving = 12
self.galil.stats.recoil = 16
self.galil.stats.suppression = 11
self.galil.fire_mode_data.fire_rate = 0.08
self.galil.can_shoot_through_shield = false
self.galil.armor_piercing_chance = 0.8
self.galil.AMMO_PICKUP = {1, 2}
self.galil.timers.reload_not_empty = 2.8
self.galil.timers.reload_empty = 3.9
self.galil.kick = {standing = { 1.7, 1.7, -0.4, 0.4 } }
self.galil.kick.crouching = { 1.6, 1.6, -0.4, 0.4 }
self.galil.kick.steelsight = { 1.6, 1.6, -0.3, 0.3 }

self.s552.CLIP_AMMO_MAX = 30
self.s552.AMMO_MAX = 180
self.s552.stats.damage = 65
self.s552.stats.spread = 18
self.s552.stats.spread_moving = 12
self.s552.stats.recoil = 18
self.s552.stats.suppression = 12
self.s552.fire_mode_data.fire_rate = 0.083333333
self.s552.can_shoot_through_shield = false
self.s552.armor_piercing_chance = 0.6
self.s552.AMMO_PICKUP = {3, 6}
self.s552.kick = {standing = { 1, 1.2, -0.4, 0.4 } }
self.s552.kick.crouching = { 1, 1.1, -0.4, 0.4 }
self.s552.kick.steelsight = { 0.9, 1, -0.4, 0.4 }

self.g36.CLIP_AMMO_MAX = 30
self.g36.AMMO_MAX = 180
self.g36.stats.damage = 65
self.g36.stats.spread = 19
self.g36.stats.spread_moving = 14
self.g36.stats.recoil = 20
self.g36.stats.suppression = 12
self.g36.fire_mode_data.fire_rate = 0.0857
self.g36.can_shoot_through_shield = false
self.g36.armor_piercing_chance = 0.6
self.g36.AMMO_PICKUP = {3, 6}
self.g36.kick = {standing = { 1, 1.1, -0.3, 0.3 } }
self.g36.kick.crouching = { 1, 1, -0.3, 0.3 }
self.g36.kick.steelsight = { 0.8, 1, -0.3, 0.3 }

self.ak5.CLIP_AMMO_MAX = 30
self.ak5.AMMO_MAX = 180
self.ak5.stats.damage = 68
self.ak5.stats.spread = 21
self.ak5.stats.spread_moving = 16
self.ak5.stats.recoil = 18
self.ak5.stats.suppression = 12
self.ak5.fire_mode_data.fire_rate = 0.0857
self.ak5.can_shoot_through_shield = false
self.ak5.armor_piercing_chance = 0.6
self.ak5.AMMO_PICKUP = {3, 6}
self.ak5.kick = {standing = { 1, 1.2, -0.4, 0.4 } }
self.ak5.kick.crouching = { 1, 1.1, -0.4, 0.4 }
self.ak5.kick.steelsight = { 0.8, 1, -0.3, 0.3 }


self.sub2000.CLIP_AMMO_MAX = 33
self.sub2000.AMMO_MAX = 165
self.sub2000.stats.damage = 52
self.sub2000.stats.spread = 18
self.sub2000.stats.spread_moving = 12
self.sub2000.stats.recoil = 20
self.sub2000.stats.suppression = 10
self.sub2000.fire_mode_data.fire_rate = 0.09231
self.sub2000.can_shoot_through_shield = false
self.sub2000.AMMO_PICKUP = {5, 7}
self.sub2000.kick = {standing = { 0.3, 0.5, -0.4, 0.4 } }
self.sub2000.kick.crouching = { 0.2, 0.4, -0.4, 0.4 }
self.sub2000.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }


-- Bullpup Rifles --

self.aug.CLIP_AMMO_MAX = 30
self.aug.AMMO_MAX = 180
self.aug.stats.damage = 67
self.aug.stats.spread = 21
self.aug.stats.spread_moving = 15
self.aug.stats.recoil = 20
self.aug.stats.suppression = 10
self.aug.fire_mode_data.fire_rate = 0.08
self.aug.can_shoot_through_shield = false
self.aug.armor_piercing_chance = 0.6
self.aug.AMMO_PICKUP = {3, 6}
self.aug.CAN_TOGGLE_FIREMODE = false
self.aug.kick = {standing = { 1, 1.2, -0.4, 0.4 } }
self.aug.kick.crouching = { 1, 1.1, -0.4, 0.4 }
self.aug.kick.steelsight = { 0.8, 1, -0.3, 0.3 }
 

self.famas.CLIP_AMMO_MAX = 25 
self.famas.AMMO_MAX = 175
self.famas.stats.damage = 67
self.famas.stats.spread = 17
self.famas.stats.spread_moving = 10
self.famas.stats.recoil = 18
self.famas.stats.suppression = 6
self.famas.fire_mode_data.fire_rate = 0.06
self.famas.armor_piercing_chance = 0.6
self.famas.can_shoot_through_shield = false
self.famas.AMMO_PICKUP = {3, 7}
self.famas.kick = {standing = { 1.1, 1.3, -0.5, 0.5 } }
self.famas.kick.crouching = { 1, 1.2, -0.5, 0.5 }
self.famas.kick.steelsight = { 0.9, 1.1, -0.5, 0.5 }


self.l85a2.CLIP_AMMO_MAX = 30
self.l85a2.AMMO_MAX = 180
self.l85a2.stats.damage = 68
self.l85a2.stats.spread = 22
self.l85a2.stats.spread_moving = 16
self.l85a2.stats.recoil = 18
self.l85a2.stats.suppression = 12
self.l85a2.fire_mode_data.fire_rate = 0.083333333
self.l85a2.armor_piercing_chance = 0.6
self.l85a2.can_shoot_through_shield = false
self.l85a2.AMMO_PICKUP = {3, 6}
self.l85a2.timers.reload_empty = 4.2
self.l85a2.kick = {standing = { 1.2, 1.2, -0.3, 0.3 } }
self.l85a2.kick.crouching = { 1.1, 1.2, -0.3, 0.3 }
self.l85a2.kick.steelsight = { 1, 1.2, -0.3, 0.3 }

self.vhs.CLIP_AMMO_MAX = 30
self.vhs.AMMO_MAX = 180
self.vhs.stats.damage = 68
self.vhs.stats.spread = 20
self.vhs.stats.spread_moving = 14
self.vhs.stats.recoil = 19
self.vhs.stats.suppression = 10
self.vhs.fire_mode_data.fire_rate = 0.0705882
self.vhs.armor_piercing_chance = 0.6
self.vhs.can_shoot_through_shield = false
self.vhs.AMMO_PICKUP = {3, 7}
self.vhs.kick = {standing = { 1, 1.2, -0.4, 0.4 } }
self.vhs.kick.crouching = { 1, 1.1, -0.4, 0.4 }
self.vhs.kick.steelsight = { 0.8, 1, -0.3, 0.3 }



self.corgi.CLIP_AMMO = 30
self.corgi.AMMO_MAX = 180
self.corgi.stats.damage = 66
self.corgi.stats.spread = 19
self.corgi.stats.spread_moving = 14
self.corgi.stats.recoil = 18
self.corgi.stats.suppression = 10
self.corgi.armor_piercing_chance = 0.6
self.corgi.AMMO_PICKUP = {3, 7}
self.corgi.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.corgi.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.corgi.kick.steelsight = { 0.9, 1, -0.4, 0.4 }


self.komodo.CLIP_AMMO = 30
self.komodo.AMMO_MAX = 180
self.komodo.stats.damage = 65
self.komodo.stats.spread = 17
self.komodo.stats.spread_moving = 10
self.komodo.stats.recoil = 20
self.komodo.stats.suppression = 10
self.komodo.armor_piercing_chance = 0.6
self.komodo.AMMO_PICKUP = {4, 6}
self.komodo.timers.reload_empty = 3
self.komodo.kick = {standing = { 1, 1.2, -0.3, 0.3 } }
self.komodo.kick.crouching = { 1, 1.1, -0.3, 0.3 }
self.komodo.kick.steelsight = { 0.8, 1, -0.3, 0.3 }

-- AKs --

self.akm.CLIP_AMMO_MAX = 30
self.akm.AMMO_MAX = 180
self.akm.stats.damage = 75
self.akm.stats.spread = 14
self.akm.stats.spread_moving = 10
self.akm.stats.recoil = 16
self.akm.stats.suppression = 9
self.akm.fire_mode_data.fire_rate = 0.1
self.akm.can_shoot_through_shield = false
self.akm.armor_piercing_chance = 0.5
self.akm.AMMO_PICKUP = {2, 4}
self.akm.timers.reload_not_empty = 2.3
self.akm.kick = {standing = { 1.5, 1.5, -0.6, 0.6 } }
self.akm.kick.crouching = { 1.5, 1.5, -0.6, 0.6 }
self.akm.kick.steelsight = { 1.4, 1.4, -0.5, 0.5 }

self.akm_gold.CLIP_AMMO_MAX = 30
self.akm_gold.AMMO_MAX = 180
self.akm_gold.stats.damage = 75
self.akm_gold.stats.spread = 14
self.akm_gold.stats.spread_moving = 10
self.akm_gold.stats.recoil = 16
self.akm_gold.stats.suppression = 9
self.akm_gold.fire_mode_data.fire_rate = 0.1
self.akm_gold.can_shoot_through_shield = false
self.akm_gold.armor_piercing_chance = 0.5
self.akm_gold.AMMO_PICKUP = {2, 4}
self.akm_gold.timers.reload_not_empty = 2.3
self.akm_gold.kick = {standing = { 1.5, 1.5, -0.6, 0.6 } }
self.akm_gold.kick.crouching = { 1.5, 1.5, -0.6, 0.6 }
self.akm_gold.kick.steelsight = { 1.4, 1.4, -0.5, 0.5 }

self.ak74.CLIP_AMMO_MAX = 30
self.ak74.AMMO_MAX = 180
self.ak74.stats.damage = 64
self.ak74.stats.spread = 16
self.ak74.stats.spread_moving = 12
self.ak74.stats.recoil = 20
self.ak74.stats.suppression = 12
self.ak74.fire_mode_data.fire_rate = 0.09231
self.ak74.armor_piercing_chance = 0.6
self.ak74.can_shoot_through_shield = false
self.ak74.AMMO_PICKUP = {4, 7}
self.ak74.kick = {standing = { 0.9, 1.1, -0.3, 0.3 } }
self.ak74.kick.crouching = { 0.8, 1, -0.2, 0.2 }
self.ak74.kick.steelsight = { 0.7, 0.9, -0.2, 0.2 }

self.asval.CLIP_AMMO_MAX = 20
self.asval.AMMO_MAX = 100
self.asval.stats.damage = 80
self.asval.stats.spread = 20
self.asval.stats.spread_moving = 16
self.asval.stats.recoil = 18
self.asval.stats.suppression = 16
self.asval.fire_mode_data.fire_rate = 0.0666666
self.asval.armor_piercing_chance = 0.8
self.asval.can_shoot_through_shield = false
self.asval.AMMO_PICKUP = {1.5, 3.5}
self.asval.kick = {standing = { 1.3, 1.3, -0.4, 0.4 } }
self.asval.kick.crouching = { 1.3, 1.3, -0.3, 0.3 }
self.asval.kick.steelsight = { 1.2, 1.2, -0.3, 0.3 }


self.akmsu.CLIP_AMMO_MAX = 30
self.akmsu.AMMO_MAX = 150
self.akmsu.stats.damage = 70
self.akmsu.stats.spread = 12
self.akmsu.stats.spread_moving = 8
self.akmsu.stats.recoil = 16
self.akmsu.stats.suppression = 11
self.akmsu.armor_piercing_chance = 0.5
self.akmsu.fire_mode_data.fire_rate = 0.075
self.akmsu.can_shoot_through_shield = false
self.akmsu.AMMO_PICKUP = {1.5, 3.5}
self.akmsu.kick = {standing = { 1.5, 1.6, -0.6, 0.6 } }
self.akmsu.kick.crouching = { 1.5, 1.6, -0.5, 0.5 }
self.akmsu.kick.steelsight = { 1.4, 1.5, -0.5, 0.5 }

self.x_akmsu.CLIP_AMMO_MAX = 60
self.x_akmsu.AMMO_MAX = 300
self.x_akmsu.stats.damage = 70
self.x_akmsu.stats.spread = 10
self.x_akmsu.stats.spread_moving = 6
self.x_akmsu.stats.recoil = 16
self.x_akmsu.stats.suppression = 9
self.x_akmsu.armor_piercing_chance = 0.5
self.x_akmsu.fire_mode_data.fire_rate = 0.075
self.x_akmsu.can_shoot_through_shield = false
self.x_akmsu.AMMO_PICKUP = {3, 5}
self.x_akmsu.kick = {standing = { 1.5, 1.6, -0.6, 0.6 } }
self.x_akmsu.kick.crouching = { 1.5, 1.6, -0.5, 0.5 }
self.x_akmsu.kick.steelsight = { 1.4, 1.5, -0.5, 0.5 }

self.flint.CLIP_AMMO_MAX = 35
self.flint.AMMO_MAX = 210
self.flint.stats.damage = 64
self.flint.stats.spread = 20
self.flint.stats.spread_moving = 16
self.flint.stats.recoil = 21
self.flint.stats.suppression = 10
self.flint.armor_piercing_chance = 0.7
self.flint.fire_mode_data.fire_rate = 0.0920245
self.flint.can_shoot_through_shield = false
self.flint.AMMO_PICKUP = {4, 7}
self.flint.kick = {standing = { 0.9, 1.1, -0.3, 0.3 } }
self.flint.kick.crouching = { 0.8, 1, -0.2, 0.2 }
self.flint.kick.steelsight = { 0.7, 0.9, -0.2, 0.2 }

self.groza.CLIP_AMMO_MAX = 20
self.groza.AMMO_MAX = 100
self.groza.stats.damage = 80
self.groza.stats.spread = 16
self.groza.stats.spread_moving = 10
self.groza.stats.recoil = 16
self.groza.stats.suppression = 16
self.groza.fire_mode_data.fire_rate = 0.08
self.groza.armor_piercing_chance = 0.8
self.groza.can_shoot_through_shield = false
self.groza.AMMO_PICKUP = {2, 4}
self.groza.kick = {standing = { 1.5, 1.5, -0.3, 0.3 } }
self.groza.kick.crouching = { 1.4, 1.4, -0.3, 0.3 }
self.groza.kick.steelsight = { 1.4, 1.4, -0.3, 0.3 }

self.groza_underbarrel.CLIP_AMMO_MAX = 1
self.groza_underbarrel.AMMO_MAX = 4
self.groza_underbarrel.stats.damage = 80
self.groza_underbarrel.stats.spread = 12
self.groza_underbarrel.stats.recoil = 8
self.groza_underbarrel.stats.suppression = 4
self.groza_underbarrel.fire_mode_data.fire_rate = 1
self.groza_underbarrel.can_shoot_through_shield = false
self.groza_underbarrel.AMMO_PICKUP = {0.3, 0.6}


-- Battle Rifles --

self.scar.CLIP_AMMO_MAX = 20
self.scar.AMMO_MAX = 100
self.scar.stats.damage = 95
self.scar.stats.spread = 22
self.scar.stats.spread_moving = 16
self.scar.stats.recoil = 18
self.scar.stats.suppression = 10
self.scar.fire_mode_data.fire_rate = 0.1
self.scar.can_shoot_through_shield = false
self.scar.armor_piercing_chance = 0.8
self.scar.AMMO_PICKUP = {1, 2}
self.scar.kick = {standing = { 1.6, 1.6, -0.3, 0.3 } }
self.scar.kick.crouching = { 1.6, 1.6, -0.3, 0.3 }
self.scar.kick.steelsight = { 1.5, 1.5, -0.3, 0.3 }

self.fal.CLIP_AMMO_MAX = 20
self.fal.AMMO_MAX = 100
self.fal.stats.damage = 96
self.fal.stats.spread = 16
self.fal.stats.spread_moving = 12
self.fal.stats.recoil = 16
self.fal.stats.suppression = 10
self.fal.fire_mode_data.fire_rate = 0.0857
self.fal.can_shoot_through_shield = false
self.fal.armor_piercing_chance = 0.9
self.fal.AMMO_PICKUP = {1, 2}
self.fal.kick = {standing = { 1.8, 1.8, -0.6, 0.6 } }
self.fal.kick.crouching = { 1.8, 1.8, -0.5, 0.5 }
self.fal.kick.steelsight = { 1.7, 1.7, -0.5, 0.5 }

self.g3.CLIP_AMMO_MAX = 20
self.g3.AMMO_MAX = 100
self.g3.stats.damage = 96
self.g3.stats.spread = 20
self.g3.stats.spread_moving = 15
self.g3.stats.recoil = 16
self.g3.stats.suppression = 10
self.g3.fire_mode_data.fire_rate = 0.1
self.g3.can_shoot_through_shield = false
self.g3.armor_piercing_chance = 0.9
self.g3.AMMO_PICKUP = {1, 2}
self.g3.timers.reload_not_empty = 2.6
self.g3.timers.reload_empty = 3.8
self.g3.kick = {standing = { 1.6, 1.6, -0.3, 0.3 } }
self.g3.kick.crouching = { 1.6, 1.6, -0.3, 0.3 }
self.g3.kick.steelsight = { 1.5, 1.5, -0.2, 0.2 }



self.new_m14.CLIP_AMMO_MAX = 20
self.new_m14.AMMO_MAX = 100
self.new_m14.stats.damage = 100
self.new_m14.stats.spread = 16
self.new_m14.stats.spread_moving = 8
self.new_m14.stats.recoil = 14
self.new_m14.stats.suppression = 10
self.new_m14.fire_mode_data.fire_rate = 0.0857
self.new_m14.armor_piercing_chance = 1
self.new_m14.AMMO_PICKUP = {1, 2}
self.new_m14.kick = {standing = { 1.8, 1.8, -0.5, 0.5 } }
self.new_m14.kick.crouching = { 1.7, 1.7, -0.5, 0.5 }
self.new_m14.kick.steelsight = { 1.7, 1.7, -0.5, 0.5 }

self.ching.CLIP_AMMO_MAX = 8
self.ching.AMMO_MAX = 48
self.ching.stats.damage = 180
self.ching.stats.spread = 16
self.ching.stats.spread_moving = 12
self.ching.stats.recoil = 14
self.ching.stats.suppression = 12
self.ching.fire_mode_data.fire_rate = 0.1
self.ching.armor_piercing_chance = 1
self.ching.AMMO_PICKUP = {0.7, 1.2}
self.ching.kick = {standing = { 2, 2.2, -0.2, 0.2 } }
self.ching.kick.crouching = { 2, 2.1, -0.2, 0.2 }
self.ching.kick.steelsight = { 1.9, 2, -0.2, 0.2 }

-- Sniper Rifles --

self.model70.CLIP_AMMO_MAX = 5
self.model70.AMMO_MAX = 30
self.model70.stats.damage = 78
self.model70.stats.spread = 20
self.model70.stats.spread_moving = 20
self.model70.stats.recoil = 16
self.model70.stats.suppression = 16
self.model70.fire_mode_data.fire_rate = 1
self.model70.can_shoot_through_shield = true
self.model70.AMMO_PICKUP = {1, 2}
self.model70.stats_modifiers = {damage = 5}
self.model70.stats.concealment = 10
self.model70.kick = {standing = { 2.4, 2.6, -0.2, 0.2 } }
self.model70.kick.crouching = { 2.3, 2.5, -0.2, 0.2 }
self.model70.kick.steelsight = { 2.1, 2.3, -0.1, 0.1 }

self.msr.CLIP_AMMO_MAX = 10
self.msr.AMMO_MAX = 40
self.msr.stats.damage = 100
self.msr.stats.spread = 23
self.msr.stats.spread_moving = 23
self.msr.stats.recoil = 12
self.msr.stats.suppression = 16
self.msr.fire_mode_data.fire_rate = 1
self.msr.can_shoot_through_shield = true
self.msr.AMMO_PICKUP = {0.4, 0.7}
self.msr.stats_modifiers = {damage = 5}
self.msr.kick = {standing = { 2.6, 2.8, -0.1, 0.1 } }
self.msr.kick.crouching = { 2.4, 2.6, -0.1, 0.1 }
self.msr.kick.steelsight = { 2.2, 2.4, -0.1, 0.1 }

self.r93.CLIP_AMMO_MAX = 5
self.r93.AMMO_MAX = 20
self.r93.stats.damage = 100
self.r93.stats.spread = 25
self.r93.stats.spread_moving = 25
self.r93.stats.recoil = 12
self.r93.stats.suppression = 16
self.r93.fire_mode_data.fire_rate = 0.83333
self.r93.can_shoot_through_shield = true
self.r93.AMMO_PICKUP = {0.4, 0.7}
self.r93.stats_modifiers = {damage = 5}
self.r93.kick = {standing = { 2.6, 2.8, -0.1, 0.1 } }
self.r93.kick.crouching = { 2.4, 2.6, -0.1, 0.1 }
self.r93.kick.steelsight = { 2.1, 2.3, -0.1, 0.1 }

self.desertfox.CLIP_AMMO_MAX = 5
self.desertfox.AMMO_MAX = 20
self.desertfox.stats.damage = 100
self.desertfox.stats.spread = 25
self.desertfox.stats.spread_moving = 25
self.desertfox.stats.recoil = 16
self.desertfox.stats.suppression = 16
self.desertfox.fire_mode_data.fire_rate = 1
self.desertfox.can_shoot_through_shield = true
self.desertfox.AMMO_PICKUP = {0.4, 0.7}
self.desertfox.stats.concealment = 14
self.desertfox.stats_modifiers = {damage = 5}
self.desertfox.kick = {standing = { 2.4, 2.6, -0.1, 0.1 } }
self.desertfox.kick.crouching = { 2.2, 2.4, -0.1, 0.1 }
self.desertfox.kick.steelsight = { 2, 2.2, -0.1, 0.1 }

self.mosin.CLIP_AMMO_MAX = 5
self.mosin.AMMO_MAX = 40
self.mosin.stats.damage = 75
self.mosin.stats.spread = 14
self.mosin.stats.spread_moving = 12
self.mosin.stats.recoil = 10
self.mosin.stats.suppression = 8
self.mosin.fire_mode_data.fire_rate = 1
self.mosin.can_shoot_through_shield = true
self.mosin.AMMO_PICKUP = {0.7, 1.2}
self.mosin.stats_modifiers = {damage = 5}
self.mosin.stats.concealment = 8
self.mosin.kick = {standing = { 2.4, 2.6, -0.2, 0.2 } }
self.mosin.kick.crouching = { 2.3, 2.5, -0.2, 0.2 }
self.mosin.kick.steelsight = { 2.1, 2.3, -0.2, 0.2 }



self.winchester1874.CLIP_AMMO_MAX = 14
self.winchester1874.AMMO_MAX = 70
self.winchester1874.stats.damage = 60
self.winchester1874.stats.spread = 14
self.winchester1874.stats.spread_moving = 12
self.winchester1874.stats.recoil = 16
self.winchester1874.stats.suppression = 14
self.winchester1874.fire_mode_data.fire_rate = 0.375
self.winchester1874.can_shoot_through_shield = true
self.winchester1874.AMMO_PICKUP = {1, 2}
self.winchester1874.stats_modifiers = {damage = 3}
self.winchester1874.kick = {standing = { 1.6, 1.8, -0.2, 0.2 } }
self.winchester1874.kick.crouching = { 1.5, 1.7, -0.2, 0.2 }
self.winchester1874.kick.steelsight = { 1.4, 1.6, -0.1, 0.1 }

self.wa2000.CLIP_AMMO_MAX = 6
self.wa2000.AMMO_MAX = 48
self.wa2000.stats.damage = 70
self.wa2000.stats.spread = 24
self.wa2000.stats.spread_moving = 20
self.wa2000.stats.recoil = 16
self.wa2000.stats.suppression = 14
self.wa2000.fire_mode_data.fire_rate = 0.15
self.wa2000.can_shoot_through_shield = true
self.wa2000.AMMO_PICKUP = {1, 2}
self.wa2000.stats.concealment = 20
self.wa2000.stats_modifiers = {damage = 5}
self.wa2000.kick = {standing = { 2.1, 2.3, -0.2, 0.2 } }
self.wa2000.kick.crouching = { 2, 2.2, -0.2, 0.2 }
self.wa2000.kick.steelsight = { 1.9, 2.1, -0.1, 0.1 }

self.tti.CLIP_AMMO_MAX = 20
self.tti.AMMO_MAX = 100
self.tti.stats.damage = 100
self.tti.stats.spread = 20
self.tti.stats.spread_moving = 16
self.tti.fire_mode_data.fire_rate = 0.10909
self.tti.stats.recoil = 18
self.tti.stats.suppression = 10
self.tti.can_shoot_through_shield = true
self.tti.AMMO_PICKUP = {1, 2}
self.tti.kick = {standing = { 2.1, 2.3, -0.3, 0.3 } }
self.tti.kick.crouching = { 2, 2.2, -0.3, 0.3 }
self.tti.kick.steelsight = { 1.8, 2, -0.3, 0.3 }

self.siltstone.CLIP_AMMO_MAX = 10
self.siltstone.AMMO_MAX = 60
self.siltstone.stats.damage = 75
self.siltstone.stats.spread = 17
self.siltstone.stats.spread_moving = 10
self.siltstone.stats.recoil = 12
self.siltstone.stats.suppression = 14
self.siltstone.fire_mode_data.fire_rate = 0.24
self.siltstone.can_shoot_through_shield = true
self.siltstone.AMMO_PICKUP = {0.5, 0.8}
self.siltstone.stats_modifiers = {damage = 5}
self.siltstone.kick = {standing = { 2, 2.2, -0.2, 0.2 } }
self.siltstone.kick.crouching = { 1.9, 2.1, -0.2, 0.2 }
self.siltstone.kick.steelsight = { 1.8, 2, -0.1, 0.1 }

self.m95.stats.damage = 1000
self.m95.stats_modifiers = {damage = 6}

self.r700.CLIP_AMMO_MAX = 10
self.r700.AMMO_MAX = 80
self.r700.stats.damage = 50
self.r700.stats.spread = 24
self.r700.stats.spread_moving = 22
self.r700.stats.recoil = 20
self.r700.stats.suppression = 16
self.r700.fire_mode_data.fire_rate = 0.6
self.r700.can_shoot_through_shield = true
self.r700.stats_modifiers = {damage = 5}
self.r700.AMMO_PICKUP = {2, 4}
self.r700.stats.concealment = 20
self.r700.kick = {standing = { 2.2, 2.4, -0.2, 0.2 } }
self.r700.kick.crouching = { 2.2, 2.2, -0.2, 0.2 }
self.r700.kick.steelsight = { 2.1, 2.1, -0.1, 0.1 }

self.sbl.CLIP_AMMO_MAX = 4
self.sbl.AMMO_MAX = 36
self.sbl.stats.damage = 80
self.sbl.stats.spread = 16
self.sbl.stats.spread_moving = 12
self.sbl.stats.recoil = 17
self.sbl.stats.suppression = 14
self.sbl.fire_mode_data.fire_rate = 0.33333
self.sbl.can_shoot_through_shield = true
self.sbl.AMMO_PICKUP = {0.5, 1.5}
self.sbl.stats_modifiers = {damage = 5}
self.sbl.kick = {standing = { 2, 2, -0.3, 0.3 } }
self.sbl.kick.crouching = { 1.8, 1.8, -0.3, 0.3 }
self.sbl.kick.steelsight = { 1.8, 1.8, -0.3, 0.3 }

self.qbu88.CLIP_AMMO_MAX = 10
self.qbu88.AMMO_MAX = 100
self.qbu88.stats.damage = 100
self.qbu88.stats.spread = 14
self.qbu88.stats.spread_moving = 6
self.qbu88.stats.recoil = 20
self.qbu88.stats.suppression = 10
self.qbu88.fire_mode_data.fire_rate = 0.1
self.qbu88.can_shoot_through_shield = true
self.qbu88.AMMO_PICKUP = {2, 4}
self.qbu88.kick = {standing = { 1.8, 1.8, -0.3, 0.3 } }
self.qbu88.kick.crouching = { 1.8, 1.8, -0.3, 0.3 }
self.qbu88.kick.steelsight = { 1.7, 1.7, -0.3, 0.3 }
self.qbu88.timers.reload_empty = 3.1

-- Classic Shotties --

self.boot.CLIP_AMMO_MAX = 5
self.boot.AMMO_MAX = 25
self.boot.stats.damage = 160
self.boot.stats.spread = 7
self.boot.stats.spread_moving = 3
self.boot.stats.recoil = 8
self.boot.stats.suppression = 14
self.boot.fire_mode_data.fire_rate = 0.6
self.boot.can_shoot_through_shield = false
self.boot.rays = 10
self.boot.AMMO_PICKUP = {1, 2}
self.boot.armor_piercing_chance = 0
self.boot.kick = {standing = { 3.2, 3.6, -0.2, 0.2 } }
self.boot.kick.crouching = { 3, 3.4, -0.2, 0.2 }
self.boot.kick.steelsight = { 2.8, 3.2, -0.2, 0.2 }
self.boot.timers.shotgun_reload_exit_empty = 0.6
self.boot.timers.shotgun_reload_exit_not_empty = 0.5
self.boot.damage_near = 1000
self.boot.damage_far = 2000



self.serbu.CLIP_AMMO_MAX = 4
self.serbu.AMMO_MAX = 24
self.serbu.stats.damage = 130
self.serbu.stats.spread = 4
self.serbu.stats.spread_moving = 4
self.serbu.stats.recoil = 6
self.serbu.stats.suppression = 14
self.serbu.fire_mode_data.fire_rate = 0.4
self.serbu.can_shoot_through_shield = false
self.serbu.AMMO_PICKUP = {2, 4}
self.serbu.rays = 9
self.serbu.stats.concealment = 22
self.serbu.armor_piercing_chance = 0
self.serbu.kick = {standing = { 3, 3.2, -0.2, 0.2 } }
self.serbu.kick.crouching = { 2.8, 3, -0.2, 0.2 }
self.serbu.kick.steelsight = { 2.6, 2.8, -0.2, 0.2 }
self.serbu.damage_near = 800
self.serbu.damage_far = 1700

self.r870.CLIP_AMMO_MAX = 6
self.r870.AMMO_MAX = 48
self.r870.stats.damage = 136
self.r870.stats.spread = 12
self.r870.stats.spread_moving = 6
self.r870.stats.recoil = 10
self.r870.stats.suppression = 14
self.r870.fire_mode_data.fire_rate = 0.4
self.r870.can_shoot_through_shield = false
self.r870.armor_piercing_chance = 0
self.r870.rays = 9
self.r870.AMMO_PICKUP = {2, 3}
self.r870.kick = {standing = { 2.8, 3, -0.2, 0.2 } }
self.r870.kick.crouching = { 2.6, 2.9, -0.2, 0.2 }
self.r870.kick.steelsight = { 2.4, 2.6, -0.2, 0.2 }
self.r870.damage_near = 1600
self.r870.damage_far = 3400



self.m37.CLIP_AMMO_MAX = 5
self.m37.AMMO_MAX = 30
self.m37.stats.damage = 135
self.m37.stats.spread = 10
self.m37.stats.spread_moving = 5
self.m37.stats.recoil = 8
self.m37.stats.suppression = 14
self.m37.fire_mode_data.fire_rate = 0.5
self.m37.rays = 9
self.m37.can_shoot_through_shield = false
self.m37.AMMO_PICKUP = {2, 4}
self.m37.armor_piercing_chance = 0
self.m37.kick = {standing = { 2.8, 3, -0.2, 0.2 } }
self.m37.kick.crouching = { 2.6, 2.9, -0.2, 0.2 }
self.m37.kick.steelsight = { 2.4, 2.6, -0.2, 0.2 }
self.m37.damage_near = 1200
self.m37.damage_far = 2800



self.ksg.CLIP_AMMO_MAX = 14
self.ksg.AMMO_MAX = 56
self.ksg.stats.damage = 135
self.ksg.stats.spread = 16
self.ksg.stats.spread_moving = 10
self.ksg.stats.recoil = 16
self.ksg.stats.suppression = 12
self.ksg.fire_mode_data.fire_rate = 0.4
self.ksg.can_shoot_through_shield = false
self.ksg.rays = 9
self.ksg.AMMO_PICKUP = {2, 3}
self.ksg.armor_piercing_chance = 0
self.ksg.kick = {standing = { 2.6, 2.8, -0.2, 0.2 } }
self.ksg.kick.crouching = { 2.4, 2.6, -0.2, 0.2 }
self.ksg.kick.steelsight = { 2.2, 2.4, -0.1, 0.1 }
self.ksg.damage_near = 1500
self.ksg.damage_far = 2500


self.huntsman.CLIP_AMMO_MAX = 2
self.huntsman.AMMO_MAX = 16
self.huntsman.stats.damage = 180
self.huntsman.stats.spread = 8
self.huntsman.stats.spread_moving = 1
self.huntsman.stats.recoil = 5
self.huntsman.stats.suppression = 10
self.huntsman.fire_mode_data.fire_rate = 0.12
self.huntsman.can_shoot_through_shield = false
self.huntsman.AMMO_PICKUP = {0.3, 0.5}
self.huntsman.armor_piercing_chance = 0
self.huntsman.rays = 10
self.huntsman.kick = {standing = { 3, 3.2, -0.2, 0.2 } }
self.huntsman.kick.crouching = { 2.8, 3, -0.2, 0.2 }
self.huntsman.kick.steelsight = { 2.6, 2.8, -0.2, 0.2 }
self.huntsman.damage_near = 1000
self.huntsman.damage_far = 2200
self.huntsman.AMMO_PICKUP = {1, 3}


self.b682.CLIP_AMMO_MAX = 2
self.b682.AMMO_MAX = 16
self.b682.stats.damage = 180
self.b682.stats.spread = 12
self.b682.stats.spread_moving = 4
self.b682.stats.recoil = 6
self.b682.stats.suppression = 10
self.b682.fire_mode_data.fire_rate = 0.12
self.b682.can_shoot_through_shield = false
self.b682.AMMO_PICKUP = {0.3, 0.5}
self.b682.armor_piercing_chance = 0
self.b682.rays = 10
self.b682.kick = {standing = { 3, 3.2, -0.2, 0.2 } }
self.b682.kick.crouching = { 2.8, 3, -0.2, 0.2 }
self.b682.kick.steelsight = { 2.6, 2.8, -0.2, 0.2 }
self.b682.damage_near = 1100
self.b682.damage_far = 2300
self.b682.AMMO_PICKUP = {1, 3}


self.coach.CLIP_AMMO_MAX = 2
self.coach.AMMO_MAX = 16
self.coach.stats.damage = 180
self.coach.stats.spread = 8
self.coach.stats.spread_moving = 1
self.coach.stats.recoil = 6
self.coach.stats.suppression = 10
self.coach.fire_mode_data.fire_rate = 0.12
self.coach.can_shoot_through_shield = false
self.coach.AMMO_PICKUP = {0.4, 0.6}
self.coach.armor_piercing_chance = 0
self.coach.rays = 10
self.coach.kick = {standing = { 3, 3.2, -0.2, 0.2 } }
self.coach.kick.crouching = { 2.8, 3, -0.2, 0.2 }
self.coach.kick.steelsight = { 2.6, 2.8, -0.2, 0.2 }
self.coach.damage_near = 800
self.coach.damage_far = 1600
self.coach.AMMO_PICKUP = {1, 3}


self.m1897.CLIP_AMMO_MAX = 5
self.m1897.AMMO_MAX = 30
self.m1897.stats.damage = 136
self.m1897.stats.spread = 8
self.m1897.stats.spread_moving = 5
self.m1897.stats.recoil = 7
self.m1897.stats.suppression = 12
self.m1897.fire_mode_data.fire_rate = 0.5
self.m1897.rays = 8
self.m1897.can_shoot_through_shield = false
self.m1897.AMMO_PICKUP = {2, 3}
self.m1897.armor_piercing_chance = 0
self.m1897.kick = {standing = { 3, 3, -0.2, 0.2 } }
self.m1897.kick.crouching = { 3, 3, -0.2, 0.2 }
self.m1897.kick.steelsight = { 2.9, 3, -0.2, 0.2 }
self.m1897.damage_near = 1200
self.m1897.damage_far = 3800

self.m590.CLIP_AMMO_MAX = 7
self.m590.AMMO_MAX = 56
self.m590.stats.damage = 136
self.m590.stats.spread = 16
self.m590.stats.spread_moving = 10
self.m590.stats.recoil = 12
self.m590.stats.suppression = 10
self.m590.fire_mode_data.fire_rate = 0.3
self.m590.can_shoot_through_shield = false
self.m590.armor_piercing_chance = 0
self.m590.rays = 9
self.m590.AMMO_PICKUP = {3, 5}
self.m590.kick = {standing = { 2.6, 2.8, -0.2, 0.2 } }
self.m590.kick.crouching = { 2.6, 2.8, -0.2, 0.2 }
self.m590.kick.steelsight = { 2.4, 2.6, -0.2, 0.2 }
self.m590.damage_near = 1600
self.m590.damage_far = 3400


-- Auto Shotties --

self.judge.CLIP_AMMO_MAX = 5
self.judge.AMMO_MAX = 40
self.judge.stats.damage = 80
self.judge.stats.spread = 10
self.judge.stats.spread_moving = 6
self.judge.stats.recoil = 16
self.judge.stats.suppression = 16
self.judge.fire_mode_data.fire_rate = 0.2
self.judge.can_shoot_through_shield = false
self.judge.AMMO_PICKUP = {3, 5}
self.judge.armor_piercing_chance = 0
self.judge.rays = 6
self.judge.kick = {standing = { 1.4, 1.4, -0.2, 0.2 } }
self.judge.kick.crouching = { 1.2, 1.3, -0.2, 0.2 }
self.judge.kick.steelsight = { 1.1, 1.2, -0.2, 0.2 }
self.judge.damage_near = 800
self.judge.damage_far = 2200



self.x_judge.CLIP_AMMO_MAX = 10
self.x_judge.AMMO_MAX = 80
self.x_judge.stats.damage = 80
self.x_judge.stats.spread = 8
self.x_judge.stats.spread_moving = 5
self.x_judge.stats.recoil = 14
self.x_judge.stats.suppression = 14
self.x_judge.fire_mode_data.fire_rate = 0.2
self.x_judge.can_shoot_through_shield = false
self.x_judge.AMMO_PICKUP = {4, 7}
self.x_judge.armor_piercing_chance = 0
self.x_judge.rays = 6
self.x_judge.kick = {standing = { 1.4, 1.4, -0.2, 0.2 } }
self.x_judge.kick.crouching = { 1.2, 1.4, -0.2, 0.2 }
self.x_judge.kick.steelsight = { 1.2, 1.4, -0.2, 0.2 }
self.x_judge.damage_near = 800
self.x_judge.damage_far = 2200

self.benelli.CLIP_AMMO_MAX = 7
self.benelli.AMMO_MAX = 42
self.benelli.stats.damage = 135
self.benelli.stats.spread = 16
self.benelli.stats.spread_moving = 12
self.benelli.stats.recoil = 16
self.benelli.stats.suppression = 10
self.benelli.fire_mode_data.fire_rate = 0.15
self.benelli.can_shoot_through_shield = false
self.benelli.rays = 8
self.benelli.AMMO_PICKUP = {2, 3}
self.benelli.armor_piercing_chance = 0
self.benelli.kick = {standing = { 2.8, 3, -0.2, 0.2 } }
self.benelli.kick.crouching = { 2.6, 2.9, -0.2, 0.2 }
self.benelli.kick.steelsight = { 2.4, 2.6, -0.2, 0.2 }
self.benelli.damage_near = 1500
self.benelli.damage_far = 3000


self.spas12.CLIP_AMMO_MAX = 6
self.spas12.AMMO_MAX = 36
self.spas12.stats.damage = 135
self.spas12.stats.spread = 15
self.spas12.stats.spread_moving = 9
self.spas12.stats.recoil = 15
self.spas12.stats.suppression = 10
self.spas12.fire_mode_data.fire_rate = 0.15
self.spas12.can_shoot_through_shield = false
self.spas12.rays = 8
self.spas12.AMMO_PICKUP = {2, 3}
self.spas12.armor_piercing_chance = 0
self.spas12.kick = {standing = { 2.8, 3, -0.2, 0.2 } }
self.spas12.kick.crouching = { 2.6, 2.9, -0.2, 0.2 }
self.spas12.kick.steelsight = { 2.4, 2.6, -0.2, 0.2 }
self.spas12.damage_near = 1400
self.spas12.damage_far = 2800


self.saiga.CLIP_AMMO_MAX = 7
self.saiga.AMMO_MAX = 42
self.saiga.stats.damage = 132
self.saiga.stats.spread = 12
self.saiga.stats.spread_moving = 6
self.saiga.stats.recoil = 12
self.saiga.stats.suppression = 9
self.saiga.fire_mode_data.fire_rate = 0.1802
self.saiga.rays = 8
self.saiga.can_shoot_through_shield = false
self.saiga.AMMO_PICKUP = {1, 2}
self.saiga.armor_piercing_chance = 0
self.saiga.kick = {standing = { 2, 2, -0.8, 0.8 } }
self.saiga.kick.crouching = { 2, 2, -0.7, 0.7 }
self.saiga.kick.steelsight = { 2, 2, -0.6, 0.6 }
self.saiga.damage_near = 1200
self.saiga.damage_far = 2500


self.aa12.CLIP_AMMO_MAX = 8
self.aa12.AMMO_MAX = 80
self.aa12.stats.damage = 130
self.aa12.stats.spread = 12
self.aa12.stats.spread_moving = 8
self.aa12.stats.recoil = 16
self.aa12.stats.suppression = 8
self.aa12.fire_mode_data.fire_rate = 0.2
self.aa12.can_shoot_through_shield = false
self.aa12.AMMO_PICKUP = {1, 1.5}
self.aa12.armor_piercing_chance = 0
self.aa12.rays = 8
self.aa12.CAN_TOGGLE_FIREMODE = false
self.aa12.kick = {standing = { 1.6, 2, -0.4, 0.4 } }
self.aa12.kick.crouching = { 1.6, 1.8, -0.3, 0.3 }
self.aa12.kick.steelsight = { 1.4, 1.6, -0.3, 0.3 }
self.aa12.damage_near = 1200
self.aa12.damage_far = 2400


self.rota.CLIP_AMMO_MAX = 6
self.rota.AMMO_MAX = 42
self.rota.stats.damage = 132
self.rota.stats.spread = 12
self.rota.stats.spread_moving = 10
self.rota.stats.recoil = 16
self.rota.stats.suppression = 12
self.rota.fire_mode_data.fire_rate = 0.2
self.rota.can_shoot_through_shield = false
self.rota.AMMO_PICKUP = {2, 3}
self.rota.armor_piercing_chance = 0
self.rota.rays = 8
self.rota.stats.concealment = 20
self.rota.kick = {standing = { 3, 3.5, -0.2, 0.2 } }
self.rota.kick.crouching = { 2.8, 3.3, -0.2, 0.2 }
self.rota.kick.steelsight = { 2.5, 3, -0.1, 0.1 }
self.rota.damage_near = 1000
self.rota.damage_far = 1800

self.x_rota.CLIP_AMMO_MAX = 12
self.x_rota.AMMO_MAX = 72
self.x_rota.stats.damage = 132
self.x_rota.stats.spread = 8
self.x_rota.stats.spread_moving = 4
self.x_rota.stats.recoil = 14
self.x_rota.stats.suppression = 9
self.x_rota.fire_mode_data.fire_rate = 0.2
self.x_rota.can_shoot_through_shield = false
self.x_rota.AMMO_PICKUP = {2, 4}
self.x_rota.armor_piercing_chance = 0
self.x_rota.rays = 8
self.x_rota.kick = {standing = { 3, 3.5, -0.2, 0.2 } }
self.x_rota.kick.crouching = { 2.8, 3.3, -0.2, 0.2 }
self.x_rota.kick.steelsight = { 2.5, 3, -0.1, 0.1 }
self.x_rota.damage_near = 1000
self.x_rota.damage_far = 1800




self.striker.CLIP_AMMO_MAX = 12
self.striker.AMMO_MAX = 60
self.striker.stats.damage = 130
self.striker.stats.spread = 9
self.striker.stats.spread_moving = 5
self.striker.stats.recoil = 10
self.striker.stats.suppression = 10
self.striker.fire_mode_data.fire_rate = 0.15
self.striker.can_shoot_through_shield = false
self.striker.AMMO_PICKUP = {2, 3}
self.striker.armor_piercing_chance = 0
self.striker.rays = 8
self.striker.kick = {standing = { 3, 3.5, -0.2, 0.2 } }
self.striker.kick.crouching = { 2.8, 3.3, -0.2, 0.2 }
self.striker.kick.steelsight = { 2.5, 3, -0.1, 0.1 }
self.striker.damage_near = 1000
self.striker.damage_far = 2500

self.basset.CLIP_AMMO_MAX = 8
self.basset.AMMO_MAX = 48
self.basset.stats.damage = 130
self.basset.stats.spread = 14
self.basset.stats.spread_moving = 8
self.basset.stats.recoil = 14
self.basset.stats.suppression = 9
self.basset.fire_mode_data.fire_rate = 0.1802
self.basset.can_shoot_through_shield = false
self.basset.rays = 8
self.basset.AMMO_PICKUP = {1, 2}
self.basset.armor_piercing_chance = 0
self.basset.kick = {standing = { 2, 2, -0.8, 0.8 } }
self.basset.kick.crouching = { 2, 2, -0.7, 0.7 }
self.basset.kick.steelsight = { 2, 2, -0.6, 0.6 }
self.basset.damage_near = 1200
self.basset.damage_far = 2400


self.x_basset.CLIP_AMMO_MAX = 16
self.x_basset.AMMO_MAX = 96
self.x_basset.stats.damage = 130
self.x_basset.stats.spread = 6
self.x_basset.stats.spread_moving = 1
self.x_basset.stats.recoil = 12
self.x_basset.stats.suppression = 8
self.x_basset.fire_mode_data.fire_rate = 0.1802
self.x_basset.can_shoot_through_shield = false
self.x_basset.rays = 8
self.x_basset.AMMO_PICKUP = {2, 3}
self.x_basset.armor_piercing_chance = 0
self.x_basset.kick = {standing = { 2, 2, -0.8, 0.8 } }
self.x_basset.kick.crouching = { 2, 2, -0.7, 0.7 }
self.x_basset.kick.steelsight = { 2, 2, -0.6, 0.6 }
self.x_basset.damage_near = 1200
self.x_basset.damage_far = 2400




-- LMGs --

self.rpk.CLIP_AMMO_MAX = 75
self.rpk.AMMO_MAX = 300
self.rpk.stats.damage = 77
self.rpk.stats.spread = 14
self.rpk.stats.spread_moving = 8
self.rpk.stats.recoil = 18
self.rpk.stats.suppression = 6
self.rpk.fire_mode_data.fire_rate = 0.0857
self.rpk.can_shoot_through_shield = false
self.rpk.AMMO_PICKUP = {3, 5}
self.rpk.armor_piercing_chance = 0.7
self.rpk.CAN_TOGGLE_FIREMODE = true
self.rpk.kick = {standing = { 1.4, 1.4, -0.3, 0.3 } }
self.rpk.kick.crouching = { 1.2, 1.2, -0.3, 0.3 }
self.rpk.kick.steelsight = { 1.2, 1.2, -0.3, 0.3 }



self.hk21.CLIP_AMMO_MAX = 150
self.hk21.AMMO_MAX = 450
self.hk21.stats.damage = 97
self.hk21.stats.spread = 16
self.hk21.stats.spread_moving = 12
self.hk21.stats.recoil = 16
self.hk21.stats.suppression = 5
self.hk21.fire_mode_data.fire_rate = 0.08
self.hk21.can_shoot_through_shield = false
self.hk21.armor_piercing_chance = 1
self.hk21.AMMO_PICKUP = {2, 4}
self.hk21.CAN_TOGGLE_FIREMODE = false
self.hk21.kick = {standing = { 1.6, 1.6, -0.4, 0.4 } }
self.hk21.kick.crouching = { 1.5, 1.5, -0.4, 0.4 }
self.hk21.kick.steelsight = { 1.5, 1.5, -0.4, 0.4 }

self.mg42.CLIP_AMMO_MAX = 50
self.mg42.AMMO_MAX = 300
self.mg42.stats.damage = 108
self.mg42.stats.spread = 14
self.mg42.stats.spread_moving = 6
self.mg42.stats.recoil = 12
self.mg42.stats.suppression = 4
self.mg42.fire_mode_data.fire_rate = 0.05
self.mg42.can_shoot_through_shield = true
self.mg42.can_shoot_through_enemy = true
self.mg42.can_shoot_through_wall = true
self.mg42.armor_piercing_chance = 1
self.mg42.AMMO_PICKUP = {1.5, 3.5}
self.mg42.CAN_TOGGLE_FIREMODE = false
self.mg42.kick = {standing = { 0.8, 0.8, -1.0, 1.0 } }
self.mg42.kick.crouching = { 0.7, 0.7, -1.0, 1.0 }
self.mg42.kick.steelsight = { 0.6, 0.6, -0.8, 0.8 }

self.m249.CLIP_AMMO_MAX = 200
self.m249.AMMO_MAX = 400
self.m249.stats.damage = 68
self.m249.stats.spread = 15
self.m249.stats.spread_moving = 10
self.m249.stats.recoil = 20
self.m249.stats.suppression = 5
self.m249.armor_piercing_chance = 0.8
self.m249.fire_mode_data.fire_rate = 0.06666
self.m249.can_shoot_through_shield = false
self.m249.AMMO_PICKUP = {4, 6}
self.m249.CAN_TOGGLE_FIREMODE = false
self.m249.kick = {standing = { 1.0, 1.0, -0.4, 0.4 } }
self.m249.kick.crouching = { 0.9, 0.9, -0.3, 0.3 }
self.m249.kick.steelsight = { 0.8, 0.8, -0.3, 0.3 }

self.par.CLIP_AMMO_MAX = 100
self.par.AMMO_MAX = 300
self.par.stats.damage = 97
self.par.stats.spread = 16
self.par.stats.spread_moving = 10
self.par.stats.recoil = 16
self.par.stats.suppression = 6
self.par.fire_mode_data.fire_rate = 0.075
self.par.can_shoot_through_shield = false
self.par.armor_piercing_chance = 1
self.par.AMMO_PICKUP = {2, 4}
self.par.CAN_TOGGLE_FIREMODE = false
self.par.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.par.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.par.kick.steelsight = { 1.1, 1.1, -0.3, 0.3 }

self.m60.CLIP_AMMO_MAX = 100
self.m60.AMMO_MAX = 300
self.m60.stats.damage = 97
self.m60.stats.spread = 16
self.m60.stats.spread_moving = 12
self.m60.stats.recoil = 15
self.m60.stats.suppression = 4
self.m60.can_shoot_through_shield = false
self.m60.armor_piercing_chance = 1
self.m60.AMMO_PICKUP = {2, 4}
self.m60.CAN_TOGGLE_FIREMODE = false
self.m60.kick = {standing = { 1.6, 1.6, -0.5, 0.5 } }
self.m60.kick.crouching = { 1.5, 1.5, -0.5, 0.5 }
self.m60.kick.steelsight = { 1.5, 1.5, -0.4, 0.4 }



-- Pistols --

self.sparrow.CLIP_AMMO_MAX = 16
self.sparrow.AMMO_MAX = 128
self.sparrow.stats.damage = 41
self.sparrow.stats.spread = 17
self.sparrow.stats.spread_moving = 10
self.sparrow.stats.recoil = 16
self.sparrow.stats.suppression = 16
self.sparrow.fire_mode_data.fire_rate = 0.1
self.sparrow.can_shoot_through_shield = false
self.sparrow.AMMO_PICKUP = {3, 5}
self.sparrow.armor_piercing_chance = 0
self.sparrow.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.sparrow.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.sparrow.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }


self.x_sparrow.CLIP_AMMO_MAX = 32
self.x_sparrow.AMMO_MAX = 192
self.x_sparrow.stats.damage = 41
self.x_sparrow.stats.spread = 15
self.x_sparrow.stats.spread_moving = 8
self.x_sparrow.stats.recoil = 16
self.x_sparrow.stats.suppression = 14
self.x_sparrow.fire_mode_data.fire_rate = 0.1
self.x_sparrow.can_shoot_through_shield = false
self.x_sparrow.AMMO_PICKUP = {4, 6}
self.x_sparrow.armor_piercing_chance = 0
self.x_sparrow.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_sparrow.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_sparrow.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }


self.pl14.CLIP_AMMO_MAX = 15
self.pl14.AMMO_MAX = 120
self.pl14.stats.damage = 41
self.pl14.stats.spread = 17
self.pl14.stats.spread_moving = 12
self.pl14.stats.recoil = 16
self.pl14.stats.suppression = 16
self.pl14.fire_mode_data.fire_rate = 0.1
self.pl14.can_shoot_through_shield = false
self.pl14.AMMO_PICKUP = {3, 5}
self.pl14.armor_piercing_chance = 0
self.pl14.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.pl14.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.pl14.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }

self.x_pl14.CLIP_AMMO_MAX = 30
self.x_pl14.AMMO_MAX = 180
self.x_pl14.stats.damage = 41
self.x_pl14.stats.spread = 15
self.x_pl14.stats.spread_moving = 10
self.x_pl14.stats.recoil = 16
self.x_pl14.stats.suppression = 14
self.x_pl14.fire_mode_data.fire_rate = 0.1
self.x_pl14.can_shoot_through_shield = false
self.x_pl14.AMMO_PICKUP = {4, 6}
self.x_pl14.armor_piercing_chance = 0
self.x_pl14.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_pl14.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_pl14.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }


self.b92fs.CLIP_AMMO_MAX = 15
self.b92fs.AMMO_MAX = 120
self.b92fs.stats.damage = 41
self.b92fs.stats.spread = 16
self.b92fs.stats.spread_moving = 10
self.b92fs.stats.recoil = 18
self.b92fs.stats.suppression = 16
self.b92fs.fire_mode_data.fire_rate = 0.1
self.b92fs.can_shoot_through_shield = false
self.b92fs.AMMO_PICKUP = {3, 5}
self.b92fs.armor_piercing_chance = 0
self.b92fs.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.b92fs.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.b92fs.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }


self.x_b92fs.CLIP_AMMO_MAX = 30
self.x_b92fs.AMMO_MAX = 180
self.x_b92fs.stats.damage = 41
self.x_b92fs.stats.spread = 14
self.x_b92fs.stats.spread_moving = 10
self.x_b92fs.stats.recoil = 18
self.x_b92fs.stats.suppression = 14
self.x_b92fs.fire_mode_data.fire_rate = 0.1
self.x_b92fs.can_shoot_through_shield = false
self.x_b92fs.AMMO_PICKUP = {4, 6}
self.x_b92fs.armor_piercing_chance = 0
self.x_b92fs.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_b92fs.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_b92fs.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }

self.packrat.CLIP_AMMO_MAX = 15
self.packrat.AMMO_MAX = 120
self.packrat.stats.damage = 41
self.packrat.stats.spread = 17
self.packrat.stats.spread_moving = 14
self.packrat.stats.recoil = 17
self.packrat.stats.suppression = 16
self.packrat.fire_mode_data.fire_rate = 0.1
self.packrat.can_shoot_through_shield = false
self.packrat.AMMO_PICKUP = {3, 5}
self.packrat.armor_piercing_chance = 0
self.packrat.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.packrat.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.packrat.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }

self.x_packrat.CLIP_AMMO_MAX = 30
self.x_packrat.AMMO_MAX = 180
self.x_packrat.stats.damage = 41
self.x_packrat.stats.spread = 15
self.x_packrat.stats.spread_moving = 12
self.x_packrat.stats.recoil = 17
self.x_packrat.stats.suppression = 14
self.x_packrat.fire_mode_data.fire_rate = 0.1
self.x_packrat.can_shoot_through_shield = false
self.x_packrat.AMMO_PICKUP = {4, 6}
self.x_packrat.armor_piercing_chance = 0
self.x_packrat.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_packrat.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_packrat.kick.steelsight = { 0.3, 0.3, -0.1, 0.1 }


self.usp.CLIP_AMMO_MAX = 12
self.usp.AMMO_MAX = 72
self.usp.stats.damage = 54
self.usp.stats.spread = 18
self.usp.stats.spread_moving = 14
self.usp.stats.recoil = 16
self.usp.stats.suppression = 16
self.usp.fire_mode_data.fire_rate = 0.1
self.usp.can_shoot_through_shield = false
self.usp.AMMO_PICKUP = {2, 4}
self.usp.armor_piercing_chance = 0
self.usp.kick = {standing = { 1, 1, -0.3, 0.3 } }
self.usp.kick.crouching = { 0.9, 0.9, -0.3, 0.3 }
self.usp.kick.steelsight = { 0.8, 0.8, -0.3, 0.3 }

self.glock_17.CLIP_AMMO_MAX = 17
self.glock_17.AMMO_MAX = 136
self.glock_17.stats.damage = 41
self.glock_17.stats.spread = 16
self.glock_17.stats.spread_moving = 10
self.glock_17.stats.recoil = 17
self.glock_17.stats.suppression = 16
self.glock_17.fire_mode_data.fire_rate = 0.1
self.glock_17.can_shoot_through_shield = false
self.glock_17.AMMO_PICKUP = {3, 5}
self.glock_17.armor_piercing_chance = 0
self.glock_17.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.glock_17.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.glock_17.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }

self.legacy.CLIP_AMMO_MAX = 13
self.legacy.AMMO_MAX = 104
self.legacy.stats.damage = 40
self.legacy.stats.spread = 15
self.legacy.stats.spread_moving = 9
self.legacy.stats.recoil = 18
self.legacy.stats.suppression = 16
self.legacy.fire_mode_data.fire_rate = 0.1
self.legacy.AMMO_PICKUP = {3, 6}
self.legacy.armor_piercing_chance = 0
self.legacy.kick = {standing = { 0.4, 0.4, -0.3, 0.3 } }
self.legacy.kick.crouching = { 0.3, 0.3, -0.3, 0.3 }
self.legacy.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }

self.x_legacy.CLIP_AMMO_MAX = 26
self.x_legacy.AMMO_MAX = 182
self.x_legacy.stats.damage = 40
self.x_legacy.stats.spread = 12
self.x_legacy.stats.spread_moving = 8
self.x_legacy.stats.recoil = 18
self.x_legacy.stats.suppression = 14
self.x_legacy.fire_mode_data.fire_rate = 0.1
self.x_legacy.AMMO_PICKUP = {4, 8}
self.x_legacy.armor_piercing_chance = 0
self.x_legacy.kick = {standing = { 0.4, 0.4, -0.3, 0.3 } }
self.x_legacy.kick.crouching = { 0.3, 0.3, -0.3, 0.3 }
self.x_legacy.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.x_g18c.CLIP_AMMO_MAX = 40
self.x_g18c.AMMO_MAX = 240
self.x_g18c.stats.damage = 41
self.x_g18c.stats.spread = 12
self.x_g18c.stats.spread_moving = 10
self.x_g18c.stats.recoil = 16
self.x_g18c.stats.suppression = 8
self.x_g18c.fire_mode_data.fire_rate = 0.06666
self.x_g18c.can_shoot_through_shield = false
self.x_g18c.AMMO_PICKUP = {4, 7}
self.x_g18c.armor_piercing_chance = 0
self.x_g18c.kick = {standing = { 0.5, 0.5, -0.3, 0.3 } }
self.x_g18c.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_g18c.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.glock_18c.CLIP_AMMO_MAX = 20
self.glock_18c.AMMO_MAX = 160
self.glock_18c.stats.damage = 41
self.glock_18c.stats.spread = 16
self.glock_18c.stats.spread_moving = 10
self.glock_18c.stats.recoil = 18
self.glock_18c.stats.suppression = 12
self.glock_18c.fire_mode_data.fire_rate = 0.06666
self.glock_18c.can_shoot_through_shield = false
self.glock_18c.AMMO_PICKUP = {2, 5}
self.glock_18c.armor_piercing_chance = 0
self.glock_18c.kick = {standing = { 0.5, 0.5, -0.3, 0.3 } }
self.glock_18c.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.glock_18c.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }

self.g26.CLIP_AMMO_MAX = 10
self.g26.AMMO_MAX = 80
self.g26.stats.damage = 40
self.g26.stats.spread = 14
self.g26.stats.spread_moving = 10
self.g26.stats.recoil = 16
self.g26.stats.suppression = 18
self.g26.fire_mode_data.fire_rate = 0.1
self.g26.can_shoot_through_shield = false
self.g26.stats.concealment = 32
self.g26.AMMO_PICKUP = {3, 5}
self.g26.armor_piercing_chance = 0
self.g26.kick = {standing = { 0.4, 0.4, -0.3, 0.3 } }
self.g26.kick.crouching = { 0.3, 0.3, -0.3, 0.3 }
self.g26.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }

self.ppk.CLIP_AMMO_MAX = 8
self.ppk.AMMO_MAX = 80
self.ppk.stats.damage = 39
self.ppk.stats.spread = 10
self.ppk.stats.spread_moving = 8
self.ppk.stats.recoil = 20
self.ppk.stats.suppression = 18
self.ppk.fire_mode_data.fire_rate = 0.1
self.ppk.can_shoot_through_shield = false
self.ppk.stats.concealment = 32
self.ppk.AMMO_PICKUP = {4, 6}
self.ppk.armor_piercing_chance = 0
self.ppk.kick = {standing = { 0.3, 0.3, -0.1, 0.1 } }
self.ppk.kick.crouching = { 0.2, 0.2, -0.1, 0.1 }
self.ppk.kick.steelsight = { 0.2, 0.2, -0.1, 0.1 }


self.x_ppk.CLIP_AMMO_MAX = 16
self.x_ppk.AMMO_MAX = 128
self.x_ppk.stats.damage = 39
self.x_ppk.stats.spread = 8
self.x_ppk.stats.spread_moving = 6
self.x_ppk.stats.recoil = 20
self.x_ppk.stats.suppression = 16
self.x_ppk.fire_mode_data.fire_rate = 0.1
self.x_ppk.can_shoot_through_shield = false
self.x_ppk.stats.concealment = 30
self.x_ppk.AMMO_PICKUP = {5, 9}
self.x_ppk.armor_piercing_chance = 0
self.x_ppk.kick = {standing = { 0.3, 0.3, -0.2, 0.2 } }
self.x_ppk.kick.crouching = { 0.2, 0.2, -0.2, 0.2 }
self.x_ppk.kick.steelsight = { 0.2, 0.2, -0.1, 0.1 }



self.jowi.CLIP_AMMO_MAX = 20
self.jowi.AMMO_MAX = 120
self.jowi.stats.damage = 40
self.jowi.stats.spread = 12
self.jowi.stats.spread_moving = 8
self.jowi.stats.recoil = 16
self.jowi.stats.suppression = 16
self.jowi.fire_mode_data.fire_rate = 0.1
self.jowi.can_shoot_through_shield = false
self.jowi.AMMO_PICKUP = {4, 6}
self.jowi.armor_piercing_chance = 0
self.jowi.stats.concealment = 30
self.jowi.kick = {standing = { 0.4, 0.4, -0.3, 0.3 } }
self.jowi.kick.crouching = { 0.3, 0.3, -0.3, 0.3 }
self.jowi.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.g22c.CLIP_AMMO_MAX = 15
self.g22c.AMMO_MAX = 105
self.g22c.stats.damage = 46
self.g22c.stats.spread = 16
self.g22c.stats.spread_moving = 10
self.g22c.stats.recoil = 16
self.g22c.stats.suppression = 16
self.g22c.fire_mode_data.fire_rate = 0.1
self.g22c.can_shoot_through_shield = false
self.g22c.AMMO_PICKUP = {3, 4}
self.g22c.armor_piercing_chance = 0
self.g22c.kick = {standing = { 0.6, 0.6, -0.2, 0.2 } }
self.g22c.kick.crouching = { 0.5, 0.5, -0.2, 0.2 }
self.g22c.kick.steelsight = { 0.5, 0.5, -0.2, 0.2 }

self.x_g22c.CLIP_AMMO_MAX = 30
self.x_g22c.AMMO_MAX = 180
self.x_g22c.stats.damage = 46
self.x_g22c.stats.spread = 14
self.x_g22c.stats.spread_moving = 10
self.x_g22c.stats.recoil = 16
self.x_g22c.stats.suppression = 14
self.x_g22c.fire_mode_data.fire_rate = 0.1
self.x_g22c.can_shoot_through_shield = false
self.x_g22c.AMMO_PICKUP = {4, 6}
self.x_g22c.armor_piercing_chance = 0
self.x_g22c.kick = {standing = { 0.6, 0.6, -0.2, 0.2 } }
self.x_g22c.kick.crouching = { 0.5, 0.5, -0.2, 0.2 }
self.x_g22c.kick.steelsight = { 0.5, 0.5, -0.2, 0.2 }

self.x_g17.CLIP_AMMO_MAX = 34
self.x_g17.AMMO_MAX = 204
self.x_g17.stats.damage = 41
self.x_g17.stats.spread = 14
self.x_g17.stats.spread_moving = 10
self.x_g17.stats.recoil = 17
self.x_g17.stats.suppression = 14
self.x_g17.fire_mode_data.fire_rate = 0.1
self.x_g17.can_shoot_through_shield = false
self.x_g17.AMMO_PICKUP = {3, 6}
self.x_g17.armor_piercing_chance = 0
self.x_g17.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_g17.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_g17.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }

self.x_usp.CLIP_AMMO_MAX = 24
self.x_usp.AMMO_MAX = 168
self.x_usp.stats.damage = 54
self.x_usp.stats.spread = 14
self.x_usp.stats.spread_moving = 10
self.x_usp.stats.recoil = 16
self.x_usp.stats.suppression = 14
self.x_usp.fire_mode_data.fire_rate = 0.1
self.x_usp.can_shoot_through_shield = false
self.x_usp.AMMO_PICKUP = {2, 4}
self.x_usp.armor_piercing_chance = 0
self.x_usp.kick = {standing = { 1, 1, -0.3, 0.3 } }
self.x_usp.kick.crouching = { 0.9, 0.9, -0.3, 0.3 }
self.x_usp.kick.steelsight = { 0.8, 0.8, -0.3, 0.3 }

self.x_deagle.CLIP_AMMO_MAX = 14
self.x_deagle.AMMO_MAX = 84
self.x_deagle.stats.damage = 90
self.x_deagle.stats.spread = 10
self.x_deagle.stats.spread_moving = 6
self.x_deagle.stats.recoil = 8
self.x_deagle.stats.suppression = 12
self.x_deagle.fire_mode_data.fire_rate = 0.15
self.x_deagle.can_shoot_through_shield = false
self.x_deagle.AMMO_PICKUP = {2, 4}
self.x_deagle.armor_piercing_chance = 0.6
self.x_deagle.kick = {standing = { 3, 3.5, -0.4, 0.4 } }
self.x_deagle.kick.crouching = { 3, 3.2, -0.4, 0.4 }
self.x_deagle.kick.steelsight = { 2.8, 3, -0.3, 0.3 }

self.p226.CLIP_AMMO_MAX = 13
self.p226.AMMO_MAX = 91
self.p226.stats.damage = 46
self.p226.stats.spread = 18
self.p226.stats.spread_moving = 12
self.p226.stats.recoil = 17
self.p226.stats.suppression = 16
self.p226.fire_mode_data.fire_rate = 0.1
self.p226.can_shoot_through_shield = false
self.p226.AMMO_PICKUP = {3, 4}
self.p226.armor_piercing_chance = 0
self.p226.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.p226.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.p226.kick.steelsight = { 0.4, 0.4, -0.2, 0.2 }


self.x_p226.CLIP_AMMO_MAX = 26
self.x_p226.AMMO_MAX = 156
self.x_p226.stats.damage = 46
self.x_p226.stats.spread = 16
self.x_p226.stats.spread_moving = 9
self.x_p226.stats.recoil = 17
self.x_p226.stats.suppression = 14
self.x_p226.fire_mode_data.fire_rate = 0.1
self.x_p226.can_shoot_through_shield = false
self.x_p226.AMMO_PICKUP = {4, 6}
self.x_p226.armor_piercing_chance = 0
self.x_p226.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_p226.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_p226.kick.steelsight = { 0.4, 0.4, -0.2, 0.2 }

self.hs2000.CLIP_AMMO_MAX = 12
self.hs2000.AMMO_MAX = 84
self.hs2000.stats.damage = 46
self.hs2000.stats.spread = 15
self.hs2000.stats.spread_moving = 9
self.hs2000.stats.recoil = 16
self.hs2000.stats.suppression = 16
self.hs2000.fire_mode_data.fire_rate = 0.11
self.hs2000.can_shoot_through_shield = false
self.hs2000.AMMO_PICKUP = {3, 4}
self.hs2000.armor_piercing_chance = 0
self.hs2000.kick = {standing = { 0.6, 0.6, -0.2, 0.2 } }
self.hs2000.kick.crouching = { 0.5, 0.5, -0.2, 0.2 }
self.hs2000.kick.steelsight = { 0.5, 0.5, -0.2, 0.2 }

self.x_hs2000.CLIP_AMMO_MAX = 24
self.x_hs2000.AMMO_MAX = 144
self.x_hs2000.stats.damage = 46
self.x_hs2000.stats.spread = 12
self.x_hs2000.stats.spread_moving = 8
self.x_hs2000.stats.recoil = 16
self.x_hs2000.stats.suppression = 14
self.x_hs2000.fire_mode_data.fire_rate = 0.11
self.x_hs2000.can_shoot_through_shield = false
self.x_hs2000.AMMO_PICKUP = {2.5, 5}
self.x_hs2000.armor_piercing_chance = 0
self.x_hs2000.kick = {standing = { 0.6, 0.6, -0.2, 0.2 } }
self.x_hs2000.kick.crouching = { 0.5, 0.5, -0.2, 0.2 }
self.x_hs2000.kick.steelsight = { 0.5, 0.5, -0.2, 0.2 }

self.colt_1911.CLIP_AMMO_MAX = 8
self.colt_1911.AMMO_MAX = 64
self.colt_1911.stats.damage = 55
self.colt_1911.stats.spread = 16
self.colt_1911.stats.spread_moving = 9
self.colt_1911.stats.recoil = 15
self.colt_1911.stats.suppression = 16
self.colt_1911.fire_mode_data.fire_rate = 0.092
self.colt_1911.can_shoot_through_shield = false
self.colt_1911.AMMO_PICKUP = {2, 4}
self.colt_1911.armor_piercing_chance = 0
self.colt_1911.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.colt_1911.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.colt_1911.kick.steelsight = { 1.1, 1.1, -0.4, 0.4 }


self.x_1911.CLIP_AMMO_MAX = 16
self.x_1911.AMMO_MAX = 96
self.x_1911.stats.damage = 55
self.x_1911.stats.spread = 14
self.x_1911.stats.spread_moving = 8
self.x_1911.stats.recoil = 15
self.x_1911.stats.suppression = 14
self.x_1911.fire_mode_data.fire_rate = 0.092
self.x_1911.can_shoot_through_shield = false
self.x_1911.AMMO_PICKUP = {3, 5}
self.x_1911.armor_piercing_chance = 0
self.x_1911.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.x_1911.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.x_1911.kick.steelsight = { 1.1, 1.1, -0.4, 0.4 }


self.peacemaker.CLIP_AMMO_MAX = 6
self.peacemaker.AMMO_MAX = 42
self.peacemaker.stats.damage = 120
self.peacemaker.stats.spread = 18
self.peacemaker.stats.spread_moving = 12
self.peacemaker.stats.recoil = 12
self.peacemaker.stats.suppression = 10
self.peacemaker.fire_mode_data.fire_rate = 0.17142
self.peacemaker.can_shoot_through_shield = true
self.peacemaker.armor_piercing_chance = 1
self.peacemaker.AMMO_PICKUP = {1, 2}
self.peacemaker.kick = {standing = { 1.5, 1.5, -0.3, 0.3 } }
self.peacemaker.kick.crouching = { 1.4, 1.4, -0.3, 0.3 }
self.peacemaker.kick.steelsight = { 1.4, 1.4, -0.3, 0.3 }

self.deagle.CLIP_AMMO_MAX = 7
self.deagle.AMMO_MAX = 56
self.deagle.stats.damage = 90
self.deagle.stats.spread = 16
self.deagle.stats.spread_moving = 8
self.deagle.stats.recoil = 12
self.deagle.stats.suppression = 8
self.deagle.fire_mode_data.fire_rate = 0.15
self.deagle.can_shoot_through_shield = false
self.deagle.armor_piercing_chance = 0.6
self.deagle.AMMO_PICKUP = {1, 2}
self.deagle.armor_piercing_chance = 0.6
self.deagle.stats.concealment = 18
self.deagle.kick = {standing = { 3, 3.5, -0.4, 0.4 } }
self.deagle.kick.crouching = { 3, 3.2, -0.4, 0.4 }
self.deagle.kick.steelsight = { 2.8, 3, -0.3, 0.3 }


self.new_raging_bull.CLIP_AMMO_MAX = 6
self.new_raging_bull.AMMO_MAX = 48
self.new_raging_bull.stats.damage = 88
self.new_raging_bull.stats.spread = 18
self.new_raging_bull.stats.spread_moving = 10
self.new_raging_bull.stats.recoil = 11
self.new_raging_bull.stats.suppression = 12
self.new_raging_bull.fire_mode_data.fire_rate = 0.17143
self.new_raging_bull.can_shoot_through_shield = false
self.new_raging_bull.armor_piercing_chance = 0.7
self.new_raging_bull.AMMO_PICKUP = {2, 3}
self.new_raging_bull.kick = {standing = { 3.2, 3.2, -0.4, 0.4 } }
self.new_raging_bull.kick.crouching = { 3, 3, -0.4, 0.4 }
self.new_raging_bull.kick.steelsight = { 3, 3, -0.4, 0.4 }

self.x_rage.CLIP_AMMO_MAX = 12
self.x_rage.AMMO_MAX = 84
self.x_rage.stats.damage = 88
self.x_rage.stats.spread = 14
self.x_rage.stats.spread_moving = 8
self.x_rage.stats.recoil = 8
self.x_rage.stats.suppression = 12
self.x_rage.fire_mode_data.fire_rate = 0.17143
self.x_rage.can_shoot_through_shield = false
self.x_rage.armor_piercing_chance = 0.7
self.x_rage.AMMO_PICKUP = {2, 4}
self.x_rage.kick = {standing = { 3.2, 3.2, -0.4, 0.4 } }
self.x_rage.kick.crouching = { 3, 3, -0.4, 0.4 }
self.x_rage.kick.steelsight = { 3, 3, -0.4, 0.4 }



self.mateba.CLIP_AMMO_MAX = 6
self.mateba.AMMO_MAX = 54
self.mateba.stats.damage = 80
self.mateba.stats.spread = 22
self.mateba.stats.spread_moving = 20
self.mateba.stats.recoil = 16
self.mateba.stats.suppression = 10
self.mateba.fire_mode_data.fire_rate = 0.125
self.mateba.can_shoot_through_shield = false
self.mateba.armor_piercing_chance = 0.5
self.mateba.AMMO_PICKUP = {2, 4}
self.mateba.stats.concealment = 28
self.mateba.kick = {standing = { 1.5, 1.5, -0.3, 0.3 } }
self.mateba.kick.crouching = { 1.4, 1.4, -0.2, 0.2 }
self.mateba.kick.steelsight = { 1.4, 1.4, -0.2, 0.2 }


self.x_2006m.CLIP_AMMO_MAX = 12
self.x_2006m.AMMO_MAX = 72
self.x_2006m.stats.damage = 80
self.x_2006m.stats.spread = 20
self.x_2006m.stats.spread_moving = 16
self.x_2006m.stats.recoil = 14
self.x_2006m.stats.suppression = 8
self.x_2006m.fire_mode_data.fire_rate = 0.125
self.x_2006m.can_shoot_through_shield = false
self.x_2006m.armor_piercing_chance = 0.5
self.x_2006m.AMMO_PICKUP = {2, 5}
self.x_2006m.stats.concealment = 26
self.x_2006m.kick = {standing = { 1.5, 1.5, -0.3, 0.3 } }
self.x_2006m.kick.crouching = { 1.4, 1.4, -0.2, 0.2 }
self.x_2006m.kick.steelsight = { 1.4, 1.4, -0.2, 0.2 }


self.c96.CLIP_AMMO_MAX = 10
self.c96.AMMO_MAX = 80
self.c96.stats.damage = 55
self.c96.stats.spread = 11
self.c96.stats.spread_moving = 8
self.c96.stats.recoil = 18
self.c96.stats.suppression = 16
self.c96.fire_mode_data.fire_rate = 0.125
self.c96.can_shoot_through_shield = false
self.c96.AMMO_PICKUP = {3, 4}
self.c96.kick = {standing = { 0.6, 0.6, -0.5, 0.5 } }
self.c96.kick.crouching = { 0.5, 0.5, -0.5, 0.5 }
self.c96.kick.steelsight = { 0.4, 0.4, -0.4, 0.4 }

self.x_c96.CLIP_AMMO_MAX = 20
self.x_c96.AMMO_MAX = 120
self.x_c96.stats.damage = 55
self.x_c96.stats.spread = 9
self.x_c96.stats.spread_moving = 6
self.x_c96.stats.recoil = 16
self.x_c96.stats.suppression = 12
self.x_c96.fire_mode_data.fire_rate = 0.125
self.x_c96.can_shoot_through_shield = false
self.x_c96.AMMO_PICKUP = {3, 5}
self.x_c96.kick = {standing = { 0.6, 0.6, -0.5, 0.5 } }
self.x_c96.kick.crouching = { 0.5, 0.5, -0.5, 0.5 }
self.x_c96.kick.steelsight = { 0.4, 0.4, -0.4, 0.4 }


self.lemming.CLIP_AMMO_MAX = 20
self.lemming.AMMO_MAX = 100
self.lemming.stats.damage = 56
self.lemming.stats.spread = 18
self.lemming.stats.spread_moving = 14
self.lemming.stats.recoil = 20
self.lemming.stats.suppression = 16
self.lemming.fire_mode_data.fire_rate = 0.1
self.lemming.can_shoot_through_shield = true
self.lemming.armor_piercing_chance = 0.5
self.lemming.AMMO_PICKUP = {2, 3}
self.lemming.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.lemming.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.lemming.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.chinchilla.CLIP_AMMO_MAX = 6
self.chinchilla.AMMO_MAX = 48
self.chinchilla.stats.damage = 88
self.chinchilla.stats.spread = 20
self.chinchilla.stats.spread_moving = 16
self.chinchilla.stats.recoil = 12
self.chinchilla.suppression = 16
self.chinchilla.fire_mode_data.fire_rate = 0.17143
self.chinchilla.can_shoot_through_shield = false
self.chinchilla.armor_piercing_chance = 0.7
self.chinchilla.AMMO_PICKUP = {2, 3}
self.chinchilla.kick = {standing = { 3.4, 3.4, -0.4, 0.4 } }
self.chinchilla.kick.crouching = { 3.3, 3.3, -0.4, 0.4 }
self.chinchilla.kick.steelsight = { 3.2, 3.2, -0.4, 0.4 }



self.x_chinchilla.CLIP_AMMO_MAX = 12
self.x_chinchilla.AMMO_MAX = 72
self.x_chinchilla.stats.damage = 88
self.x_chinchilla.stats.spread = 16
self.x_chinchilla.stats.spread_moving = 8
self.x_chinchilla.stats.recoil = 10
self.x_chinchilla.suppression = 14
self.x_chinchilla.fire_mode_data.fire_rate = 0.17143
self.x_chinchilla.can_shoot_through_shield = false
self.x_chinchilla.armor_piercing_chance = 0.7
self.x_chinchilla.AMMO_PICKUP = {2, 4}
self.x_chinchilla.kick = {standing = { 3.4, 3.4, -0.4, 0.4 } }
self.x_chinchilla.kick.crouching = { 3.3, 3.3, -0.4, 0.4 }
self.x_chinchilla.kick.steelsight = { 3.2, 3.2, -0.4, 0.4 }


self.breech.CLIP_AMMO_MAX = 8
self.breech.AMMO_MAX = 64
self.breech.stats.damage = 41
self.breech.stats.spread = 13
self.breech.stats.spread_moving = 7
self.breech.stats.recoil = 18
self.breech.stats.suppression = 16
self.breech.fire_mode_data.fire_rate = 0.1
self.breech.can_shoot_through_shield = false
self.breech.AMMO_PICKUP = {3, 5}
self.breech.armor_piercing_chance = 0
self.breech.stats.concealment = 32
self.breech.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.breech.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.breech.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.x_breech.CLIP_AMMO_MAX = 16
self.x_breech.AMMO_MAX = 128
self.x_breech.stats.damage = 41
self.x_breech.stats.spread = 10
self.x_breech.stats.spread_moving = 5
self.x_breech.stats.recoil = 18
self.x_breech.stats.suppression = 14
self.x_breech.fire_mode_data.fire_rate = 0.1
self.x_breech.can_shoot_through_shield = false
self.x_breech.AMMO_PICKUP = {5, 8}
self.x_breech.armor_piercing_chance = 0
self.x_breech.stats.concealment = 30
self.x_breech.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_breech.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.x_breech.kick.steelsight = { 0.3, 0.3, -0.2, 0.2 }


self.shrew.CLIP_AMMO_MAX = 9
self.shrew.AMMO_MAX = 72
self.shrew.stats.damage = 40
self.shrew.stats.spread = 11
self.shrew.stats.spread_moving = 8
self.shrew.stats.recoil = 19
self.shrew.stats.suppression = 16
self.shrew.fire_mode_data.fire_rate = 0.092
self.shrew.can_shoot_through_shield = false
self.shrew.AMMO_PICKUP = {3, 5}
self.shrew.armor_piercing_chance = 0
self.shrew.stats.concealment = 32
self.shrew.kick = {standing = { 0.5, 0.5, -0.4, 0.4 } }
self.shrew.kick.crouching = { 0.4, 0.4, -0.3, 0.3 }
self.shrew.kick.steelsight = { 0.4, 0.4, -0.3, 0.3 }

self.x_shrew.CLIP_AMMO_MAX = 18
self.x_shrew.AMMO_MAX = 108
self.x_shrew.stats.damage = 40
self.x_shrew.stats.spread = 11
self.x_shrew.stats.spread_moving = 8
self.x_shrew.stats.recoil = 19
self.x_shrew.stats.suppression = 16
self.x_shrew.fire_mode_data.fire_rate = 0.092
self.x_shrew.can_shoot_through_shield = false
self.x_shrew.AMMO_PICKUP = {4, 6}
self.x_shrew.armor_piercing_chance = 0
self.x_shrew.stats.concealment = 30
self.x_shrew.kick = {standing = { 0.5, 0.5, -0.4, 0.4 } }
self.x_shrew.kick.crouching = { 0.4, 0.4, -0.3, 0.3 }
self.x_shrew.kick.steelsight = { 0.4, 0.4, -0.3, 0.3 }

self.czech.CLIP_AMMO_MAX = 16
self.czech.AMMO_MAX = 128
self.czech.stats.damage = 41
self.czech.stats.spread = 19
self.czech.stats.spread_moving = 14
self.czech.stats.recoil = 20
self.czech.stats.suppression = 10
self.czech.can_shoot_through_shield = false
self.czech.AMMO_PICKUP = {2, 5}
self.czech.armor_piercing_chance = 0
self.czech.kick = {standing = { 0.7, 0.7, -0.5, 0.5 } }
self.czech.kick.crouching = { 0.6, 0.6, -0.5, 0.5 }
self.czech.kick.steelsight = { 0.5, 0.5, -0.5, 0.5 }

self.x_czech.CLIP_AMMO_MAX = 32
self.x_czech.AMMO_MAX = 256
self.x_czech.stats.damage = 41
self.x_czech.stats.spread = 14
self.x_czech.stats.spread_moving = 12
self.x_czech.stats.recoil = 16
self.x_czech.stats.suppression = 8
self.x_czech.can_shoot_through_shield = false
self.x_czech.AMMO_PICKUP = {4, 6}
self.x_czech.armor_piercing_chance = 0
self.x_czech.kick = {standing = { 0.7, 0.7, -0.5, 0.5 } }
self.x_czech.kick.crouching = { 0.6, 0.6, -0.5, 0.5 }
self.x_czech.kick.steelsight = { 0.5, 0.5, -0.5, 0.5 }

self.beer.CLIP_AMMO_MAX = 15
self.beer.AMMO_MAX = 120
self.beer.stats.damage = 41
self.beer.stats.spread = 17
self.beer.stats.spread_moving = 12
self.beer.stats.recoil = 20
self.beer.stats.suppression = 12
self.beer.can_shoot_through_shield = false
self.beer.AMMO_PICKUP = {2, 5}
self.beer.armor_piercing_chance = 0
self.beer.kick = {standing = { 0.7, 0.7, -0.4, 0.4 } }
self.beer.kick.crouching = { 0.6, 0.6, -0.4, 0.4 }
self.beer.kick.steelsight = { 0.6, 0.6, -0.3, 0.3 }


self.x_beer.CLIP_AMMO_MAX = 30
self.x_beer.AMMO_MAX = 240
self.x_beer.stats.damage = 41
self.x_beer.stats.spread = 15
self.x_beer.stats.spread_moving = 12
self.x_beer.stats.recoil = 18
self.x_beer.stats.suppression = 10
self.x_beer.can_shoot_through_shield = false
self.x_beer.AMMO_PICKUP = {4, 6}
self.x_beer.armor_piercing_chance = 0
self.x_beer.kick = {standing = { 0.7, 0.7, -0.4, 0.4 } }
self.x_beer.kick.crouching = { 0.6, 0.6, -0.4, 0.4 }
self.x_beer.kick.steelsight = { 0.6, 0.6, -0.3, 0.3 }

self.stech.CLIP_AMMO_MAX = 20
self.stech.AMMO_MAX = 180
self.stech.stats.damage = 40
self.stech.stats.spread = 14
self.stech.stats.spread_moving = 6
self.stech.stats.recoil = 16
self.stech.stats.suppression = 12
self.stech.can_shoot_through_shield = false
self.stech.AMMO_PICKUP = {3, 5}
self.stech.armor_piercing_chance = 0
self.stech.kick = {standing = { 0.5, 0.5, -0.5, 0.5 } }
self.stech.kick.crouching = { 0.4, 0.4, -0.5, 0.5 }
self.stech.kick.steelsight = { 0.4, 0.4, -0.4, 0.4 }

self.x_stech.CLIP_AMMO_MAX = 40
self.x_stech.AMMO_MAX = 360
self.x_stech.stats.damage = 40
self.x_stech.stats.spread = 12
self.x_stech.stats.spread_moving = 5
self.x_stech.stats.recoil = 20
self.x_stech.stats.suppression = 12
self.x_stech.can_shoot_through_shield = false
self.x_stech.AMMO_PICKUP = {5, 7}
self.x_stech.armor_piercing_chance = 0
self.x_stech.kick = {standing = { 0.5, 0.5, -0.5, 0.5 } }
self.x_stech.kick.crouching = { 0.4, 0.4, -0.5, 0.5 }
self.x_stech.kick.steelsight = { 0.4, 0.4, -0.4, 0.4 }

self.holt.CLIP_AMMO_MAX = 15
self.holt.AMMO_MAX = 120
self.holt.stats.damage = 41
self.holt.stats.spread = 18
self.holt.stats.spread_moving = 14
self.holt.stats.recoil = 20
self.holt.stats.suppression = 16
self.holt.fire_mode_data.fire_rate = 0.092
self.holt.can_shoot_through_shield = false
self.holt.AMMO_PICKUP = {3, 5}
self.holt.armor_piercing_chance = 0
self.holt.kick = {standing = { 0.4, 0.4, -0.2, 0.2 } }
self.holt.kick.crouching = { 0.4, 0.4, -0.2, 0.2 }
self.holt.kick.steelsight = { 0.4, 0.4, -0.2, 0.2 }


self.x_holt.CLIP_AMMO_MAX = 30
self.x_holt.AMMO_MAX = 180
self.x_holt.stats.damage = 41
self.x_holt.stats.spread = 18
self.x_holt.stats.spread_moving = 14
self.x_holt.stats.recoil = 18
self.x_holt.stats.suppression = 12
self.x_holt.fire_mode_data.fire_rate = 0.092
self.x_holt.can_shoot_through_shield = false
self.x_holt.AMMO_PICKUP = {4, 8}
self.x_holt.armor_piercing_chance = 0
self.x_holt.kick = {standing = { 0.5, 0.5, -0.2, 0.2 } }
self.x_holt.kick.crouching = { 0.5, 0.5, -0.2, 0.2 }
self.x_holt.kick.steelsight = { 0.5, 0.5, -0.2, 0.2 }

self.model3.CLIP_AMMO_MAX = 6
self.model3.AMMO_MAX = 60
self.model3.stats.damage = 65
self.model3.stats.spread = 16
self.model3.stats.spread_moving = 10
self.model3.stats.recoil = 18
self.model3.suppression = 16
self.model3.fire_mode_data.fire_rate = 0.17143
self.model3.can_shoot_through_shield = false
self.model3.armor_piercing_chance = 0.5
self.model3.AMMO_PICKUP = {5, 8}
self.model3.kick = {standing = { 1.5, 1.5, -0.4, 0.4 } }
self.model3.kick.crouching = { 1.4, 1.4, -0.4, 0.4 }
self.model3.kick.steelsight = { 1.5, 1.5, -0.4, 0.4 }

self.x_model3.CLIP_AMMO_MAX = 12
self.x_model3.AMMO_MAX = 120
self.x_model3.stats.damage = 65
self.x_model3.stats.spread = 14
self.x_model3.stats.spread_moving = 7
self.x_model3.stats.recoil = 16
self.x_model3.suppression = 10
self.x_model3.fire_mode_data.fire_rate = 0.17143
self.x_model3.can_shoot_through_shield = false
self.x_model3.armor_piercing_chance = 0.5
self.x_model3.AMMO_PICKUP = {6, 10}
self.x_model3.kick = {standing = { 1.5, 1.5, -0.4, 0.4 } }
self.x_model3.kick.crouching = { 1.4, 1.4, -0.4, 0.4 }
self.x_model3.kick.steelsight = { 1.5, 1.5, -0.4, 0.4 }

self.m1911.CLIP_AMMO_MAX = 8
self.m1911.AMMO_MAX = 64
self.m1911.stats.damage = 55
self.m1911.stats.spread = 16
self.m1911.stats.spread_moving = 10
self.m1911.stats.recoil = 15
self.m1911.stats.suppression = 16
self.m1911.fire_mode_data.fire_rate = 0.092
self.m1911.can_shoot_through_shield = false
self.m1911.AMMO_PICKUP = {2, 4}
self.m1911.armor_piercing_chance = 0
self.m1911.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.m1911.kick.crouching = { 1, 1, -0.4, 0.4 }
self.m1911.kick.steelsight = { 1, 1, -0.4, 0.4 }

self.x_m1911.CLIP_AMMO_MAX = 16
self.x_m1911.AMMO_MAX = 96
self.x_m1911.stats.damage = 55
self.x_m1911.stats.spread = 14
self.x_m1911.stats.spread_moving = 6
self.x_m1911.stats.recoil = 14
self.x_m1911.stats.suppression = 16
self.x_m1911.fire_mode_data.fire_rate = 0.092
self.x_m1911.can_shoot_through_shield = false
self.x_m1911.AMMO_PICKUP = {4, 6}
self.x_m1911.armor_piercing_chance = 0
self.x_m1911.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.x_m1911.kick.crouching = { 1, 1, -0.4, 0.4 }
self.x_m1911.kick.steelsight = { 1, 1, -0.4, 0.4 }













-- Specials

self.m134.CLIP_AMMO_MAX = 1000
self.m134.AMMO_MAX = 2000
self.m134.stats.damage = 100
self.m134.stats.spread = 6
self.m134.stats.spread_moving = 1
self.m134.stats.recoil = 5
self.m134.stats.suppression = 2
self.m134.fire_mode_data.fire_rate = 0.02
self.m134.can_shoot_through_shield = true
self.m134.can_shoot_through_wall = true
self.m134.can_shoot_through_enemy = true
self.m134.armor_piercing_chance = 1
self.m134.AMMO_PICKUP = {0,0}

self.shuno.CLIP_AMMO_MAX = 750
self.shuno.AMMO_MAX = 1500
self.shuno.stats.damage = 70
self.shuno.stats.spread = 12
self.shuno.stats.spread_moving = 8
self.shuno.stats.recoil = 18
self.shuno.stats.suppression = 2
self.shuno.can_shoot_through_shield = false
self.shuno.armor_piercing_chance = 0.8
self.shuno.AMMO_PICKUP = {0,0}


self.flamethrower_mk2.CLIP_AMMO_MAX = 600
self.flamethrower_mk2.AMMO_MAX = 1200
self.flamethrower_mk2.stats.damage = 40
self.flamethrower_mk2.stats.spread = 5
self.flamethrower_mk2.stats.recoil = 20
self.flamethrower_mk2.stats.suppression = 4
self.flamethrower_mk2.can_shoot_through_shield = true
self.flamethrower_mk2.AMMO_PICKUP = {0,0}

self.system.CLIP_AMMO_MAX = 400
self.system.AMMO_MAX = 1200
self.system.stats.damage = 30
self.system.AMMO_PICKUP = {0,0}

-- Grenade Launchers

self.gre_m79.CLIP_AMMO_MAX = 1
self.gre_m79.AMMO_MAX = 6
self.gre_m79.stats.damage = 150
self.gre_m79.stats.spread = 16
self.gre_m79.stats.recoil = 17
self.gre_m79.stats.suppression = 5
self.gre_m79.fire_mode_data.fire_rate = 1

self.china.CLIP_AMMO_MAX = 3
self.china.AMMO_MAX = 9
self.china.stats.damage = 150
self.china.stats.spread = 16
self.china.stats.recoil = 15
self.china.stats.suppression = 5
self.china.fire_mode_data.fire_rate = 1.333333
self.china.timers.shotgun_reload_exit_empty = 1.5
self.china.timers.shotgun_reload_exit_not_empty = 0.6



self.m32.CLIP_AMMO_MAX = 6
self.m32.AMMO_MAX = 12
self.m32.stats.damage = 150
self.m32.fire_mode_data.fire_rate = 0.6
self.m32.stats.spread = 16
self.m32.stats.recoil = 16
self.m32.stats.suppression = 5


self.arbiter.CLIP_AMMO_MAX = 5
self.arbiter.AMMO_MAX = 15
self.arbiter.stats.damage = 150
self.arbiter.stats.spread = 20
self.arbiter.stats.recoil = 20
self.arbiter.stats.suppression = 5
self.arbiter.fire_mode_data.fire_rate = 0.5

self.rpg7.CLIP_AMMO_MAX = 1
self.rpg7.AMMO_MAX = 8
self.rpg7.stats.damage = 150
self.rpg7.stats.spread = 25
self.rpg7.stats.recoil = 25
self.rpg7.stats.suppression = 5
self.rpg7.stats_modifiers = {damage = 100}


self.ray.CLIP_AMMO_MAX = 4
self.ray.AMMO_MAX = 8
self.ray.stats.damage = 100
self.ray.stats.spread = 25
self.ray.stats.recoil = 25
self.ray.stats.suppression = 5
self.ray.fire_mode_data.fire_rate = 0.75
self.ray.stats_modifiers = {damage = 100}

self.slap.CLIP_AMMO_MAX = 1
self.slap.AMMO_MAX = 6
self.slap.stats.damage = 150
self.slap.stats.spread = 25
self.slap.stats.suppression = 5
self.slap.timers.reload_empty = 3.4

-- ((Custom Weapons))


if self.hugsforleon then 
self.hugsforleon.CLIP_AMMO_MAX = 30
self.hugsforleon.AMMO_MAX = 180
self.hugsforleon.stats.damage = 68
self.hugsforleon.stats.spread = 24
self.hugsforleon.stats.spread_moving = 18
self.hugsforleon.stats.recoil = 22
self.hugsforleon.armor_piercing_chance = 0.7
self.hugsforleon.AMMO_PICKUP = {3, 5}
self.hugsforleon.kick = {standing = { 1, 1, -0.2, 0.2 } }
self.hugsforleon.kick.crouching = { 0.8, 0.8, -0.2, 0.2 }
self.hugsforleon.kick.steelsight = { 0.7, 0.7, -0.2, 0.2 }
end

if self.drongo then 
self.drongo.CLIP_AMMO_MAX = 30
self.drongo.AMMO_MAX = 180
self.drongo.stats.damage = 65
self.drongo.stats.spread = 17
self.drongo.stats.spread_moving = 12
self.drongo.stats.recoil = 18
self.drongo.stats.suppression = 12
self.drongo.armor_piercing_chance = 0.6
self.drongo.AMMO_PICKUP = {3, 6}
self.drongo.stats.concealment = 22
self.drongo.kick = {standing = { 0.9, 1.1, -0.3, 0.3 } }
self.drongo.kick.crouching = { 0.8, 1, -0.2, 0.2 }
self.drongo.kick.steelsight = { 0.7, 0.9, -0.2, 0.2 }
end

if self.ak5s then 
self.ak5s.CLIP_AMMO_MAX = 30
self.ak5s.AMMO_MAX = 180
self.ak5s.stats.damage = 42
self.ak5s.stats.spread = 19
self.ak5s.stats.spread_moving = 14
self.ak5s.stats.recoil = 17
self.ak5s.stats.suppression = 12
self.ak5s.can_shoot_through_shield = false
self.ak5s.AMMO_PICKUP = {4, 8}
self.ak5s.armor_piercing_chance = 0
self.ak5s.kick = {standing = { 0.3, 0.5, -0.4, 0.4 } }
self.ak5s.kick.crouching = { 0.2, 0.4, -0.4, 0.4 }
self.ak5s.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }
end

if self.sg416 then 
self.sg416.CLIP_AMMO_MAX = 30
self.sg416.AMMO_MAX = 180
self.sg416.stats.damage = 66
self.sg416.stats.spread = 21
self.sg416.stats.spread_moving = 18
self.sg416.stats.recoil = 23
self.sg416.armor_piercing_chance = 0.6
self.sg416.AMMO_PICKUP = {3, 6}
self.sg416.stats.suppression = 12
self.sg416.stats.concealment = 18
self.sg416.kick = {standing = { 1, 1.2, -0.3, 0.3 } }
self.sg416.kick.crouching = { 1, 1.1, -0.3, 0.3 }
self.sg416.kick.steelsight = { 0.8, 1, -0.2, 0.2 }
end

if self.amr12 then 
self.amr12.CLIP_AMMO_MAX = 7
self.amr12.AMMO_MAX = 42
self.amr12.stats.damage = 130
self.amr12.stats.spread = 16
self.amr12.stats.spread_moving = 14
self.amr12.stats.recoil = 16
self.amr12.stats.suppression = 9
self.amr12.rays = 9
self.amr12.can_shoot_through_shield = false
self.amr12.AMMO_PICKUP = {2, 3}
self.amr12.armor_piercing_chance = 0
self.amr12.kick = {standing = { 2, 2.2, -0.2, 0.2 } }
self.amr12.kick.crouching = { 2, 2, -0.2, 0.2 }
self.amr12.kick.steelsight = { 2, 2, -0.2, 0.2 }
self.amr12.damage_near = 1500
self.amr12.damage_far = 2500
end

if self.soppo then 
self.soppo.CLIP_AMMO_MAX = 30
self.soppo.AMMO_MAX = 180
self.soppo.stats.damage = 66
self.soppo.stats.spread = 20
self.soppo.stats.spread_moving = 14
self.soppo.stats.recoil = 20
self.soppo.stats.suppression = 12
self.soppo.fire_mode_data.fire_rate = 0.0857
self.soppo.can_shoot_through_shield = false
self.soppo.armor_piercing_chance = 0.6
self.soppo.AMMO_PICKUP = {3, 6}
self.soppo.kick = {standing = { 1, 1.1, -0.4, 0.4 } }
self.soppo.kick.crouching = { 0.9, 1, -0.4, 0.4 }
self.soppo.kick.steelsight = { 0.7, 0.9, -0.3, 0.3 }

self.contraband_m203.CLIP_AMMO_MAX = 1
self.contraband_m203.AMMO_MAX = 4
self.contraband_m203.stats.damage = 80
self.contraband_m203.stats.spread = 12
self.contraband_m203.stats.recoil = 8
self.contraband_m203.stats.suppression = 4
self.contraband_m203.fire_mode_data.fire_rate = 1
self.contraband_m203.can_shoot_through_shield = false
self.contraband_m203.AMMO_PICKUP = {0.2, 0.5}
end

if self.beck then 
self.beck.CLIP_AMMO_MAX = 6
self.beck.AMMO_MAX = 48
self.beck.stats.damage = 136
self.beck.stats.spread = 14
self.beck.stats.spread_moving = 8
self.beck.stats.recoil = 12
self.beck.stats.suppression = 14
self.beck.fire_mode_data.fire_rate = 0.4
self.beck.can_shoot_through_shield = false
self.beck.rays = 9
self.beck.AMMO_PICKUP = {2, 3}
self.beck.armor_piercing_chance = 0
self.beck.kick = {standing = { 2.8, 3, -0.2, 0.2 } }
self.beck.kick.crouching = { 2.6, 2.8, -0.2, 0.2 }
self.beck.kick.steelsight = { 2.4, 2.6, -0.1, 0.1 }
self.beck.damage_near = 1600
self.beck.damage_far = 3400
end

if self.smolak then 
self.smolak.CLIP_AMMO_MAX = 20
self.smolak.AMMO_MAX = 100
self.smolak.stats.damage = 60
self.smolak.stats.spread = 10
self.smolak.stats.spread_moving = 8
self.smolak.stats.recoil = 18
self.smolak.stats.suppression = 10
self.smolak.fire_mode_data.fire_rate = 0.09231
self.smolak.armor_piercing_chance = 0.5
self.smolak.can_shoot_through_shield = false
self.smolak.AMMO_PICKUP = {3, 6}
self.smolak.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.smolak.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.smolak.kick.steelsight = { 1, 1, -0.4, 0.4 }
self.smolak.CAN_TOGGLE_FIREMODE = false
self.smolak.FIRE_MODE = "single"
end

if self.car9 then 
self.car9.CLIP_AMMO_MAX = 17
self.car9.AMMO_MAX = 136
self.car9.stats.damage = 42
self.car9.stats.spread = 19
self.car9.stats.spread_moving = 16
self.car9.stats.recoil = 18
self.car9.stats.suppression = 16
self.car9.can_shoot_through_shield = false
self.car9.AMMO_PICKUP = {4, 6}
self.car9.armor_piercing_chance = 0
self.car9.kick = {standing = { 0.5, 0.5, -0.4, 0.4 } }
self.car9.kick.crouching = { 0.4, 0.4, -0.4, 0.4 }
self.car9.kick.steelsight = { 0.4, 0.4, -0.3, 0.3 }
end

if self.x_smolak then 
self.x_smolak.CLIP_AMMO_MAX = 40
self.x_smolak.AMMO_MAX = 240
self.x_smolak.stats.damage = 60
self.x_smolak.stats.spread = 6
self.x_smolak.stats.spread_moving = 4
self.x_smolak.stats.recoil = 18
self.x_smolak.stats.suppression = 8
self.x_smolak.fire_mode_data.fire_rate = 0.09231
self.x_smolak.armor_piercing_chance = 0.5
self.x_smolak.can_shoot_through_shield = false
self.x_smolak.AMMO_PICKUP = {4, 7}
self.x_smolak.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.x_smolak.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.x_smolak.kick.steelsight = { 1, 1, -0.4, 0.4 }
self.x_smolak.CAN_TOGGLE_FIREMODE = false
self.x_smolak.FIRE_MODE = "single"
end

if self.x_ak5s then 
self.x_ak5s.CLIP_AMMO_MAX = 60
self.x_ak5s.AMMO_MAX = 300
self.x_ak5s.stats.damage = 42
self.x_ak5s.stats.spread = 14
self.x_ak5s.stats.spread_moving = 10
self.x_ak5s.stats.recoil = 18
self.x_ak5s.stats.suppression = 9
self.x_ak5s.can_shoot_through_shield = false
self.x_ak5s.AMMO_PICKUP = {4, 6}
self.x_ak5s.armor_piercing_chance = 0
self.x_ak5s.kick = {standing = { 0.3, 0.5, -0.4, 0.4 } }
self.x_ak5s.kick.crouching = { 0.2, 0.4, -0.4, 0.4 }
self.x_ak5s.kick.steelsight = { 0.2, 0.3, -0.3, 0.3 }
end

if self.x_car9 then 
self.x_car9.CLIP_AMMO_MAX = 34
self.x_car9.AMMO_MAX = 204
self.x_car9.stats.damage = 42
self.x_car9.stats.spread = 16
self.x_car9.stats.spread_moving = 12
self.x_car9.stats.recoil = 17
self.x_car9.stats.suppression = 9
self.x_car9.can_shoot_through_shield = false
self.x_car9.AMMO_PICKUP = {4, 6}
self.x_car9.armor_piercing_chance = 0
self.x_car9.kick = {standing = { 0.5, 0.5, -0.4, 0.4 } }
self.x_car9.kick.crouching = { 0.4, 0.4, -0.4, 0.4 }
self.x_car9.kick.steelsight = { 0.4, 0.4, -0.3, 0.3 }
end

if self.spike then 
self.spike.CLIP_AMMO_MAX = 30
self.spike.AMMO_MAX = 120
self.spike.stats.damage = 75
self.spike.stats.spread = 18
self.spike.stats.spread_moving = 12
self.spike.stats.recoil = 16
self.spike.stats.suppression = 10
self.spike.fire_mode_data.fire_rate = 0.1
self.spike.can_shoot_through_shield = false
self.spike.armor_piercing_chance = 0.5
self.spike.AMMO_PICKUP = {2, 4}
self.spike.kick = {standing = { 1.5, 1.5, -0.4, 0.4 } }
self.spike.kick.crouching = { 1.5, 1.5, -0.4, 0.4 }
self.spike.kick.steelsight = { 1.5, 1.5, -0.4, 0.4 }
end

if self.cold then 
self.cold.CLIP_AMMO_MAX = 8
self.cold.AMMO_MAX = 48
self.cold.stats.damage = 55
self.cold.stats.spread = 15
self.cold.stats.spread_moving = 9
self.cold.stats.recoil = 15
self.cold.stats.suppression = 16
self.cold.fire_mode_data.fire_rate = 0.092
self.cold.can_shoot_through_shield = false
self.cold.AMMO_PICKUP = {2, 4}
self.cold.armor_piercing_chance = 0
self.cold.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.cold.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.cold.kick.steelsight = { 1, 1, -0.4, 0.4 }
end

if self.x_cold then 
self.x_cold.CLIP_AMMO_MAX = 16
self.x_cold.AMMO_MAX = 160
self.x_cold.stats.damage = 55
self.x_cold.stats.spread = 12
self.x_cold.stats.spread_moving = 6
self.x_cold.stats.recoil = 12
self.x_cold.stats.suppression = 12
self.x_cold.fire_mode_data.fire_rate = 0.092
self.x_cold.can_shoot_through_shield = false
self.x_cold.AMMO_PICKUP = {2, 4}
self.x_cold.armor_piercing_chance = 0
self.x_cold.kick = {standing = { 1.2, 1.2, -0.4, 0.4 } }
self.x_cold.kick.crouching = { 1.1, 1.1, -0.4, 0.4 }
self.x_cold.kick.steelsight = { 1, 1, -0.4, 0.4 }
end

if self.sgs then 
self.sgs.CLIP_AMMO_MAX = 20
self.sgs.AMMO_MAX = 100
self.sgs.stats.damage = 95
self.sgs.stats.spread = 22
self.sgs.stats.spread_moving = 18
self.sgs.stats.recoil = 16
self.sgs.stats.suppression = 10
self.sgs.fire_mode_data.fire_rate = 0.08
self.sgs.can_shoot_through_shield = false
self.sgs.armor_piercing_chance = 0.8
self.sgs.AMMO_PICKUP = {1, 2}
self.sgs.stats_modifiers = {damage = 1}
self.sgs.kick = {standing = { 1.6, 1.8, -0.3, 0.3 } }
self.sgs.kick.crouching = { 1.6, 1.6, -0.3, 0.3 }
self.sgs.kick.steelsight = { 1.6, 1.6, -0.3, 0.3 }
end

if self.lebman then 
self.lebman.CLIP_AMMO_MAX = 10
self.lebman.AMMO_MAX = 100
self.lebman.stats.damage = 44
self.lebman.stats.spread = 14
self.lebman.stats.spread_moving = 8
self.lebman.stats.recoil = 16
self.lebman.stats.suppression = 8
self.lebman.fire_mode_data.fire_rate = 0.06
self.lebman.can_shoot_through_shield = false
self.lebman.armor_piercing_chance = 0
self.lebman.AMMO_PICKUP = {4, 6}
self.lebman.kick = {standing = { 0.6, 0.8, -0.6, 0.6 } }
self.lebman.kick.crouching = { 0.6, 0.8, -0.6, 0.6 }
self.lebman.kick.steelsight = { 0.5, 0.7, -0.6, 0.6 }
self.lebman.CAN_TOGGLE_FIREMODE = true
end

if self.x_lebman then 
self.x_lebman.CLIP_AMMO_MAX = 20
self.x_lebman.AMMO_MAX = 200
self.x_lebman.stats.damage = 44
self.x_lebman.stats.spread = 10
self.x_lebman.stats.spread_moving = 5
self.x_lebman.stats.recoil = 16
self.x_lebman.stats.suppression = 6
self.x_lebman.fire_mode_data.fire_rate = 0.06
self.x_lebman.can_shoot_through_shield = false
self.x_lebman.armor_piercing_chance = 0
self.x_lebman.AMMO_PICKUP = {6, 8}
self.x_lebman.kick = {standing = { 0.6, 0.8, -0.6, 0.6 } }
self.x_lebman.kick.crouching = { 0.6, 0.8, -0.6, 0.6 }
self.x_lebman.kick.steelsight = { 0.5, 0.7, -0.6, 0.6 }
self.x_lebman.CAN_TOGGLE_FIREMODE = true
end

if self.aknato then
self.aknato.CLIP_AMMO_MAX = 30
self.aknato.AMMO_MAX = 180
self.aknato.stats.damage = 66
self.aknato.stats.spread = 17
self.aknato.stats.spread_moving = 10
self.aknato.stats.recoil = 18
self.aknato.stats.suppression = 12
self.aknato.armor_piercing_chance = 0.6
self.aknato.can_shoot_through_shield = false
self.aknato.AMMO_PICKUP = {3, 6}
self.aknato.kick = {standing = { 1.0, 1.1, -0.4, 0.4 } }
self.aknato.kick.crouching = { 0.9, 1, -0.3, 0.3 }
self.aknato.kick.steelsight = { 0.9, 0.9, -0.3, 0.3 }
self.aknato.timers.reload_not_empty = 2.3
end

if self.bdgr then
self.bdgr.CLIP_AMMO_MAX = 30
self.bdgr.AMMO_MAX = 180
self.bdgr.stats.damage = 70
self.bdgr.stats.spread = 20
self.bdgr.stats.spread_moving = 16
self.bdgr.stats.recoil = 18
self.bdgr.stats.concealment = 19
self.bdgr.stats.suppression = 11
self.bdgr.can_shoot_through_shield = false
self.bdgr.armor_piercing_chance = 0.75
self.bdgr.AMMO_PICKUP = {3, 5}
self.bdgr.kick = {standing = { 1.2, 1.2, -0.6, 0.6 } }
self.bdgr.kick.crouching = { 1.0, 1.0, -0.6, 0.6 }
self.bdgr.kick.steelsight = { 1.0, 1.0, -0.5, 0.5 }
end

if self.minibeck then
self.minibeck.CLIP_AMMO_MAX = 5
self.minibeck.AMMO_MAX = 30
self.minibeck.stats.damage = 130
self.minibeck.stats.spread = 10
self.minibeck.stats.spread_moving = 4
self.minibeck.stats.recoil = 8
self.minibeck.stats.suppression = 14
self.minibeck.fire_mode_data.fire_rate = 0.2
self.minibeck.can_shoot_through_shield = false
self.minibeck.rays = 9
self.minibeck.AMMO_PICKUP = {2, 3}
self.minibeck.armor_piercing_chance = 0
self.minibeck.kick = {standing = { 3, 3.2, -0.4, 0.4 } }
self.minibeck.kick.crouching = { 3, 3, -0.4, 0.4 }
self.minibeck.kick.steelsight = { 3, 3, -0.4, 0.4 }
self.minibeck.damage_near = 900
self.minibeck.damage_far = 1600
end




end