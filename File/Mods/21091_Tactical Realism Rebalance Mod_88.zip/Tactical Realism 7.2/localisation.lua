Hooks:Add("LocalizationManagerPostInit", "oui", function(loc)
	LocalizationManager:add_localized_strings({
	
		bm_w_amcar_desc = "AMR16's carbine version, 5.56x45, 10 inch barrel",			                        -- AMCAR
		bm_w_m4_desc = "Standard issue for the law enforcement, highly customizable, a straight upgrade from AMCAR, 14 inch barrel",				        -- CAR-4
		bm_w_m16_desc = "Comes with 16 inch barrel, very accurate and powerful, but less ergonomic than its carbine counterpart, good aftermarket support",				                -- AMR-16
		bm_w_ak74_desc = "Illegaly imported, an original AK74 assault rifle charmbered in 5.45x39, standard issue for the Russian military, less recoil than 5.56x45 rifles but also less velocity",			                        -- AK
		bm_w_ak5_desc = "Swedish assault rifle, 5.56x45, 17 inch barrel",				                -- Ak5
		bm_w_aug_desc = "A classic bullpup assault rifle, controllable recoil and decent accuracy, bullpup design gives concealment bonuses, 5.56x45",				                -- UAR
		bm_w_g36_desc = "German carbine, standard issue for the Gensec and Murky, decent gun but short barrel makes it less accurate, 5.56x45",				                -- JP36
		bm_w_s552_desc = "A rare Swiss carbine, compact and packs enough firepower, not very accurate due to the short barrel, 5.56x45",			                -- Commando 553
		bm_w_famas_desc = "Rarely seen in the state, originated from France, slightly outdated, but the fire rate is absurdly high for an assault rifle, 5.56x45",			                -- Clarion
		bm_w_l85a2_desc = "British bullpup assault rifle, very controllable but slow to reload due to the design, 5.56x45",			                        -- Queen's Wrath
		bm_w_vhs_desc = "Basically a bullpup JP36, slow to reload due to the bullpup design, otherwise it's a good rifle, 5.56x45",				        -- Lion's Roar
		bm_w_ak12_desc = "A newly upgraded AK style rifle to replace AK74 for the Russian military, comes with a more modernized design and better compatibility with aftermarket attachments, accuracy and recoil are also superior, 5.45x39",			                        -- AK17
		bm_w_tecci_desc = "SG416 carbine with a 10 inch barrel and 100 rounds drum magazine, 5.56x45, good for crowd control",			                        -- Bootleg
		bm_w_hajk_desc = "A new product from Czech, relatively compact and can be used as secondary weapon, 5.56x45",			                        -- CR 805B
		bm_w_corgi_desc = "A Belgium bullpup assault rifle, are often seen in recent conflicts in Middle East, 5.56x45",			        -- Union 5.56
		bm_w_asval_desc = "A Russian assault rifle chambered in 9x39 subsonic rounds, comes with integrated suppressor, deadly and silent",			                                -- Valkyria
		bm_w_akm_desc = "Battle proven, famous AK 762, no need to explain, 7.62x39 kicks more but also punchs harder",			-- AK.762
		bm_w_akm_gold_desc = "Golden plated AK",		                                -- Golden AK.762
		bm_w_m14_desc = "Kicks like a mule but 308 caliber makes it an decent marksman rifle, can be customized to suit for different combat scenarios, this version also comes with a bolt release for more convenient reload",				                        -- M308
		bm_w_scar_desc = "Favored by spec ops, accurate and the recoil is more forgiving than other 308 rifles",			                        -- Eagle Heavy
		bm_w_fal_desc = "The right arm of the free world, 7.62x51",				                                -- Falcon
		bm_w_g3_desc = "Designed with the iconic roller delayed blowback system, makes the gun easier to control compare to its competitors at the time, can be converted to a sniper rifle with the right modification, 7.62x51",				        -- Gewehr 3
		bm_w_galil_desc = "An Israeli 308 battle rifle, internal design is almost identical to AK, but has better performance",			        -- Gecko 7.62
		bm_w_contraband_desc = "SG417 battle rifle with a m203 underbarrel grenade launcher, perfect gun when you want to make a good first impression on your enemies",		        -- Little Friend
		bm_w_ching_desc = "A classic world war 2 rifle, chambered in 30-06, boomer's favorite",			                        -- Galant
		bm_w_sub2000_desc = "A foldable PCC, this version comes with 9MM +P rounds",			-- Cavity
		bm_w_komodo_desc = "A new Israeli assault rifle, compact and easy to handle, 5.56x45",			                                -- MTAR 21
                bm_w_hugsforleon_desc = "5.56 version of Contractor 308 rifle, very accurate", 
		bm_w_drongo_desc = "SG416 with a short barrel, 5.56x45",
		bm_w_sg416_desc = "SG416 assault rifle, you can pretend to be operator with this gun, 5.56x45",
		bm_w_soppo_desc = "CAR4 with a grenade launcher, 5.56x45",
		bm_w_spike_desc = "An AKM installed with bullpup coversion kit for better control and ergonomics, 7.62x39",
		bm_w_aknato_desc = "A US made AK chambered in 5.56x45, can use AR attachments",
		bm_w_bdgr_desc = "An custom made AR15, fires .300 blackout",
		
		bm_w_tti_desc = "An custmoized gucci AR10 rifle",				                -- Contractor 308
		bm_w_wa2000_desc = "A very rare sniper rifle chambered with 308 Armor Piercing rounds, extremly accurate and compact, but only holds 6 rounds and slow to reload",			                -- Lebensauger
		bm_w_mosin_desc = "Garbage rod",			                        -- Nagant
		bm_w_siltstone_desc = "A classic Russian sniper rifle, 7.62x54 Armor Piercing",		                        -- Grom
		bm_w_model70_desc = "Fudd rifle, 30-06 armor piercing",			                        -- Platypus 70
		bm_w_msr_desc = "Modular sniper rifle, .338 armor piercing rounds",				                        -- Rattlesnake
		bm_w_r93_desc = "A very well crafted sniper rifle, extremely accurate, .338 AP",				                -- R93
		bm_w_desertfox_desc = "Bullpup sniper rifle, good concealment and very lethal with .338 AP",		                -- Desert Fox
		bm_w_winchester1874_desc = "Real boomer, 44-40",	-- Repeater 1874
		bm_w_m95_desc = ".50 bullpup anti-material rifle",				                -- Thanatos 50
		bm_w_sgs_desc = "A marksman version of Commando 553, 7.62x51 AP, very accurate and easy to use",
		bm_w_r700_desc = "Modernized model 70, 5.56 AP",
		bm_w_sbl_desc = "A modern lever action rifle, 45-70",
		
		bm_w_r870_desc = "One of the most common pump action 12 gauge shotgun in the world, popular in both civilian and law enforcement markets",			                        -- Reinfeld 880
		bm_w_saiga_desc = "A Russian semi-auto magazine fed shotgun based on AK platform, 12 Gauge",			        -- IZHMA
		bm_w_huntsman_desc = "For sport purpose only, 12 gauge",		                        -- Mosconi
		bm_w_benelli_desc = "A semi-auto Italian shotgun, 12 gauge",			                -- M1014
		bm_w_ksg_desc = "A 12 gauge bullpup pump action shotgun, has 2 magazine tube internally, compact and powerful",				                -- Raven
		bm_w_spas12_desc = "A famous gun because of movies, semi auto, 12 gauge",			                        -- Predator
		bm_w_b682_desc = "Fudd",			                        -- Joceline O/U
		bm_w_aa12_desc = "A fully automatic 12 gauge shotgun, comes with 8 round magazine, low recoil, very illegal",			                        -- Steakout
		bm_w_judge_desc = "A revolver chambered in .410 shotgun rounds, less lethal than 12 gauge, but highly concealable and more controllable",			                        -- Judge
		bm_w_serbu_desc = "Chopped off 880, you can hide it under your trench coat",			                        -- Locomotive
		bm_w_striker_desc = "Shotgun with revolver design, rare",			                -- Street Sweeper
		bm_w_basset_desc = "IZHMA in a bullpup coversion kit",			        -- Grimm
		bm_w_rota_desc = "A new breed on the market, revolver style cylinder feed shotgun, rapid to reload, 12 gauge",			                        -- Goliath
		bm_w_m37_desc = "This classic police shotgun has been in service for over 70 years, 12 gauge",				                -- GSPS
		bm_w_boot_desc = "Lever action shotgun, looks cool, 10 gauge",		-- Breaker
		bm_w_coach_desc = "For sport purpose only, secondary weapon, 12 gauge",			-- Claire 12G
		bm_w_amr12_desc = "AR style 12 gauge shotgun, compatible with most AR attachments",
		bm_w_beck_desc = "12 gauge Pump action shotgun used by original Payday gangs during multiple heists",
		bm_w_minibeck_desc = "Semi-auto, sawed-off version of Reinbeck",
		bm_w_m1897_desc = "Very old shotgun, used in WW2, 12 Gauge",
		bm_w_m590_desc = "Fastest pump action shotgun",

		
		
		
		bm_w_glock_17_desc = "One of the most used handguns in the world, 9mm, designed in from the 80s but still not outdated, 9x19",		-- Chimano 88
		bm_w_b92fs_desc = "9x19 B9S",		-- Bernetti 9
		bm_w_ppk_desc = "Shitty damage because of the .32 acp caliber, only holds 8 rounds, good for stealth",				        -- Gruber Kurz
		bm_wp_pis_g26_desc = "Pretty useless in combat, good for conceal carry, 9x19",		-- Chimano Compact
		bm_w_pl14_desc = "New Russian handgun made by the same brand that produces AKs, 9x19",			        -- White Streak
		bm_w_packrat_desc = "New SG 9mm pistol",			-- Contractor
		bm_w_legacy_desc = "Superior German engineering, sadly not that useful in combat",			-- M13 9mm
		bm_w_lemming_desc = "A large size handgun chambered in 5.7x28 ap rounds, hold 20 rounds",			        -- 5/7 AP
		bm_w_breech_desc = "A relic from WW1, not much of the use besides looking cool, 9x19",			        -- Parabellum
		bm_w_shrew_desc = "Crosskill compact version, useless, good for stealth, 9mm",			                        -- Crosskill Guard
		bm_w_hs2000_desc = "A Cortian made pistol, brought back by Dragan, popular in the state even though it's a shitty gun, 9x19",			                -- LEO
		bm_w_p226_desc = "Another German classic handgun, this is a .40 version",			                        -- Signature 40
		bm_w_g22c_desc = "GLOCK FORTY, .40",			                                -- Chimano Custom
		bm_w_sparrow_desc = "9mm Israeli handgun",	-- Baby Deagle
		bm_w_usp_desc = "The famous German pistol, .45",				                -- Interceptor 45
		bm_w_colt_1911_desc = "Ok boomer, .45",		        -- Crosskill
		bm_w_peacemaker_desc = "Too boomer to shoot, very slow to reload .45 long colt",		        -- Peacemaker 45
		bm_w_mateba_desc = "Very rare revolver, very accurate but slow to reload, .357",			        -- Matever 357
		bm_w_chinchilla_desc = "A famous .44 revolver, high recoil",		        -- Castigo 44
		bm_w_deagle_desc = ".50 AE handgun, not very practical, 7 rounds",			                        -- Deagle
		bm_w_raging_bull_desc = "A new .44 revolver produced by a Brazilian company",		                -- Bronco 44
                bm_w_beer_desc = "Bernetti 9 machine pistol, 9x19",                               -- Bernetti Auto Pistol
                bm_w_czech_desc = "Czech made machine pistol, 9x19",                 -- Czech 92 Pistol
                bm_w_stech_desc = "Russian made machine pistol, 9x18",                     -- Igor Automatik Pistol
		bm_w_cold_desc = "Real boomer's favorite, an replica of original Crosskill, .45",
		bm_w_lebman_desc = "A Crosskill chambered in .38 super, converted to fullauto, have a fire selector",
		bm_w_smolak_desc = "Draco AK, 5.45x39, very bad accuracy but powerful",
		bm_w_holt_desc = "Dead pistol, 9x19",
		bm_w_model3_desc = "Why would you even use this, rechambered in .44 special",
		bm_w_m1911_desc = "Fudd .45",
		
                
                
		
		bm_w_mp9_desc = "Standard issue smg for law enforcement, 9x19",				                -- CMP
		bm_w_glock_18c_desc = "Full auto Glock, has a fire selector, hard to control due to its high fire rate, 9x19",		-- STRYK 18c
		bm_w_p90_desc = "5.7x28 armor piercing PDW",				        -- Kobus 90
		bm_w_mp5_desc = "The famous SG mp5, easy to control, accurate, favored by law enforcement for over 60 years, 9x19",				                -- Compact-5
		bm_w_m45_desc = "Used by MACV-SOG in Nam, old but reliable, 9x19",				-- Swedish K
		bm_w_akmsu_desc = "An carbine version of AKM, early prototype, very high rate of fire, a lot of recoil, 7.62x39",			-- Krinkov
		bm_w_olympic_desc = "An AR pistol chambered with 5.56x45, comes in handy when you need some extra firepower",			                        -- Para
		bm_w_mp7_desc = "SG made PDW, 4.6x30 AP, no poor allowed",				-- SpecOps
		bm_w_scorpion_desc = "A .32acp SMG, kinda useless",		                        -- Cobra
		bm_w_tec9_desc = "Gang banger's favorite, 9x19, this one is post-ban version, semi-auto only",		-- Blaster
		bm_w_uzi_desc = "Famous UZI, no need to introduce, 9x19",				                -- Uzi
		bm_w_c96_desc = "A restored WW1 relic, still functional, .30 Mauser",		-- Broomstick
		bm_w_sterling_desc = "A 9x19 British SMG developed during the late stage of WW2, adopted by many commonwealth states, and battle proven through out warfare from 50 and 60s",		                -- Patchett L2A1
		bm_w_cobray_desc = "A newly upgraded MAC 10, 9x19, larger and less maneuverability, but easier to control",		-- Jacket's Piece
		bm_w_baka_desc = "Micro UZI, extremly fast fire rate, 9x19, good for conceal carry",			                -- Micro Uzi
		bm_w_sr2_desc = "A Russian SMG chambred in 9x21, can penetrate armor better than 9X19 luger",				                -- Heather
		bm_w_erma_desc = "A WW2 German submachine gun, 9x19, very easy to use",			                        -- MP40
		bm_w_coal_desc = "A Russian SMG based on AK, comes with a unique helical magazine, 9x18",			                -- Tatonka
		bm_w_m1928_desc = "A SMG from the 20s, .45acp",			                -- Chicago Typewriter
		bm_w_mac10_desc = "MAC 10, .45ACP",			-- Mark 10
		bm_w_polymer_desc = "A modern .45 SMG, very fast fire rate",			                -- Kross Vertex
		bm_w_schakal_desc = "A SG made .45 SMG, Gensec standard issue, very tactical",			                -- Jackal
		bm_w_shepheard_desc = "A new competitetor to the MP5, and it's better, handles like an AR15",		                        -- Signature
		bm_w_car9_desc = "AR9 SMG, this has a integrated suppressor, accept Chimano 88 magazines",
		bm_w_ak5s_desc = "A prototype AK5 smg uses 9x19 round",
		bm_w_vityaz_desc = "Russian 9X19 SMG",
		
		bm_w_rpk_desc = "AK with longer barrel and a 75 rounds drum mag",		        -- RPK
		bm_w_m249_desc = "200 5.56 rounds box feed magazine says all, standard issue for the military",			                        -- KSP
		bm_w_hk21_desc = "OG Payday crew's favorite, SG made 308 machine gun",		-- Brennet 21
		bm_w_mg42_desc = "A WW2 German machine gun, chambered with the devastating 7.92x57 full power rifle rounds, insane fire rate, but only holds 50 rounds",			                -- Buzzsaw 42
		bm_w_par_desc = "A bigger, 308 version of KSP",				-- Ksp 58
		bm_w_m60_desc = "Classic 308 machine gun",
            
		
               

       
               

		
		
	})
end)