Hooks:PostHook(BlackMarketTweakData, "_init_weapon_skins", "MagpullSkinFix", function(self)

-- Assault Rifle --
-- M308 --
self.weapon_skins.new_m14_bloodsplat.parts.wpn_fps_ass_m14_m_quick = {
	[Idstring("mag"):key()] = {
		sticker = Idstring("units/payday2_cash/safes/cop/sticker/sticker_pinupp_df"),
		uv_offset_rot = Vector3(0.029201, 0.570584, 0),
		uv_scale = Vector3(2.83711, 2.83711, 0),
		pattern = Idstring("units/payday2_cash/safes/cop/pattern/pattern_overkill_logo_df"),
		pattern_tweak = Vector3(2.14075, 1.02152, 1)
	}
}

-- Clarion --
self.weapon_skins.famas_skf.parts.wpn_fps_ass_famas_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		pattern = "units/payday2_cash/safes/skf/pattern/skf_pattern_014_d_df",
		base_gradient = "units/payday2_cash/safes/skf/base_gradient/base_skf_014_df",
		pattern_gradient = "units/payday2_cash/safes/skf/pattern_gradient/gradient_skf_014_df",
		pattern_tweak = Vector3(1.01598, 0, 1),
		pattern_pos = Vector3(0.130217, -0.022418, 0)
	}
}
self.weapon_skins.famas_skf.parts.wpn_fps_ass_famas_m_magpul = {
	[Idstring("mtr_mag"):key()] = {
		base_gradient = "units/payday2_cash/safes/buck/base_gradient/base_buck_004_df"
	}
}
	
self.weapon_skins.famas_bloodsplat.parts.wpn_fps_ass_famas_m_magpul = {
	[Idstring("mtr_mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/buck/base_gradient/base_buck_004_df")
	}
}

-- Little Friend 7.62 --
self.weapon_skins.contraband_mxs.parts.wpn_fps_ass_contraband_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/mxs/base_gradient/base_mxs_002_df")
	}
}

self.weapon_skins.contraband_sfs.parts.wpn_fps_ass_contraband_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		pattern_tweak = Vector3(1.39757, 4.76971, 0),
		cubemap_pattern_control = Vector3(1, 1, 0),
		pattern_pos = Vector3(0.537425, 1.21013, 0)
	}
}

-- Falcon --	
self.weapon_skins.fal_burn.parts.wpn_fps_ass_fal_m_quick = {
	[Idstring("mat_magazine02"):key()] = {
		sticker = Idstring("units/payday2_cash/safes/burn/sticker/burn_sticker_009_df"),
		uv_offset_rot = Vector3(-0.136895, 1.19866, 1.75773),
		pattern_pos = Vector3(-0.136434, 0.425948, 0),
		uv_scale = Vector3(1.74059, 2.02664, 0.18674)
	}
}

-- Shotgun --
-- Steakout 12G --
self.weapon_skins.aa12_wac.parts.wpn_fps_sho_aa12_m_quick = {
	[Idstring("aa12_mag_straight"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/wac/base_gradient/base_wac_003_df"),
		uv_offset_rot = Vector3(-0.172514, 1.17005, 6.28319),
		uv_scale = Vector3(3.17083, 3.45688, 0),
		sticker = Idstring("units/payday2_cash/safes/burn/sticker/burn_sticker_003_df")
	}
}

self.weapon_skins.aa12_cs3.parts.wpn_fps_sho_aa12_m_quick = {
	[Idstring("aa12_mag_straight"):key()] = {
		pattern = "units/payday2_cash/safes/cs3/pattern/cs3_pattern_003_b_df",
		sticker = "units/payday2_cash/safes/cs3/sticker/cs3_sticker_006_df",
		pattern_gradient = "units/payday2_cash/safes/cs3/pattern_gradient/gradient_cs3_003_b_df",
		pattern_tweak = Vector3(1, 4.70977, 1),
		uv_offset_rot = Vector3(0.00620103, 1.17959, 4.52995),
		pattern_pos = Vector3(-1.55831, -0.442165, 0),
		uv_scale = Vector3(3.29955, 3.29955, 0.413308),
		base_gradient = Idstring("units/payday2_cash/safes/wac/base_gradient/base_wac_001_b_df")
	}
}

-- Goliath 12G --
self.weapon_skins.rota_mxs.parts.wpn_fps_sho_rota_m_quick = {
	[Idstring("mat_mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/pack/base_gradient/base_pack_010_df"),
		pattern_pos = Vector3(0.002, 0, 0),
		pattern_tweak = Vector3(0, 0, 1),
		pattern = Idstring("units/payday2_cash/safes/shared/pattern/pattern_acryl_001_df")
	}
}

-- Pistol --
-- STRYK 18c --
self.weapon_skins.glock_18c_wac.parts.wpn_fps_pis_g17_m_quick = {
	[Idstring("mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/buck/base_gradient/base_buck_007_df")
	}
}

self.weapon_skins.glock_18c_burn.parts.wpn_fps_pis_g17_m_quick = {
	[Idstring("mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/burn/base_gradient/base_burn_012_c_df"),
		pattern_gradient = Idstring("units/payday2_cash/safes/bah/pattern_gradient/gradient_bah_002_df"),
		sticker = Idstring("units/payday2_cash/safes/burn/sticker/burn_sticker_001_df"),
		uv_scale = Vector3(0.01, 0.01, 1),
		uv_offset_rot = Vector3(2, 2, 0),
		pattern_tweak = Vector3(1.54067, 1.62287, 1),
		pattern = Idstring("units/payday2_cash/safes/burn/pattern/burn_pattern_003_df")
	}
}

-- Interceptor .45 --
self.weapon_skins.usp_cat.parts.wpn_fps_pis_usp_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		base_gradient = "units/payday2_cash/safes/cat/base_gradient/base_cat_017_df"
	}
}

-- Chimano Compact --
self.weapon_skins.jowi_mxs.parts.wpn_fps_pis_g17_m_quick = {
	[Idstring("mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/mxs/base_gradient/base_mxs_001_b_df")
	}
}

-- Submachine Gun --
-- Compact-5 --
self.weapon_skins.new_mp5_cs3.parts.wpn_fps_smg_mp5_m_quick = {
	[Idstring("mag_std"):key()] = {
		pattern = "units/payday2_cash/safes/cs3/pattern/cs3_pattern_011_g_df",
		pattern_gradient = "units/payday2_cash/safes/cs3/pattern_gradient/gradient_cs3_011_c_df",
		pattern_pos = Vector3(0.645361, -0.566182, 0),
		pattern_tweak = Vector3(1, 1.96752, 1)
	}
}

self.weapon_skins.new_mp5_buck.parts.wpn_fps_smg_mp5_m_quick = {
	[Idstring("mag_std"):key()] = {
		uv_offset_rot = Vector3(-2, -2, 0.364135)
	}
}
	
-- Chicago Typewriter --
self.weapon_skins.m1928_wwt.parts.wpn_fps_smg_thompson_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/wwt/base_gradient/base_wwt_001_df")
	}
}

self.weapon_skins.m1928_grunt.parts.wpn_fps_smg_thompson_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		base_gradient = Idstring("units/payday2_cash/safes/grunt/base_gradient/base_grunt_004_df")
	}
}

self.weapon_skins.m1928_smosh.parts.wpn_fps_smg_thompson_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		pattern = "units/payday2_cash/safes/smosh/pattern/smosh_pattern_015_df",
		sticker = "units/payday2_cash/safes/smosh/sticker/smosh_sticker_015_e_df",
		pattern_gradient = "units/payday2_cash/safes/smosh/pattern_gradient/gradient_smosh_015_c_df",
		uv_offset_rot = Vector3(0.0825188, 1.09373, 0),
		uv_scale = Vector3(4.82514, 4.82514, 1),
		cubemap_pattern_control = Vector3(0.582638, 1, 0),
		pattern_tweak = Vector3(4.73647, 0, 0.630336)
	}
}

-- Swedish K --
self.weapon_skins.m45_buck.parts.wpn_fps_smg_m45_m_quick = {
	[Idstring("m45_mag"):key()] = {
		uv_scale = Vector3(2.64641, 0.0243047, 1),
		uv_offset_rot = Vector3(-0.225292, 0.982331, 4.71278)
	}
}

-- Kross Vertex --
self.weapon_skins.polymer_css.parts.wpn_fps_smg_polymer_m_quick = {
	[Idstring("mtr_mag"):key()] = {
		sticker = "units/payday2_cash/safes/css/sticker/css_sticker_011_df",
		base_gradient = "units/payday2_cash/safes/css/base_gradient/base_css_011_j_df",
		uv_offset_rot = Vector3(0, 0.998331, 0)
	}
}

-- Tatonka --
self.weapon_skins.coal_css.parts.wpn_fps_smg_coal_m_quick = {
	[Idstring("mat_mag"):key()] = {
		pattern = "units/payday2_cash/safes/css/pattern/css_pattern_012_b_df",
		pattern_tweak = Vector3(1, 0, 0)
	}
}

end)
